# go-ws-template

Template Go para camadas de WebSocket de alta densidade: **50k–100k+ conexões por instância**, multiplexação de canais, fan-out paralelo multi-core e custo ~70% menor que o equivalente Node horizontal. Nasceu das lições do `r10-websockets` (ver `docs/PLAN.md` e `docs/ARCHITECTURE.md`).

## Por que este template

O padrão broadcast→clientes parece simples, mas tem armadilhas que limitam qualquer servidor a poucos milhares de conexões: lock global no fan-out, envio bloqueante para cliente lento (head-of-line blocking) e ausência de keepalive. Este template resolve por construção:

- **Sessões multiplexadas** — 1 conexão assina até N canais (subscribe dinâmico via frames de controle); até N× menos conexões por usuário.
- **Hub shardado por canal** — broadcast lê um snapshot imutável (zero locks, zero alocações) e, em canais quentes, fatia o fan-out por um **worker pool multi-core**.
- **Mailbox latest-wins por assinatura** — cliente lento recebe o estado mais recente e nunca atrasa os demais; modo **keyed** mantém o último estado **por entidade** (ex.: por jogo).
- **Snapshot-on-connect** — assinante novo recebe o estado atual imediatamente.
- **`PreparedMessage`** — frame WS serializado 1× por broadcast, não 1× por cliente.
- **Keepalive completo** + **política de cliente lento** (desconexão por drops sustentados) + **rate limit de upgrades** (anti accept-storm).
- **Envelope com `seq` + timestamp + canal/chave** — idade da mensagem (publish→socket) vira métrica p99; o "super spike" deixa de ser invisível.
- **Graceful shutdown** com close frames espalhados (jitter) e **GOMEMLIMIT automático** via cgroup.
- **Auth JWT HS256 opcional** (claims podem restringir canais) e **pprof** em porta separada.
- **2 dependências** (`gorilla/websocket`, `go-redis/v9`). Métricas Prometheus, config, envelope, auth e rate limit em stdlib.

## Quickstart

```bash
make setup            # go mod tidy + .env
make compose-up       # redis + servidor via docker
# ou local:
make run-memory       # servidor com broker em memória (sem Redis)

# terminal 2 — publica eventos com envelope (keys=20 p/ modo keyed):
make publisher rate=50

# terminal 3 — abre conexões multiplexadas e mede idade p50/p95/p99:
make loadtest conns=1000
```

Conexão do cliente:

```
ws://localhost:8080/ws?channels=events            # assinaturas iniciais (CSV)
ws://host/ws?event=stats&language=portuguese      # compat r10: canal "stats-portuguese"
```

## Protocolo (v1.1)

### Frames de dados (BINARY): envelope + payload opaco

```
[0:2] magic 0x5753 | [2] versão=1 | [3] flags | [4:12] seq | [12:20] publish_ts (µs Unix)
flags bit1 (0x02): extensão de canal  → [1B len][canal]   (sempre presente servidor→cliente)
flags bit0 (0x01): extensão de chave  → [1B len][chave]   (produtor→servidor, modo keyed)
[...] payload (protobuf, JSON, ...)
```

### Frames de controle (TEXT JSON)

```jsonc
// cliente → servidor
{"action":"subscribe","channels":["odds-pt","placar-pt"]}
{"action":"unsubscribe","channels":["odds-pt"]}
// servidor → cliente
{"type":"ack","action":"subscribe","ok":["odds-pt"],"errors":{"x":"unknown channel"}}
```

### Cliente JS de referência

```js
ws.binaryType = "arraybuffer";
ws.onopen = () => ws.send(JSON.stringify({ action: "subscribe", channels: ["odds-pt"] }));
ws.onmessage = (e) => {
  if (typeof e.data === "string") return handleAck(JSON.parse(e.data));
  const v = new DataView(e.data);
  if (v.getUint16(0) !== 0x5753) return;
  const flags = v.getUint8(3);
  const publishedUs = v.getBigUint64(12);
  let off = 20, channel = "", key = "";
  if (flags & 0x02) { const n = v.getUint8(off); channel = dec(e.data, off + 1, n); off += 1 + n; }
  if (flags & 0x01) { const n = v.getUint8(off); key = dec(e.data, off + 1, n); off += 1 + n; }
  const ageMs = publishedUs ? Date.now() - Number(publishedUs / 1000n) : 0;
  const payload = new Uint8Array(e.data, off);
  // ageMs alto → UI "dado defasado": nunca deixe o usuário agir sobre preço velho
};
const dec = (buf, off, len) => new TextDecoder().decode(new Uint8Array(buf, off, len));
```

Publicação (produtor/dataloader): `PUBLISH <prefixo><tópico> <envelope+payload>` no Redis, via `internal/envelope` (`Encode` ou `EncodeKeyed`); `cmd/publisher` é a referência.

## Configuração

Tudo por env — ver [.env.sample](.env.sample). Principais:

| Variável | Default | Descrição |
|---|---|---|
| `WS_TOPICS` | `events` | Canais lógicos (CSV) |
| `WS_MAX_CONNECTIONS` | `50000` | Acima disso: HTTP 503 |
| `WS_DELIVERY_MODE` | `coalesce` | `coalesce` (snapshot por canal) · `coalesce-keyed` (latest por entidade) · `buffer` (fila drop-oldest) |
| `WS_MAX_SUBSCRIPTIONS` | `16` | Canais por conexão (multiplexação) |
| `WS_SNAPSHOT_ON_CONNECT` | `true` | Entrega o estado atual ao assinar |
| `WS_FANOUT_CHUNK` | `4096` | Acima disso, fan-out do canal vai para o worker pool |
| `WS_SLOW_MAX_DROPS` / `WS_SLOW_WINDOW` | `1000` / `10s` | Desconecta cliente lento (close 1013); 0 desliga |
| `WS_UPGRADE_RATE` / `WS_UPGRADE_BURST` | `0` / `2000` | Rate limit de upgrades (429); 0 = sem limite |
| `WS_AUTH_SECRET` | _(vazio)_ | JWT HS256; claims `exp` (obrig.), `sub`, `channels` |
| `WS_COMPRESSION` | `false` | permessage-deflate |
| `WS_DEBUG_PORT` | _(vazio)_ | pprof (nunca expor publicamente) |
| `WS_PING_INTERVAL` / `WS_PONG_TIMEOUT` | `25s` / `60s` | Keepalive (ALB idle timeout > ping interval) |
| `WS_DRAIN_TIMEOUT` / `WS_DRAIN_JITTER` | `30s` / `5s` | Drain no SIGTERM |
| `BROKER_KIND` / `REDIS_ADDR` | `redis` / `localhost:6379` | Broker (1 assinatura Redis por tópico) |

## Métricas (`/metrics`, formato Prometheus)

| Métrica | Para quê |
|---|---|
| `ws_message_age_seconds` (hist, por canal) | **A métrica do super spike**: p99 da idade publish→socket. Alarme principal |
| `ws_active_connections` (gauge) | Sessões ativas — capacidade/autoscaling |
| `ws_active_subscriptions{channel}` | Assinaturas por canal |
| `ws_messages_dropped_total{channel}` | Pressão de coalescing — clientes lentos |
| `ws_slow_clients_disconnected_total` | Política de cliente lento agindo |
| `ws_broadcast_fanout_seconds` (hist) | Custo do fan-out por broadcast |
| `ws_rejected_full_total` / `ws_rate_limited_total` / `ws_auth_rejected_total` | Rejeições no teto / rate limit / auth |
| `ingest_events_total` / `ingest_invalid_envelope_total` | Saúde da ingestão |
| `go_goroutines`, `go_mem_heap_*`, `go_gc_*` | Saúde do runtime |

## Dimensionamento e operação

- **Vertical primeiro**: 1 task 2 vCPU/2 GB > 10 tasks de 0,25 vCPU. Horizontal é HA (2–4 tasks multi-AZ), não capacidade.
- **ulimits**: `nofile >= 1048576` na task definition (1 conexão = 1 fd).
- **GOMEMLIMIT**: autodetectado do cgroup (90%); evita OOM kill no pico.
- **ALB**: idle timeout maior que `WS_PING_INTERVAL`; health check em `/healthz`.
- **Picos previsíveis** (jogos grandes): scheduled scaling antes do evento.
- **Aceitação**: `make spike` + `make loadtest` com p99 de `ws_message_age_seconds` abaixo do limite do motor de risco — "não caiu" não é critério.

Detalhes em [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Estrutura

```
cmd/server        servidor (+ GOMEMLIMIT automático)
cmd/publisher     produtor de teste (envelope, chaves, rajadas de super spike)
cmd/loadtest      gerador de carga multiplexado com medição de idade no cliente
internal/hub        sessões, assinaturas, mailboxes, fan-out paralelo  (stdlib)
internal/envelope   header binário seq+timestamp+canal/chave           (stdlib)
internal/metrics    Prometheus text via atomics (+GaugeFunc)           (stdlib)
internal/auth       JWT HS256                                          (stdlib)
internal/ratelimit  token bucket p/ upgrades                           (stdlib)
internal/broker     interface + memory; redisbroker = go-redis/v9 (1 sub/tópico)
internal/transport  upgrade, protocolo de controle, pumps, drain, pprof (gorilla)
```

## Documentação

| Documento | Quando ler |
|---|---|
| [docs/GUIDE.md](docs/GUIDE.md) | **Comece aqui** para criar um novo serviço ou alterar um existente — passo a passo com receitas |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Visão de arquitetura, invariantes de performance e checklist de produção |
| [docs/adr/](docs/adr/README.md) | Decisões arquiteturais registradas (ADRs) — toda decisão nova entra aqui, no mesmo PR |
| [docs/IMPROVEMENTS.md](docs/IMPROVEMENTS.md) | Backlog priorizado de melhorias (com status) |
| [docs/PLAN.md](docs/PLAN.md) | Planejamento original e critérios de aceitação |

## Roadmap

Itens restantes por gatilho (ver [docs/IMPROVEMENTS.md](docs/IMPROVEMENTS.md)): transporte epoll (`gobwas/ws`) para 1M+ conexões/instância, broker com entrega garantida (NATS JetStream/Kafka) e SDK de cliente oficial (TS/Go).
