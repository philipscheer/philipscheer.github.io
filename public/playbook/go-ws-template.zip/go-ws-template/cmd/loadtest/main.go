// loadtest abre N conexões WebSocket multiplexadas, assina canais via frames
// de controle, mede a idade das mensagens no cliente (decodificando o
// envelope) e reporta p50/p95/p99 — o critério de aceitação do super spike é
// o p99 ficar abaixo do limite tolerado pelo motor de risco.
//
// Exemplos:
//
//	go run ./cmd/loadtest -url ws://localhost:8080/ws -channels events -conns 1000
//	go run ./cmd/loadtest -channels "odds-pt,placar-pt" -conns 10000 -ramp 30s -churn 0.01
//	go run ./cmd/loadtest -channels events -conns 100 -token "$JWT"
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"math"
	"math/rand"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/gorilla/websocket"

	"github.com/grupootg/go-ws-template/internal/envelope"
	"github.com/grupootg/go-ws-template/internal/metrics"
)

type stats struct {
	connected atomic.Int64
	connErrs  atomic.Uint64
	messages  atomic.Uint64
	bytes     atomic.Uint64
	noEnvel   atomic.Uint64
	acks      atomic.Uint64
	age       *metrics.Histogram
}

func main() {
	var (
		baseURL  = flag.String("url", "ws://localhost:8080/ws", "URL base do servidor")
		channels = flag.String("channels", "events", "canais a assinar (CSV) por conexão")
		token    = flag.String("token", "", "JWT (quando WS_AUTH_SECRET ativo no servidor)")
		conns    = flag.Int("conns", 100, "número de conexões simultâneas")
		ramp     = flag.Duration("ramp", 5*time.Second, "tempo para abrir todas as conexões")
		duration = flag.Duration("duration", 0, "duração do teste (0 = até Ctrl+C)")
		churn    = flag.Float64("churn", 0, "fração de conexões recicladas por segundo (0.01 = 1%/s)")
	)
	flag.Parse()

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	if *duration > 0 {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, *duration)
		defer cancel()
	}

	reg := metrics.NewRegistry()
	st := &stats{
		age: reg.Histogram("client_message_age_seconds", "idade no cliente", nil,
			metrics.DefaultLatencyBuckets()),
	}

	chList := strings.Split(*channels, ",")
	for i := range chList {
		chList[i] = strings.TrimSpace(chList[i])
	}
	subFrame, _ := json.Marshal(map[string]any{"action": "subscribe", "channels": chList})

	var header http.Header
	if *token != "" {
		header = http.Header{"Authorization": []string{"Bearer " + *token}}
	}

	dialer := &websocket.Dialer{HandshakeTimeout: 10 * time.Second}

	var wg sync.WaitGroup
	interval := time.Duration(0)
	if *conns > 0 {
		interval = *ramp / time.Duration(*conns)
	}

	fmt.Printf("abrindo %d conexões em %s contra %s, canais %v (churn %.2f%%/s)\n",
		*conns, *ramp, *baseURL, chList, *churn*100)

	for i := 0; i < *conns; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			runConn(ctx, dialer, *baseURL, header, subFrame, st, *churn)
		}()
		if interval > 0 {
			select {
			case <-ctx.Done():
				i = *conns
			case <-time.After(interval):
			}
		}
	}

	go report(ctx, st)
	wg.Wait()
	final(st)
}

// runConn mantém uma conexão viva (com reconexão backoff+jitter) até o ctx
// encerrar. Com churn > 0, recicla a conexão aleatoriamente — simula o
// comportamento real de clientes e o pico de reconexões do super spike.
func runConn(ctx context.Context, d *websocket.Dialer, url string, header http.Header,
	subFrame []byte, st *stats, churn float64) {
	backoff := time.Second
	for ctx.Err() == nil {
		conn, _, err := d.DialContext(ctx, url, header)
		if err != nil {
			st.connErrs.Add(1)
			select {
			case <-ctx.Done():
				return
			case <-time.After(backoff + time.Duration(rand.Int63n(int64(backoff)))):
			}
			if backoff < 30*time.Second {
				backoff *= 2
			}
			continue
		}
		backoff = time.Second
		if err := conn.WriteMessage(websocket.TextMessage, subFrame); err != nil {
			st.connErrs.Add(1)
			_ = conn.Close()
			continue
		}
		st.connected.Add(1)
		readLoop(ctx, conn, st, churn)
		st.connected.Add(-1)
		_ = conn.Close()
	}
}

func readLoop(ctx context.Context, conn *websocket.Conn, st *stats, churn float64) {
	var recycle <-chan time.Time
	if churn > 0 {
		// tempo de vida ~ Exp(churn) por conexão
		life := time.Duration(rand.ExpFloat64() / churn * float64(time.Second))
		t := time.NewTimer(life)
		defer t.Stop()
		recycle = t.C
	}

	done := make(chan struct{})
	go func() {
		defer close(done)
		for {
			msgType, data, err := conn.ReadMessage()
			if err != nil {
				return
			}
			if msgType == websocket.TextMessage {
				st.acks.Add(1) // acks/erros do protocolo de controle
				continue
			}
			st.messages.Add(1)
			st.bytes.Add(uint64(len(data)))
			if env, err := envelope.Decode(data); err == nil && env.PublishedMicros != 0 {
				if age := env.Age(time.Now()); age >= 0 {
					st.age.Observe(age.Seconds())
				}
			} else if err != nil {
				st.noEnvel.Add(1)
			}
		}
	}()

	select {
	case <-ctx.Done():
	case <-recycle:
	case <-done:
		return
	}
	_ = conn.WriteControl(websocket.CloseMessage,
		websocket.FormatCloseMessage(websocket.CloseNormalClosure, ""),
		time.Now().Add(time.Second))
	_ = conn.Close()
	<-done
}

func report(ctx context.Context, st *stats) {
	ticker := time.NewTicker(5 * time.Second)
	defer ticker.Stop()
	var lastMsgs uint64
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			msgs := st.messages.Load()
			fmt.Printf("conns=%d msgs=%d (%.0f/s) errs=%d acks=%d | idade p50=%s p95=%s p99=%s\n",
				st.connected.Load(), msgs, float64(msgs-lastMsgs)/5,
				st.connErrs.Load(), st.acks.Load(),
				secs(st.age.Quantile(0.50)),
				secs(st.age.Quantile(0.95)),
				secs(st.age.Quantile(0.99)),
			)
			lastMsgs = msgs
		}
	}
}

func final(st *stats) {
	fmt.Println("\n===== RESULTADO =====")
	fmt.Printf("mensagens recebidas: %d (%.1f MB)\n", st.messages.Load(),
		float64(st.bytes.Load())/1e6)
	fmt.Printf("erros de conexão:    %d\n", st.connErrs.Load())
	fmt.Printf("sem envelope:        %d\n", st.noEnvel.Load())
	fmt.Printf("idade da mensagem:   p50=%s p95=%s p99=%s (n=%d)\n",
		secs(st.age.Quantile(0.50)),
		secs(st.age.Quantile(0.95)),
		secs(st.age.Quantile(0.99)),
		st.age.Count(),
	)
}

func secs(v float64) string {
	if math.IsInf(v, 1) {
		return ">60s" // acima do último bucket do histograma
	}
	return time.Duration(v * float64(time.Second)).Round(time.Millisecond).String()
}
