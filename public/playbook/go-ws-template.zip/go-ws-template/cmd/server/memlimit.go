package main

import (
	"os"
	"runtime/debug"
	"strconv"
	"strings"
)

// setupMemoryLimit define GOMEMLIMIT ≈ 90% do limite de memória do container
// (cgroup v2/v1) quando não configurado explicitamente — sem isso, o GC não
// conhece o teto da task e o OOM killer derruba dezenas de milhares de
// conexões de uma vez (IMPROVEMENTS §3).
//
// Precedência: env GOMEMLIMIT (runtime já honra) > autodetecção cgroup.
// Retorna o limite aplicado em bytes (0 = nenhum).
func setupMemoryLimit() int64 {
	if os.Getenv("GOMEMLIMIT") != "" {
		return 0 // o runtime já aplicou
	}
	limit := cgroupMemoryLimit()
	if limit <= 0 {
		return 0
	}
	soft := limit * 9 / 10
	debug.SetMemoryLimit(soft)
	return soft
}

func cgroupMemoryLimit() int64 {
	// cgroup v2
	if b, err := os.ReadFile("/sys/fs/cgroup/memory.max"); err == nil {
		v := strings.TrimSpace(string(b))
		if v != "max" {
			if n, err := strconv.ParseInt(v, 10, 64); err == nil {
				return n
			}
		}
	}
	// cgroup v1
	if b, err := os.ReadFile("/sys/fs/cgroup/memory/memory.limit_in_bytes"); err == nil {
		if n, err := strconv.ParseInt(strings.TrimSpace(string(b)), 10, 64); err == nil {
			// v1 reporta um número astronômico quando não há limite
			if n > 0 && n < int64(1)<<60 {
				return n
			}
		}
	}
	return 0
}
