// Servidor de WebSockets de alta densidade.
// Configuração 100% por variáveis de ambiente — ver .env.sample.
package main

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"github.com/grupootg/go-ws-template/internal/broker"
	"github.com/grupootg/go-ws-template/internal/broker/redisbroker"
	"github.com/grupootg/go-ws-template/internal/config"
	"github.com/grupootg/go-ws-template/internal/hub"
	"github.com/grupootg/go-ws-template/internal/metrics"
	"github.com/grupootg/go-ws-template/internal/transport"
)

func main() {
	log := slog.New(slog.NewJSONHandler(os.Stdout, nil))

	cfg, err := config.Load()
	if err != nil {
		log.Error("configuração inválida", "err", err)
		os.Exit(1)
	}

	if limit := setupMemoryLimit(); limit > 0 {
		log.Info("GOMEMLIMIT automático aplicado", "bytes", limit)
	}

	mode, _ := hub.ParseMode(cfg.DeliveryMode)
	reg := metrics.NewRegistry()
	h := hub.New(cfg.Topics, hub.Options{
		Mode:              mode,
		BufferSize:        cfg.ClientBuffer,
		MaxSubscriptions:  cfg.MaxSubscriptions,
		SnapshotOnConnect: cfg.SnapshotOnConnect,
		FanoutChunk:       cfg.FanoutChunk,
		FanoutWorkers:     cfg.FanoutWorkers,
		SlowMaxDrops:      cfg.SlowMaxDrops,
		SlowWindow:        cfg.SlowWindow,
	}, reg)

	var b broker.Broker
	switch cfg.BrokerKind {
	case "redis":
		b, err = redisbroker.New(cfg.RedisAddr, cfg.RedisPrefix)
		if err != nil {
			log.Error("falha ao conectar no Redis", "addr", cfg.RedisAddr, "err", err)
			os.Exit(1)
		}
	case "memory":
		b = broker.NewMemory()
		log.Warn("broker em memória: apenas para desenvolvimento/teste")
	}
	defer b.Close()

	srv := transport.New(transport.Options{
		Cfg:    cfg,
		Hub:    h,
		Broker: b,
		Reg:    reg,
		Logger: log,
	})

	// SIGTERM (deploy/scale-in) e SIGINT iniciam o drain gracioso.
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	if err := srv.Run(ctx, reg); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Error("servidor encerrou com erro", "err", err)
		os.Exit(1)
	}
	log.Info("servidor encerrado")
}
