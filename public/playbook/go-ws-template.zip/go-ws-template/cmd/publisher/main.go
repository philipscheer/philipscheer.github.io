// publisher publica eventos de teste no broker com envelope (seq + timestamp
// e, opcionalmente, chave de entidade) — simula a dataloader. Use junto do
// cmd/loadtest para medir idade de ponta a ponta, inclusive cenários de super
// spike (rajadas com -burst).
//
// Exemplos:
//
//	go run ./cmd/publisher -topic events -rate 50 -size 256
//	go run ./cmd/publisher -topic events -rate 20 -burst 500 -burst-every 10s
//	go run ./cmd/publisher -topic events -rate 50 -keys 20   # 20 entidades (keyed coalescing)
package main

import (
	"context"
	"crypto/rand"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/grupootg/go-ws-template/internal/broker/redisbroker"
	"github.com/grupootg/go-ws-template/internal/envelope"
)

func main() {
	var (
		redisAddr  = flag.String("redis", "localhost:6379", "endereço do Redis")
		prefix     = flag.String("prefix", "", "prefixo dos canais Redis")
		topic      = flag.String("topic", "events", "tópico de publicação")
		rate       = flag.Int("rate", 10, "mensagens por segundo (regime estável)")
		size       = flag.Int("size", 256, "tamanho do payload em bytes")
		keys       = flag.Int("keys", 0, "nº de chaves de entidade (0 = sem chave; >0 alterna match:0..N-1)")
		burst      = flag.Int("burst", 0, "mensagens extras por rajada (simula super spike)")
		burstEvery = flag.Duration("burst-every", 10*time.Second, "intervalo entre rajadas")
		duration   = flag.Duration("duration", 0, "duração total (0 = até Ctrl+C)")
	)
	flag.Parse()

	b, err := redisbroker.New(*redisAddr, *prefix)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer b.Close()

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	if *duration > 0 {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, *duration)
		defer cancel()
	}

	payload := make([]byte, *size)
	_, _ = rand.Read(payload)

	var seq uint64
	publish := func() {
		seq++
		var msg []byte
		if *keys > 0 {
			key := fmt.Sprintf("match:%d", seq%uint64(*keys))
			msg, _ = envelope.EncodeKeyed(nil, seq, time.Now(), key, payload)
		} else {
			msg = envelope.Encode(nil, seq, time.Now(), payload)
		}
		if err := b.Publish(ctx, *topic, msg); err != nil && ctx.Err() == nil {
			fmt.Fprintln(os.Stderr, "publish:", err)
		}
	}

	ticker := time.NewTicker(time.Second / time.Duration(max(*rate, 1)))
	defer ticker.Stop()

	var burstTicker <-chan time.Time
	if *burst > 0 {
		t := time.NewTicker(*burstEvery)
		defer t.Stop()
		burstTicker = t.C
	}

	fmt.Printf("publicando em %q: %d msg/s, payload %dB", *topic, *rate, *size)
	if *keys > 0 {
		fmt.Printf(", %d chaves", *keys)
	}
	if *burst > 0 {
		fmt.Printf(", rajada de %d a cada %s", *burst, *burstEvery)
	}
	fmt.Println()

	report := time.NewTicker(5 * time.Second)
	defer report.Stop()

	for {
		select {
		case <-ctx.Done():
			fmt.Printf("\ntotal publicado: %d mensagens\n", seq)
			return
		case <-ticker.C:
			publish()
		case <-burstTicker:
			start := time.Now()
			for i := 0; i < *burst; i++ {
				publish()
			}
			fmt.Printf("rajada de %d mensagens em %s\n", *burst, time.Since(start))
		case <-report.C:
			fmt.Printf("publicadas: %d\n", seq)
		}
	}
}
