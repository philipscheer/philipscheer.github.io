// Package auth implementa verificação de JWT HS256 com a stdlib (sem
// dependências). Suficiente para autenticar o upgrade WebSocket; claims podem
// restringir os canais autorizados.
//
// Claims reconhecidas:
//
//	exp      (obrigatória) — expiração Unix seconds
//	sub      (opcional)    — identificador do cliente
//	channels (opcional)    — lista de canais autorizados; vazia = todos
package auth

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"strings"
	"time"
)

var (
	ErrMalformed = errors.New("auth: token malformado")
	ErrAlg       = errors.New("auth: algoritmo não suportado (esperado HS256)")
	ErrSignature = errors.New("auth: assinatura inválida")
	ErrExpired   = errors.New("auth: token expirado ou sem exp")
)

type Claims struct {
	Sub      string   `json:"sub"`
	Exp      int64    `json:"exp"`
	Channels []string `json:"channels"`
}

// AllowsChannel informa se as claims autorizam o canal (lista vazia = todos).
func (c Claims) AllowsChannel(channel string) bool {
	if len(c.Channels) == 0 {
		return true
	}
	for _, ch := range c.Channels {
		if ch == channel {
			return true
		}
	}
	return false
}

type Verifier struct {
	secret []byte
}

func NewHS256(secret string) *Verifier {
	return &Verifier{secret: []byte(secret)}
}

// Verify valida assinatura e expiração e retorna as claims.
func (v *Verifier) Verify(token string, now time.Time) (Claims, error) {
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return Claims{}, ErrMalformed
	}

	headerJSON, err := base64.RawURLEncoding.DecodeString(parts[0])
	if err != nil {
		return Claims{}, ErrMalformed
	}
	var header struct {
		Alg string `json:"alg"`
	}
	if err := json.Unmarshal(headerJSON, &header); err != nil {
		return Claims{}, ErrMalformed
	}
	if header.Alg != "HS256" {
		return Claims{}, ErrAlg
	}

	mac := hmac.New(sha256.New, v.secret)
	mac.Write([]byte(parts[0] + "." + parts[1]))
	want := mac.Sum(nil)
	got, err := base64.RawURLEncoding.DecodeString(parts[2])
	if err != nil || !hmac.Equal(want, got) {
		return Claims{}, ErrSignature
	}

	payloadJSON, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return Claims{}, ErrMalformed
	}
	var claims Claims
	if err := json.Unmarshal(payloadJSON, &claims); err != nil {
		return Claims{}, ErrMalformed
	}
	if claims.Exp == 0 || now.Unix() >= claims.Exp {
		return Claims{}, ErrExpired
	}
	return claims, nil
}

// Sign gera um token HS256 (para testes e tooling interno).
func Sign(secret string, claims Claims) string {
	header := base64.RawURLEncoding.EncodeToString([]byte(`{"alg":"HS256","typ":"JWT"}`))
	payloadJSON, _ := json.Marshal(claims)
	payload := base64.RawURLEncoding.EncodeToString(payloadJSON)
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(header + "." + payload))
	sig := base64.RawURLEncoding.EncodeToString(mac.Sum(nil))
	return header + "." + payload + "." + sig
}
