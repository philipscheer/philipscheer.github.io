package auth

import (
	"strings"
	"testing"
	"time"
)

const secret = "test-secret"

func TestVerifyValidToken(t *testing.T) {
	now := time.Now()
	token := Sign(secret, Claims{Sub: "user-1", Exp: now.Add(time.Hour).Unix(), Channels: []string{"odds-pt"}})

	claims, err := NewHS256(secret).Verify(token, now)
	if err != nil {
		t.Fatal(err)
	}
	if claims.Sub != "user-1" {
		t.Fatalf("sub divergente: %q", claims.Sub)
	}
	if !claims.AllowsChannel("odds-pt") {
		t.Fatal("canal autorizado negado")
	}
	if claims.AllowsChannel("outro") {
		t.Fatal("canal não autorizado aceito")
	}
}

func TestEmptyChannelsAllowsAll(t *testing.T) {
	c := Claims{}
	if !c.AllowsChannel("qualquer") {
		t.Fatal("claims sem channels deveria autorizar todos os canais")
	}
}

func TestVerifyRejects(t *testing.T) {
	now := time.Now()
	valid := Sign(secret, Claims{Exp: now.Add(time.Hour).Unix()})
	v := NewHS256(secret)

	cases := []struct {
		name  string
		token string
		want  error
	}{
		{"malformado", "abc.def", ErrMalformed},
		{"assinatura errada", Sign("outro-secret", Claims{Exp: now.Add(time.Hour).Unix()}), ErrSignature},
		{"expirado", Sign(secret, Claims{Exp: now.Add(-time.Hour).Unix()}), ErrExpired},
		{"sem exp", Sign(secret, Claims{}), ErrExpired},
		{"corpo adulterado", tamper(valid), ErrSignature},
	}
	for _, c := range cases {
		if _, err := v.Verify(c.token, now); err != c.want {
			t.Fatalf("%s: esperava %v, obtido %v", c.name, c.want, err)
		}
	}
}

func TestRejectsAlgNone(t *testing.T) {
	// header {"alg":"none"} — ataque clássico; precisa ser rejeitado
	header := "eyJhbGciOiJub25lIn0" // base64url de {"alg":"none"}
	token := header + ".e30."
	if _, err := NewHS256(secret).Verify(token, time.Now()); err != ErrAlg {
		t.Fatalf("esperava ErrAlg, obtido %v", err)
	}
}

func tamper(token string) string {
	parts := strings.Split(token, ".")
	last := parts[1][len(parts[1])-1]
	repl := byte('A')
	if last == 'A' {
		repl = 'B' // garante que o payload sempre muda
	}
	parts[1] = parts[1][:len(parts[1])-1] + string(repl)
	return strings.Join(parts, ".")
}
