// Package config carrega a configuração do servidor a partir de variáveis
// de ambiente (12-factor). Sem dependências externas.
package config

import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

type Config struct {
	Port           string
	Topics         []string
	MaxConnections int64
	AllowedOrigins []string

	DeliveryMode      string // "coalesce" | "coalesce-keyed" | "buffer"
	ClientBuffer      int
	MaxSubscriptions  int
	SnapshotOnConnect bool

	PingInterval time.Duration
	PongTimeout  time.Duration
	WriteTimeout time.Duration
	ReadLimit    int64

	DrainTimeout time.Duration
	DrainJitter  time.Duration

	// Performance
	Compression   bool // permessage-deflate
	FanoutChunk   int  // fatia do fan-out paralelo intra-canal
	FanoutWorkers int  // 0 = GOMAXPROCS

	// Proteções
	SlowMaxDrops int64 // drops na janela p/ desconectar cliente lento (0 = off)
	SlowWindow   time.Duration
	UpgradeRate  float64 // upgrades/s aceitos (0 = sem limite)
	UpgradeBurst float64

	// Segurança
	AuthSecret string // JWT HS256; vazio = sem autenticação

	// Observabilidade
	DebugPort string // pprof; vazio = desabilitado

	BrokerKind  string // "redis" | "memory"
	RedisAddr   string
	RedisPrefix string
}

func Load() (*Config, error) {
	cfg := &Config{
		Port:           envStr("WS_PORT", "8080"),
		Topics:         envList("WS_TOPICS", "events"),
		MaxConnections: int64(envInt("WS_MAX_CONNECTIONS", 50000)),
		AllowedOrigins: envList("WS_ALLOWED_ORIGINS", "*"),

		DeliveryMode:      envStr("WS_DELIVERY_MODE", "coalesce"),
		ClientBuffer:      envInt("WS_CLIENT_BUFFER", 64),
		MaxSubscriptions:  envInt("WS_MAX_SUBSCRIPTIONS", 16),
		SnapshotOnConnect: envBool("WS_SNAPSHOT_ON_CONNECT", true),

		PingInterval: envDur("WS_PING_INTERVAL", 25*time.Second),
		PongTimeout:  envDur("WS_PONG_TIMEOUT", 60*time.Second),
		WriteTimeout: envDur("WS_WRITE_TIMEOUT", 10*time.Second),
		ReadLimit:    int64(envInt("WS_READ_LIMIT", 1024)),

		DrainTimeout: envDur("WS_DRAIN_TIMEOUT", 30*time.Second),
		DrainJitter:  envDur("WS_DRAIN_JITTER", 5*time.Second),

		Compression:   envBool("WS_COMPRESSION", false),
		FanoutChunk:   envInt("WS_FANOUT_CHUNK", 4096),
		FanoutWorkers: envInt("WS_FANOUT_WORKERS", 0),

		SlowMaxDrops: int64(envInt("WS_SLOW_MAX_DROPS", 1000)),
		SlowWindow:   envDur("WS_SLOW_WINDOW", 10*time.Second),
		UpgradeRate:  envFloat("WS_UPGRADE_RATE", 0),
		UpgradeBurst: envFloat("WS_UPGRADE_BURST", 2000),

		AuthSecret: envStr("WS_AUTH_SECRET", ""),
		DebugPort:  envStr("WS_DEBUG_PORT", ""),

		BrokerKind:  envStr("BROKER_KIND", "redis"),
		RedisAddr:   envStr("REDIS_ADDR", "localhost:6379"),
		RedisPrefix: envStr("REDIS_CHANNEL_PREFIX", ""),
	}
	return cfg, cfg.validate()
}

func (c *Config) validate() error {
	if len(c.Topics) == 0 {
		return fmt.Errorf("config: WS_TOPICS não pode ser vazio")
	}
	switch c.DeliveryMode {
	case "coalesce", "coalesce-keyed", "buffer":
	default:
		return fmt.Errorf("config: WS_DELIVERY_MODE inválido %q (use coalesce|coalesce-keyed|buffer)", c.DeliveryMode)
	}
	switch c.BrokerKind {
	case "redis", "memory":
	default:
		return fmt.Errorf("config: BROKER_KIND inválido %q (use redis|memory)", c.BrokerKind)
	}
	if c.ClientBuffer < 1 {
		return fmt.Errorf("config: WS_CLIENT_BUFFER deve ser >= 1")
	}
	if c.MaxSubscriptions < 1 {
		return fmt.Errorf("config: WS_MAX_SUBSCRIPTIONS deve ser >= 1")
	}
	if c.MaxConnections < 1 {
		return fmt.Errorf("config: WS_MAX_CONNECTIONS deve ser >= 1")
	}
	if c.PingInterval >= c.PongTimeout {
		return fmt.Errorf("config: WS_PING_INTERVAL (%s) deve ser menor que WS_PONG_TIMEOUT (%s)",
			c.PingInterval, c.PongTimeout)
	}
	if c.SlowMaxDrops > 0 && c.SlowWindow <= 0 {
		return fmt.Errorf("config: WS_SLOW_WINDOW deve ser > 0 quando WS_SLOW_MAX_DROPS está ativo")
	}
	return nil
}

func envStr(key, def string) string {
	if v := strings.TrimSpace(os.Getenv(key)); v != "" {
		return v
	}
	return def
}

func envInt(key string, def int) int {
	v := strings.TrimSpace(os.Getenv(key))
	if v == "" {
		return def
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return def
	}
	return n
}

func envFloat(key string, def float64) float64 {
	v := strings.TrimSpace(os.Getenv(key))
	if v == "" {
		return def
	}
	f, err := strconv.ParseFloat(v, 64)
	if err != nil {
		return def
	}
	return f
}

func envBool(key string, def bool) bool {
	v := strings.ToLower(strings.TrimSpace(os.Getenv(key)))
	if v == "" {
		return def
	}
	switch v {
	case "1", "true", "yes", "on":
		return true
	case "0", "false", "no", "off":
		return false
	}
	return def
}

func envDur(key string, def time.Duration) time.Duration {
	v := strings.TrimSpace(os.Getenv(key))
	if v == "" {
		return def
	}
	d, err := time.ParseDuration(v)
	if err != nil {
		return def
	}
	return d
}

func envList(key, def string) []string {
	v := strings.TrimSpace(os.Getenv(key))
	if v == "" {
		v = def
	}
	parts := strings.Split(v, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		if p = strings.TrimSpace(p); p != "" {
			out = append(out, p)
		}
	}
	return out
}
