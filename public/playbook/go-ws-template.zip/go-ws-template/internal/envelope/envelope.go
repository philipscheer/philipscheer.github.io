// Package envelope define o cabeçalho binário das mensagens (seq + timestamp
// de publicação + extensões opcionais). É ele que torna a "idade da mensagem"
// mensurável de ponta a ponta — a defesa contra a degradação invisível do
// super spike (ADR-0005) — e que carrega canal/chave para multiplexação e
// keyed coalescing (ADR-0007/0008).
//
// Layout (big-endian, 20 bytes + extensões + payload):
//
//	[0:2]   magic 0x5753 ("WS")
//	[2]     versão (1)
//	[3]     flags: bit0 (0x01) = extensão de chave; bit1 (0x02) = extensão de canal
//	[4:12]  seq (uint64)
//	[12:20] publish timestamp em microssegundos Unix (int64; 0 = desconhecido)
//	-- se flag canal:  [1B len][canal]   (servidor→cliente: sempre presente)
//	-- se flag chave:  [1B len][chave]   (produtor→servidor: entidade p/ keyed coalescing)
//	[...]   payload (opaco: protobuf, JSON, etc.)
//
// Produtores usam Encode/EncodeKeyed. O servidor reescreve o frame de saída
// com a extensão de canal via EncodeWire.
package envelope

import (
	"encoding/binary"
	"errors"
	"time"
)

const (
	HeaderSize = 20
	Version    = byte(1)

	FlagKey     = byte(0x01)
	FlagChannel = byte(0x02)

	// MaxExtLen é o tamanho máximo de canal/chave (cabem em 1 byte de length).
	MaxExtLen = 255

	magic = uint16(0x5753) // "WS"
)

var (
	ErrInvalid    = errors.New("envelope: cabeçalho inválido")
	ErrExtTooLong = errors.New("envelope: canal/chave excede 255 bytes")
)

type Envelope struct {
	Seq             uint64
	PublishedMicros int64  // UnixMicro do publish; 0 = desconhecido
	Channel         string // "" = ausente
	Key             string // "" = ausente (chave de entidade p/ keyed coalescing)
	Payload         []byte
}

// Published retorna o timestamp de publicação (zero time se desconhecido).
func (e Envelope) Published() time.Time {
	if e.PublishedMicros == 0 {
		return time.Time{}
	}
	return time.UnixMicro(e.PublishedMicros)
}

// Age retorna a idade da mensagem em relação a now (0 se desconhecida).
func (e Envelope) Age(now time.Time) time.Duration {
	if e.PublishedMicros == 0 {
		return 0
	}
	return now.Sub(time.UnixMicro(e.PublishedMicros))
}

// Encode monta o frame de produtor simples (sem extensões), anexando a dst.
// Passe dst=nil para alocar exato.
func Encode(dst []byte, seq uint64, published time.Time, payload []byte) []byte {
	out, _ := EncodeWire(dst, Envelope{
		Seq:             seq,
		PublishedMicros: published.UnixMicro(),
		Payload:         payload,
	})
	return out
}

// EncodeKeyed monta o frame de produtor com chave de entidade (keyed
// coalescing — ADR-0008).
func EncodeKeyed(dst []byte, seq uint64, published time.Time, key string, payload []byte) ([]byte, error) {
	return EncodeWire(dst, Envelope{
		Seq:             seq,
		PublishedMicros: published.UnixMicro(),
		Key:             key,
		Payload:         payload,
	})
}

// EncodeWire serializa o envelope completo (com as extensões presentes),
// anexando a dst. É o formato servidor→cliente (canal sempre presente).
func EncodeWire(dst []byte, e Envelope) ([]byte, error) {
	if len(e.Channel) > MaxExtLen || len(e.Key) > MaxExtLen {
		return nil, ErrExtTooLong
	}
	var flags byte
	extLen := 0
	if e.Channel != "" {
		flags |= FlagChannel
		extLen += 1 + len(e.Channel)
	}
	if e.Key != "" {
		flags |= FlagKey
		extLen += 1 + len(e.Key)
	}

	var h [HeaderSize]byte
	binary.BigEndian.PutUint16(h[0:2], magic)
	h[2] = Version
	h[3] = flags
	binary.BigEndian.PutUint64(h[4:12], e.Seq)
	binary.BigEndian.PutUint64(h[12:20], uint64(e.PublishedMicros))

	if dst == nil {
		dst = make([]byte, 0, HeaderSize+extLen+len(e.Payload))
	}
	dst = append(dst, h[:]...)
	if e.Channel != "" {
		dst = append(dst, byte(len(e.Channel)))
		dst = append(dst, e.Channel...)
	}
	if e.Key != "" {
		dst = append(dst, byte(len(e.Key)))
		dst = append(dst, e.Key...)
	}
	return append(dst, e.Payload...), nil
}

// Decode interpreta cabeçalho e extensões. Payload/Channel/Key referenciam o
// slice de entrada (zero-copy).
func Decode(b []byte) (Envelope, error) {
	if len(b) < HeaderSize ||
		binary.BigEndian.Uint16(b[0:2]) != magic ||
		b[2] != Version {
		return Envelope{}, ErrInvalid
	}
	e := Envelope{
		Seq:             binary.BigEndian.Uint64(b[4:12]),
		PublishedMicros: int64(binary.BigEndian.Uint64(b[12:20])),
	}
	flags := b[3]
	rest := b[HeaderSize:]

	if flags&FlagChannel != 0 {
		var s string
		var err error
		s, rest, err = readExt(rest)
		if err != nil {
			return Envelope{}, err
		}
		e.Channel = s
	}
	if flags&FlagKey != 0 {
		var s string
		var err error
		s, rest, err = readExt(rest)
		if err != nil {
			return Envelope{}, err
		}
		e.Key = s
	}
	e.Payload = rest
	return e, nil
}

func readExt(b []byte) (string, []byte, error) {
	if len(b) < 1 {
		return "", nil, ErrInvalid
	}
	n := int(b[0])
	if len(b) < 1+n {
		return "", nil, ErrInvalid
	}
	return string(b[1 : 1+n]), b[1+n:], nil
}
