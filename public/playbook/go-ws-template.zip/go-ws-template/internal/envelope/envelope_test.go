package envelope

import (
	"bytes"
	"strings"
	"testing"
	"time"
)

func TestEncodeDecodeRoundTrip(t *testing.T) {
	pub := time.Now().Add(-150 * time.Millisecond)
	payload := []byte(`{"odd":1.95}`)

	b := Encode(nil, 42, pub, payload)
	if len(b) != HeaderSize+len(payload) {
		t.Fatalf("tamanho esperado %d, obtido %d", HeaderSize+len(payload), len(b))
	}

	env, err := Decode(b)
	if err != nil {
		t.Fatal(err)
	}
	if env.Seq != 42 {
		t.Fatalf("seq esperado 42, obtido %d", env.Seq)
	}
	if env.Channel != "" || env.Key != "" {
		t.Fatalf("frame simples não deveria ter extensões: %q %q", env.Channel, env.Key)
	}
	if !bytes.Equal(env.Payload, payload) {
		t.Fatalf("payload divergente")
	}
	if env.Published().UnixMicro() != pub.UnixMicro() {
		t.Fatalf("timestamp divergente: %v != %v", env.Published(), pub)
	}
	if age := env.Age(time.Now()); age < 100*time.Millisecond || age > 5*time.Second {
		t.Fatalf("idade fora do esperado: %v", age)
	}
}

func TestEncodeWireWithExtensions(t *testing.T) {
	pub := time.Now()
	payload := []byte("xyz")

	wire, err := EncodeWire(nil, Envelope{
		Seq:             7,
		PublishedMicros: pub.UnixMicro(),
		Channel:         "odds-pt",
		Key:             "match:123",
		Payload:         payload,
	})
	if err != nil {
		t.Fatal(err)
	}

	wantLen := HeaderSize + 1 + len("odds-pt") + 1 + len("match:123") + len(payload)
	if len(wire) != wantLen {
		t.Fatalf("tamanho esperado %d, obtido %d", wantLen, len(wire))
	}

	env, err := Decode(wire)
	if err != nil {
		t.Fatal(err)
	}
	if env.Channel != "odds-pt" {
		t.Fatalf("canal esperado odds-pt, obtido %q", env.Channel)
	}
	if env.Key != "match:123" {
		t.Fatalf("chave esperada match:123, obtida %q", env.Key)
	}
	if !bytes.Equal(env.Payload, payload) {
		t.Fatalf("payload divergente: %q", env.Payload)
	}
}

func TestEncodeKeyed(t *testing.T) {
	wire, err := EncodeKeyed(nil, 1, time.Now(), "match:9", []byte("p"))
	if err != nil {
		t.Fatal(err)
	}
	env, err := Decode(wire)
	if err != nil {
		t.Fatal(err)
	}
	if env.Key != "match:9" || env.Channel != "" {
		t.Fatalf("extensões inesperadas: key=%q channel=%q", env.Key, env.Channel)
	}
}

func TestUnknownPublishedIsZero(t *testing.T) {
	wire, _ := EncodeWire(nil, Envelope{Seq: 1, Channel: "a", Payload: []byte("p")})
	env, err := Decode(wire)
	if err != nil {
		t.Fatal(err)
	}
	if env.PublishedMicros != 0 {
		t.Fatalf("esperava PublishedMicros=0, obtido %d", env.PublishedMicros)
	}
	if !env.Published().IsZero() {
		t.Fatalf("Published deveria ser zero time")
	}
	if env.Age(time.Now()) != 0 {
		t.Fatalf("idade de timestamp desconhecido deve ser 0")
	}
}

func TestExtTooLong(t *testing.T) {
	long := strings.Repeat("x", MaxExtLen+1)
	if _, err := EncodeWire(nil, Envelope{Channel: long}); err != ErrExtTooLong {
		t.Fatalf("esperava ErrExtTooLong, obtido %v", err)
	}
	if _, err := EncodeKeyed(nil, 1, time.Now(), long, nil); err != ErrExtTooLong {
		t.Fatalf("esperava ErrExtTooLong, obtido %v", err)
	}
}

func TestDecodeInvalid(t *testing.T) {
	truncatedExt, _ := EncodeWire(nil, Envelope{Seq: 1, Channel: "abcdef", Payload: []byte("p")})
	cases := [][]byte{
		nil,
		{},
		[]byte("short"),
		Encode(nil, 1, time.Now(), nil)[1:],                 // magic corrompida
		append([]byte{0x57, 0x53, 99}, make([]byte, 17)...), // versão errada
		truncatedExt[:HeaderSize+3],                         // extensão truncada
	}
	for i, c := range cases {
		if _, err := Decode(c); err == nil {
			t.Fatalf("caso %d: esperava erro", i)
		}
	}
}

func TestEncodeAppendsToDst(t *testing.T) {
	dst := make([]byte, 0, 64)
	out := Encode(dst, 7, time.Now(), []byte("x"))
	if len(out) != HeaderSize+1 {
		t.Fatalf("tamanho inesperado %d", len(out))
	}
}

func BenchmarkEncodeWire(b *testing.B) {
	payload := make([]byte, 256)
	e := Envelope{Seq: 1, PublishedMicros: time.Now().UnixMicro(), Channel: "odds-pt", Payload: payload}
	buf := make([]byte, 0, HeaderSize+16+len(payload))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		e.Seq = uint64(i)
		buf, _ = EncodeWire(buf[:0], e)
	}
}

func BenchmarkDecode(b *testing.B) {
	msg, _ := EncodeWire(nil, Envelope{
		Seq: 1, PublishedMicros: time.Now().UnixMicro(),
		Channel: "odds-pt", Key: "match:123", Payload: make([]byte, 256),
	})
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		if _, err := Decode(msg); err != nil {
			b.Fatal(err)
		}
	}
}
