package ratelimit

import (
	"testing"
	"time"
)

func TestDisabledAlwaysAllows(t *testing.T) {
	b := New(0, 0)
	for i := 0; i < 1000; i++ {
		if !b.Allow() {
			t.Fatal("bucket desabilitado deveria sempre permitir")
		}
	}
	var nilBucket *Bucket
	if !nilBucket.Allow() {
		t.Fatal("bucket nil deveria sempre permitir")
	}
}

func TestBurstThenThrottle(t *testing.T) {
	b := New(10, 5)
	allowed := 0
	for i := 0; i < 20; i++ {
		if b.Allow() {
			allowed++
		}
	}
	if allowed < 5 || allowed > 6 {
		t.Fatalf("esperava ~5 permitidos no burst, obtido %d", allowed)
	}
}

func TestRefill(t *testing.T) {
	b := New(100, 1)
	if !b.Allow() {
		t.Fatal("primeiro pedido deveria passar")
	}
	if b.Allow() {
		t.Fatal("bucket deveria estar vazio")
	}
	time.Sleep(30 * time.Millisecond) // ~3 tokens a 100/s (cap 1)
	if !b.Allow() {
		t.Fatal("bucket deveria ter recarregado")
	}
}
