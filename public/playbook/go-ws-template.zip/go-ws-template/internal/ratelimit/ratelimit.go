// Package ratelimit implementa um token bucket simples para limitar a taxa de
// upgrades (proteção anti accept-storm pós-deploy/failover). Não fica no hot
// path de mensagens — mutex é suficiente.
package ratelimit

import (
	"sync"
	"time"
)

type Bucket struct {
	mu     sync.Mutex
	rate   float64 // tokens por segundo
	burst  float64
	tokens float64
	last   time.Time
}

// New cria um bucket com rate tokens/s e capacidade burst.
// rate <= 0 desabilita o limite (Allow sempre true).
func New(rate, burst float64) *Bucket {
	if burst < 1 {
		burst = 1
	}
	return &Bucket{rate: rate, burst: burst, tokens: burst, last: time.Now()}
}

func (b *Bucket) Allow() bool {
	if b == nil || b.rate <= 0 {
		return true
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	now := time.Now()
	b.tokens += now.Sub(b.last).Seconds() * b.rate
	if b.tokens > b.burst {
		b.tokens = b.burst
	}
	b.last = now
	if b.tokens >= 1 {
		b.tokens--
		return true
	}
	return false
}
