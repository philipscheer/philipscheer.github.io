//go:build integration

// Teste de integração ponta a ponta: broker → ingest → hub → WebSocket real
// (gorilla server+client), cobrindo o protocolo de assinatura multiplexada,
// envelope wire, snapshot-on-connect e autenticação.
//
// Rode com: go test -race -tags integration ./internal/transport/
package transport

import (
	"context"
	"encoding/json"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/gorilla/websocket"

	"github.com/grupootg/go-ws-template/internal/auth"
	"github.com/grupootg/go-ws-template/internal/broker"
	"github.com/grupootg/go-ws-template/internal/config"
	"github.com/grupootg/go-ws-template/internal/envelope"
	"github.com/grupootg/go-ws-template/internal/hub"
	"github.com/grupootg/go-ws-template/internal/metrics"
)

type testStack struct {
	srv    *Server
	broker *broker.Memory
	http   *httptest.Server
	cancel context.CancelFunc
}

func newStack(t *testing.T, mutate func(*config.Config)) *testStack {
	t.Helper()
	cfg := &config.Config{
		Port:              "0",
		Topics:            []string{"alpha", "beta"},
		MaxConnections:    100,
		AllowedOrigins:    []string{"*"},
		DeliveryMode:      "coalesce",
		ClientBuffer:      16,
		MaxSubscriptions:  4,
		SnapshotOnConnect: true,
		PingInterval:      20 * time.Second,
		PongTimeout:       45 * time.Second,
		WriteTimeout:      5 * time.Second,
		ReadLimit:         1024,
		DrainTimeout:      2 * time.Second,
		DrainJitter:       10 * time.Millisecond,
		FanoutChunk:       4096,
		SlowWindow:        10 * time.Second,
		BrokerKind:        "memory",
	}
	if mutate != nil {
		mutate(cfg)
	}

	mode, _ := hub.ParseMode(cfg.DeliveryMode)
	reg := metrics.NewRegistry()
	h := hub.New(cfg.Topics, hub.Options{
		Mode:              mode,
		BufferSize:        cfg.ClientBuffer,
		MaxSubscriptions:  cfg.MaxSubscriptions,
		SnapshotOnConnect: cfg.SnapshotOnConnect,
		FanoutChunk:       cfg.FanoutChunk,
		SlowMaxDrops:      cfg.SlowMaxDrops,
		SlowWindow:        cfg.SlowWindow,
	}, reg)

	mem := broker.NewMemory()
	s := New(Options{
		Cfg:    cfg,
		Hub:    h,
		Broker: mem,
		Reg:    reg,
		Logger: slog.New(slog.NewTextHandler(testWriter{t}, nil)),
	})

	ctx, cancel := context.WithCancel(context.Background())
	if err := s.runIngest(ctx); err != nil {
		cancel()
		t.Fatal(err)
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/ws", s.handleWS)
	ts := httptest.NewServer(mux)

	st := &testStack{srv: s, broker: mem, http: ts, cancel: cancel}
	t.Cleanup(func() {
		ts.Close()
		cancel()
		_ = mem.Close()
	})
	return st
}

type testWriter struct{ t *testing.T }

func (w testWriter) Write(p []byte) (int, error) {
	w.t.Log(strings.TrimSpace(string(p)))
	return len(p), nil
}

func (st *testStack) wsURL(query string) string {
	u := "ws" + strings.TrimPrefix(st.http.URL, "http") + "/ws"
	if query != "" {
		u += "?" + query
	}
	return u
}

func dial(t *testing.T, url string, header http.Header) *websocket.Conn {
	t.Helper()
	conn, _, err := websocket.DefaultDialer.Dial(url, header)
	if err != nil {
		t.Fatalf("dial %s: %v", url, err)
	}
	t.Cleanup(func() { _ = conn.Close() })
	return conn
}

// readUntilBinary lê frames até achar um BINARY (acks TEXT são acumulados).
func readUntilBinary(t *testing.T, conn *websocket.Conn, timeout time.Duration) (envelope.Envelope, []string) {
	t.Helper()
	var acks []string
	_ = conn.SetReadDeadline(time.Now().Add(timeout))
	for {
		msgType, data, err := conn.ReadMessage()
		if err != nil {
			t.Fatalf("read: %v (acks até aqui: %v)", err, acks)
		}
		if msgType == websocket.TextMessage {
			acks = append(acks, string(data))
			continue
		}
		env, err := envelope.Decode(data)
		if err != nil {
			t.Fatalf("frame binário sem envelope válido: %v", err)
		}
		return env, acks
	}
}

func readAck(t *testing.T, conn *websocket.Conn, timeout time.Duration) controlAck {
	t.Helper()
	_ = conn.SetReadDeadline(time.Now().Add(timeout))
	for {
		msgType, data, err := conn.ReadMessage()
		if err != nil {
			t.Fatalf("read ack: %v", err)
		}
		if msgType != websocket.TextMessage {
			continue
		}
		var ack controlAck
		if err := json.Unmarshal(data, &ack); err != nil {
			t.Fatalf("ack inválido: %v", err)
		}
		return ack
	}
}

func TestEndToEndPublishSubscribe(t *testing.T) {
	st := newStack(t, nil)
	conn := dial(t, st.wsURL("channels=alpha"), nil)

	// publish após a conexão estar assinada
	msg := envelope.Encode(nil, 1, time.Now(), []byte("hello"))
	if err := st.broker.Publish(context.Background(), "alpha", msg); err != nil {
		t.Fatal(err)
	}

	env, _ := readUntilBinary(t, conn, 3*time.Second)
	if env.Channel != "alpha" {
		t.Fatalf("canal esperado alpha, obtido %q", env.Channel)
	}
	if string(env.Payload) != "hello" {
		t.Fatalf("payload divergente: %q", env.Payload)
	}
	if env.Age(time.Now()) <= 0 || env.Age(time.Now()) > 3*time.Second {
		t.Fatalf("idade implausível: %v", env.Age(time.Now()))
	}
}

func TestMultiplexSubscribeUnsubscribe(t *testing.T) {
	st := newStack(t, nil)
	conn := dial(t, st.wsURL("channels=alpha"), nil)

	// assina beta dinamicamente
	sub, _ := json.Marshal(controlRequest{Action: "subscribe", Channels: []string{"beta"}})
	if err := conn.WriteMessage(websocket.TextMessage, sub); err != nil {
		t.Fatal(err)
	}

	// aguarda os dois acks (inicial + subscribe) antes de publicar
	for i := 0; i < 2; i++ {
		ack := readAck(t, conn, 2*time.Second)
		if ack.Type != "ack" {
			t.Fatalf("esperava ack, obtido %+v", ack)
		}
	}

	_ = st.broker.Publish(context.Background(), "beta", envelope.Encode(nil, 2, time.Now(), []byte("b")))
	env, _ := readUntilBinary(t, conn, 3*time.Second)
	if env.Channel != "beta" || string(env.Payload) != "b" {
		t.Fatalf("mensagem divergente: canal=%q payload=%q", env.Channel, env.Payload)
	}

	// cancela alpha; publica nos dois; só beta deve chegar
	unsub, _ := json.Marshal(controlRequest{Action: "unsubscribe", Channels: []string{"alpha"}})
	if err := conn.WriteMessage(websocket.TextMessage, unsub); err != nil {
		t.Fatal(err)
	}
	_ = readAck(t, conn, 2*time.Second)

	_ = st.broker.Publish(context.Background(), "alpha", envelope.Encode(nil, 3, time.Now(), []byte("a")))
	_ = st.broker.Publish(context.Background(), "beta", envelope.Encode(nil, 4, time.Now(), []byte("b2")))

	env, _ = readUntilBinary(t, conn, 3*time.Second)
	if env.Channel != "beta" || env.Seq != 4 {
		t.Fatalf("esperava beta seq=4, obtido canal=%q seq=%d", env.Channel, env.Seq)
	}
}

func TestSnapshotOnConnectE2E(t *testing.T) {
	st := newStack(t, nil)

	// publica ANTES de qualquer assinante (precisa de um assinante do broker
	// já ativo: o ingest do servidor assina no boot, então o estado fica no shard)
	_ = st.broker.Publish(context.Background(), "alpha", envelope.Encode(nil, 9, time.Now(), []byte("estado")))
	time.Sleep(100 * time.Millisecond) // ingest processa

	conn := dial(t, st.wsURL("channels=alpha"), nil)
	env, _ := readUntilBinary(t, conn, 3*time.Second)
	if env.Seq != 9 || string(env.Payload) != "estado" {
		t.Fatalf("snapshot-on-connect não entregou o último estado: seq=%d payload=%q", env.Seq, env.Payload)
	}
}

func TestKeyedCoalesceE2E(t *testing.T) {
	st := newStack(t, func(c *config.Config) { c.DeliveryMode = "coalesce-keyed" })

	_ = st.broker.Publish(context.Background(), "alpha", mustKeyed(t, 1, "m:A", []byte("a1")))
	_ = st.broker.Publish(context.Background(), "alpha", mustKeyed(t, 2, "m:B", []byte("b1")))
	_ = st.broker.Publish(context.Background(), "alpha", mustKeyed(t, 3, "m:A", []byte("a2")))
	time.Sleep(100 * time.Millisecond)

	conn := dial(t, st.wsURL("channels=alpha"), nil)
	byKey := map[string]envelope.Envelope{}
	for i := 0; i < 2; i++ {
		env, _ := readUntilBinary(t, conn, 3*time.Second)
		byKey[env.Key] = env
	}
	if string(byKey["m:A"].Payload) != "a2" {
		t.Fatalf("m:A deveria ter o estado mais recente, obtido %q", byKey["m:A"].Payload)
	}
	if string(byKey["m:B"].Payload) != "b1" {
		t.Fatalf("m:B divergente: %q", byKey["m:B"].Payload)
	}
}

func mustKeyed(t *testing.T, seq uint64, key string, payload []byte) []byte {
	t.Helper()
	b, err := envelope.EncodeKeyed(nil, seq, time.Now(), key, payload)
	if err != nil {
		t.Fatal(err)
	}
	return b
}

func TestAuthE2E(t *testing.T) {
	const secret = "integration-secret"
	st := newStack(t, func(c *config.Config) { c.AuthSecret = secret })

	// sem token → handshake falha (401)
	if _, resp, err := websocket.DefaultDialer.Dial(st.wsURL("channels=alpha"), nil); err == nil {
		t.Fatal("dial sem token deveria falhar")
	} else if resp == nil || resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("esperava 401, obtido %+v", resp)
	}

	// token restrito a alpha
	token := auth.Sign(secret, auth.Claims{
		Sub: "u1", Exp: time.Now().Add(time.Hour).Unix(), Channels: []string{"alpha"},
	})
	header := http.Header{"Authorization": []string{"Bearer " + token}}
	conn := dial(t, st.wsURL("channels=alpha"), header)

	// canal proibido via query → 403
	if _, resp, err := websocket.DefaultDialer.Dial(st.wsURL("channels=beta&token="+token), nil); err == nil {
		t.Fatal("canal proibido deveria falhar no handshake")
	} else if resp == nil || resp.StatusCode != http.StatusForbidden {
		t.Fatalf("esperava 403, obtido %+v", resp)
	}

	// canal proibido via control frame → ack com erro
	sub, _ := json.Marshal(controlRequest{Action: "subscribe", Channels: []string{"beta"}})
	_ = conn.WriteMessage(websocket.TextMessage, sub)
	sawForbidden := false
	for i := 0; i < 2; i++ {
		ack := readAck(t, conn, 2*time.Second)
		if ack.Errors["beta"] == "forbidden" {
			sawForbidden = true
		}
	}
	if !sawForbidden {
		t.Fatal("subscribe em canal proibido deveria retornar ack com erro 'forbidden'")
	}
}

func TestUnknownChannelHandshake(t *testing.T) {
	st := newStack(t, nil)
	if _, resp, err := websocket.DefaultDialer.Dial(st.wsURL("channels=nope"), nil); err == nil {
		t.Fatal("canal inexistente deveria falhar no handshake")
	} else if resp == nil || resp.StatusCode != http.StatusNotFound {
		t.Fatalf("esperava 404, obtido %+v", resp)
	}
}
