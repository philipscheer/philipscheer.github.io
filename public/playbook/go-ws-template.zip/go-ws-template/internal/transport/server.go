// Package transport liga HTTP/WebSocket (gorilla) ao hub: upgrade com
// limites, origin check, rate limit e autenticação; protocolo de assinatura
// multiplexada (ADR-0007); ingestão do broker com fan-out paralelo; métricas
// e graceful shutdown com drain.
package transport

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"net/http/pprof"
	"net/url"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/gorilla/websocket"

	"github.com/grupootg/go-ws-template/internal/auth"
	"github.com/grupootg/go-ws-template/internal/broker"
	"github.com/grupootg/go-ws-template/internal/config"
	"github.com/grupootg/go-ws-template/internal/envelope"
	"github.com/grupootg/go-ws-template/internal/hub"
	"github.com/grupootg/go-ws-template/internal/metrics"
	"github.com/grupootg/go-ws-template/internal/ratelimit"
)

type Options struct {
	Cfg    *config.Config
	Hub    *hub.Hub
	Broker broker.Broker
	Reg    *metrics.Registry
	Logger *slog.Logger
}

type Server struct {
	cfg      *config.Config
	hub      *hub.Hub
	broker   broker.Broker
	log      *slog.Logger
	upgrader websocket.Upgrader

	verifier *auth.Verifier    // nil = autenticação desabilitada
	bucket   *ratelimit.Bucket // nil/rate 0 = sem limite de upgrades

	draining atomic.Bool
	httpSrv  *http.Server

	// métricas
	rejectedFull    *metrics.Counter
	rateLimited     *metrics.Counter
	authRejected    *metrics.Counter
	upgradeErrors   *metrics.Counter
	invalidEnvelope *metrics.Counter
	ingested        *metrics.Counter
	ingestDropped   *metrics.Counter
	writeErrors     *metrics.Counter
	controlErrors   *metrics.Counter
	msgAge          map[string]*metrics.Histogram // por canal: idade publish→socket
}

func New(o Options) *Server {
	s := &Server{
		cfg:    o.Cfg,
		hub:    o.Hub,
		broker: o.Broker,
		log:    o.Logger,
		upgrader: websocket.Upgrader{
			ReadBufferSize:    1024,
			WriteBufferSize:   1024,
			WriteBufferPool:   &sync.Pool{},
			CheckOrigin:       originChecker(o.Cfg.AllowedOrigins),
			EnableCompression: o.Cfg.Compression,
		},
		rejectedFull: o.Reg.Counter("ws_rejected_full_total",
			"Conexões rejeitadas por limite de capacidade (503)", nil),
		rateLimited: o.Reg.Counter("ws_rate_limited_total",
			"Upgrades rejeitados pelo rate limit (429)", nil),
		authRejected: o.Reg.Counter("ws_auth_rejected_total",
			"Conexões/assinaturas rejeitadas por autenticação/autorização", nil),
		upgradeErrors: o.Reg.Counter("ws_upgrade_errors_total",
			"Falhas no upgrade HTTP→WS", nil),
		invalidEnvelope: o.Reg.Counter("ingest_invalid_envelope_total",
			"Eventos recebidos sem envelope válido (encaminhados mesmo assim)", nil),
		ingested: o.Reg.Counter("ingest_events_total",
			"Eventos recebidos do broker", nil),
		ingestDropped: o.Reg.Counter("ingest_dropped_total",
			"Eventos descartados na ingestão por worker de tópico saturado", nil),
		writeErrors: o.Reg.Counter("ws_write_errors_total",
			"Erros de escrita no socket (sessão derrubada)", nil),
		controlErrors: o.Reg.Counter("ws_control_errors_total",
			"Frames de controle inválidos recebidos de clientes", nil),
		msgAge: make(map[string]*metrics.Histogram, len(o.Cfg.Topics)),
	}
	for _, ch := range o.Cfg.Topics {
		s.msgAge[ch] = o.Reg.Histogram("ws_message_age_seconds",
			"Idade da mensagem do publish até a escrita no socket (super spike fica visível aqui)",
			metrics.Labels{"channel": ch}, metrics.DefaultLatencyBuckets())
	}
	if o.Cfg.AuthSecret != "" {
		s.verifier = auth.NewHS256(o.Cfg.AuthSecret)
	}
	if o.Cfg.UpgradeRate > 0 {
		s.bucket = ratelimit.New(o.Cfg.UpgradeRate, o.Cfg.UpgradeBurst)
	}
	registerRuntimeMetrics(o.Reg)
	return s
}

// Run sobe o servidor e bloqueia até ctx ser cancelado (SIGTERM) ou erro
// fatal. No cancelamento executa o drain gracioso.
func (s *Server) Run(ctx context.Context, reg *metrics.Registry) error {
	if err := s.runIngest(ctx); err != nil {
		return err
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/ws", s.handleWS)
	mux.HandleFunc("/healthz", s.handleHealthz)
	mux.Handle("/metrics", reg.Handler())

	s.httpSrv = &http.Server{
		Addr:              ":" + s.cfg.Port,
		Handler:           mux,
		ReadHeaderTimeout: 5 * time.Second,
	}

	if s.cfg.DebugPort != "" {
		go s.runDebugServer(ctx)
	}

	errCh := make(chan error, 1)
	go func() { errCh <- s.httpSrv.ListenAndServe() }()
	s.log.Info("servidor iniciado",
		"port", s.cfg.Port,
		"topics", strings.Join(s.cfg.Topics, ","),
		"max_connections", s.cfg.MaxConnections,
		"delivery_mode", s.cfg.DeliveryMode,
		"compression", s.cfg.Compression,
		"auth", s.verifier != nil,
	)

	select {
	case err := <-errCh:
		return err
	case <-ctx.Done():
	}

	// --- Graceful shutdown / connection draining ---
	s.draining.Store(true) // healthz passa a responder 503: o LB para de rotear
	conns := s.hub.Connections()
	s.log.Info("drenando conexões", "connections", conns, "jitter", s.cfg.DrainJitter.String())

	s.hub.CloseAll(s.cfg.DrainJitter) // close frames espalhados (sem thundering herd)

	deadline := time.Now().Add(s.cfg.DrainTimeout)
	for time.Now().Before(deadline) && s.hub.Connections() > 0 {
		time.Sleep(100 * time.Millisecond)
	}
	s.log.Info("drain concluído", "remaining", s.hub.Connections())

	shutCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := s.httpSrv.Shutdown(shutCtx); err != nil && !errors.Is(err, context.DeadlineExceeded) {
		return err
	}
	return nil
}

// runDebugServer expõe pprof em porta separada (NUNCA atrás do ALB público).
func (s *Server) runDebugServer(ctx context.Context) {
	mux := http.NewServeMux()
	mux.HandleFunc("/debug/pprof/", pprof.Index)
	mux.HandleFunc("/debug/pprof/cmdline", pprof.Cmdline)
	mux.HandleFunc("/debug/pprof/profile", pprof.Profile)
	mux.HandleFunc("/debug/pprof/symbol", pprof.Symbol)
	mux.HandleFunc("/debug/pprof/trace", pprof.Trace)
	srv := &http.Server{Addr: ":" + s.cfg.DebugPort, Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	go func() {
		<-ctx.Done()
		shutCtx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		_ = srv.Shutdown(shutCtx)
	}()
	s.log.Info("pprof habilitado", "port", s.cfg.DebugPort)
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		s.log.Warn("debug server encerrou", "err", err)
	}
}

// registerRuntimeMetrics expõe a saúde do runtime — sem isso, investigar um
// super spike real é adivinhação (IMPROVEMENTS §9).
func registerRuntimeMetrics(reg *metrics.Registry) {
	var mu sync.Mutex
	var last time.Time
	var ms runtime.MemStats
	read := func() *runtime.MemStats {
		mu.Lock()
		defer mu.Unlock()
		if time.Since(last) > time.Second {
			runtime.ReadMemStats(&ms)
			last = time.Now()
		}
		return &ms
	}
	reg.GaugeFunc("go_goroutines", "Número de goroutines", nil,
		func() int64 { return int64(runtime.NumGoroutine()) })
	reg.GaugeFunc("go_mem_heap_alloc_bytes", "Heap alocado (bytes)", nil,
		func() int64 { return int64(read().HeapAlloc) })
	reg.GaugeFunc("go_mem_heap_sys_bytes", "Heap reservado do SO (bytes)", nil,
		func() int64 { return int64(read().HeapSys) })
	reg.GaugeFunc("go_gc_cycles_total", "Ciclos de GC concluídos", nil,
		func() int64 { return int64(read().NumGC) })
	reg.GaugeFunc("go_gc_pause_total_ns", "Tempo total de pausa de GC (ns)", nil,
		func() int64 { return int64(read().PauseTotalNs) })
}

// runIngest assina o broker e despacha cada tópico para um worker próprio —
// fan-out de canais independentes acontece em paralelo (multi-core).
func (s *Server) runIngest(ctx context.Context) error {
	events, err := s.broker.Subscribe(ctx, s.cfg.Topics...)
	if err != nil {
		return err
	}

	workers := make(map[string]chan broker.Event, len(s.cfg.Topics))
	for _, topic := range s.cfg.Topics {
		ch := make(chan broker.Event, 1024)
		workers[topic] = ch
		go func(topic string, in <-chan broker.Event) {
			for ev := range in {
				s.dispatch(topic, ev.Payload)
			}
		}(topic, ch)
	}

	go func() {
		defer func() {
			for _, ch := range workers {
				close(ch)
			}
		}()
		for ev := range events {
			s.ingested.Inc()
			w, ok := workers[ev.Topic]
			if !ok {
				continue
			}
			// Nunca bloquear o dispatcher: worker de tópico saturado descarta
			// (latest-wins corrige no próximo update) em vez de atrasar os
			// demais tópicos.
			select {
			case w <- ev:
			default:
				s.ingestDropped.Inc()
			}
		}
	}()
	return nil
}

// dispatch reescreve o evento como frame wire (envelope + extensão de canal),
// prepara o frame WS 1× para N assinantes e dispara o broadcast.
func (s *Server) dispatch(topic string, payload []byte) {
	env, err := envelope.Decode(payload)
	if err != nil {
		s.invalidEnvelope.Inc()
		env = envelope.Envelope{Payload: payload}
	}
	env.Channel = topic

	wire, werr := envelope.EncodeWire(nil, env)
	if werr != nil {
		s.invalidEnvelope.Inc()
		return
	}

	out := &hub.Outgoing{
		Seq:             env.Seq,
		PublishedMicros: env.PublishedMicros,
		Key:             env.Key,
		Data:            wire,
	}
	if pm, err := websocket.NewPreparedMessage(websocket.BinaryMessage, wire); err == nil {
		out.Prepared = pm
	}

	_ = s.hub.Broadcast(topic, out)
}

func (s *Server) handleHealthz(w http.ResponseWriter, _ *http.Request) {
	if s.draining.Load() {
		http.Error(w, "draining", http.StatusServiceUnavailable)
		return
	}
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write([]byte("OK"))
}

// originChecker valida o header Origin contra a allowlist. "*" libera tudo
// (dev). Requests sem Origin (clientes não-browser) são aceitos.
func originChecker(allowed []string) func(*http.Request) bool {
	if len(allowed) == 1 && allowed[0] == "*" {
		return func(*http.Request) bool { return true }
	}
	set := make(map[string]struct{}, len(allowed))
	for _, a := range allowed {
		set[strings.ToLower(strings.TrimSuffix(a, "/"))] = struct{}{}
	}
	return func(r *http.Request) bool {
		origin := r.Header.Get("Origin")
		if origin == "" {
			return true
		}
		o := strings.ToLower(strings.TrimSuffix(origin, "/"))
		if _, ok := set[o]; ok {
			return true
		}
		if u, err := url.Parse(o); err == nil {
			if _, ok := set[u.Host]; ok {
				return true
			}
		}
		return false
	}
}
