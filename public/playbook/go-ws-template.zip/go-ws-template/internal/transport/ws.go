package transport

import (
	"encoding/json"
	"net/http"
	"strings"
	"time"

	"github.com/gorilla/websocket"

	"github.com/grupootg/go-ws-template/internal/auth"
	"github.com/grupootg/go-ws-template/internal/hub"
)

// Protocolo de controle (ADR-0007), frames TEXT JSON:
//
//	cliente → servidor: {"action":"subscribe","channels":["odds-pt"]}
//	cliente → servidor: {"action":"unsubscribe","channels":["odds-pt"]}
//	servidor → cliente: {"type":"ack","action":"subscribe","ok":["odds-pt"],"errors":{"x":"unknown channel"}}
//
// Assinaturas iniciais via query string: ?channels=a,b (ou ?channel=a;
// compat r10: ?event=stats&language=portuguese → "stats-portuguese").
type controlRequest struct {
	Action   string   `json:"action"`
	Channels []string `json:"channels"`
}

type controlAck struct {
	Type   string            `json:"type"`
	Action string            `json:"action,omitempty"`
	OK     []string          `json:"ok,omitempty"`
	Errors map[string]string `json:"errors,omitempty"`
}

// handleWS aceita a conexão e inicia os pumps da sessão multiplexada.
func (s *Server) handleWS(w http.ResponseWriter, r *http.Request) {
	if s.draining.Load() {
		http.Error(w, "draining", http.StatusServiceUnavailable)
		return
	}
	if s.hub.Connections() >= s.cfg.MaxConnections {
		s.rejectedFull.Inc()
		w.Header().Set("Retry-After", "5")
		http.Error(w, "at capacity", http.StatusServiceUnavailable)
		return
	}
	if !s.bucket.Allow() {
		s.rateLimited.Inc()
		w.Header().Set("Retry-After", "2")
		http.Error(w, "too many connection attempts", http.StatusTooManyRequests)
		return
	}

	// Autenticação (JWT HS256) antes de pagar o custo do upgrade.
	var claims *auth.Claims
	if s.verifier != nil {
		token := r.URL.Query().Get("token")
		if token == "" {
			token = strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
		}
		c, err := s.verifier.Verify(token, time.Now())
		if err != nil {
			s.authRejected.Inc()
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		claims = &c
	}

	// Assinaturas iniciais (opcionais) via query string — validadas ANTES do
	// upgrade para falhar com HTTP limpo.
	initial := initialChannels(r)
	for _, ch := range initial {
		if !s.hub.HasChannel(ch) {
			http.Error(w, "unknown channel: "+ch, http.StatusNotFound)
			return
		}
		if claims != nil && !claims.AllowsChannel(ch) {
			s.authRejected.Inc()
			http.Error(w, "forbidden channel: "+ch, http.StatusForbidden)
			return
		}
	}

	conn, err := s.upgrader.Upgrade(w, r, nil)
	if err != nil {
		s.upgradeErrors.Inc()
		s.log.Warn("falha no upgrade", "err", err)
		return
	}

	sess := s.hub.NewSession()
	defer s.hub.CloseSession(sess, hub.ReasonError)
	defer conn.Close()

	if len(initial) > 0 {
		ok := make([]string, 0, len(initial))
		errs := map[string]string{}
		for _, ch := range initial {
			if _, err := s.hub.Subscribe(sess, ch); err != nil {
				errs[ch] = subscribeError(err) // ex.: excedeu WS_MAX_SUBSCRIPTIONS
				continue
			}
			ok = append(ok, ch)
		}
		s.sendAck(sess, "subscribe", ok, errs)
	}

	go s.writePump(sess, conn)
	s.readPump(sess, conn, claims) // roda na goroutine do handler
}

func initialChannels(r *http.Request) []string {
	q := r.URL.Query()
	if cs := q.Get("channels"); cs != "" {
		parts := strings.Split(cs, ",")
		out := make([]string, 0, len(parts))
		for _, p := range parts {
			if p = strings.TrimSpace(p); p != "" {
				out = append(out, p)
			}
		}
		return out
	}
	if c := q.Get("channel"); c != "" {
		return []string{c}
	}
	if event := q.Get("event"); event != "" { // compat r10
		if lang := q.Get("language"); lang != "" {
			return []string{event + "-" + lang}
		}
		return []string{event}
	}
	return nil
}

// readPump consome o socket: keepalive (pong renova o deadline) e frames de
// controle subscribe/unsubscribe.
func (s *Server) readPump(sess *hub.Session, conn *websocket.Conn, claims *auth.Claims) {
	conn.SetReadLimit(s.cfg.ReadLimit)
	_ = conn.SetReadDeadline(time.Now().Add(s.cfg.PongTimeout))
	conn.SetPongHandler(func(string) error {
		return conn.SetReadDeadline(time.Now().Add(s.cfg.PongTimeout))
	})

	for {
		msgType, data, err := conn.ReadMessage()
		if err != nil {
			sess.Close(hub.ReasonError)
			return
		}
		if msgType != websocket.TextMessage {
			continue // clientes só falam o protocolo de controle (TEXT)
		}
		s.handleControl(sess, data, claims)
	}
}

func (s *Server) handleControl(sess *hub.Session, data []byte, claims *auth.Claims) {
	var req controlRequest
	if err := json.Unmarshal(data, &req); err != nil {
		s.controlErrors.Inc()
		s.sendError(sess, "invalid control frame")
		return
	}

	switch req.Action {
	case "subscribe":
		ok := make([]string, 0, len(req.Channels))
		errs := map[string]string{}
		for _, ch := range req.Channels {
			if claims != nil && !claims.AllowsChannel(ch) {
				s.authRejected.Inc()
				errs[ch] = "forbidden"
				continue
			}
			if _, err := s.hub.Subscribe(sess, ch); err != nil {
				errs[ch] = subscribeError(err)
				continue
			}
			ok = append(ok, ch)
		}
		s.sendAck(sess, "subscribe", ok, errs)

	case "unsubscribe":
		ok := make([]string, 0, len(req.Channels))
		for _, ch := range req.Channels {
			s.hub.Unsubscribe(sess, ch)
			ok = append(ok, ch)
		}
		s.sendAck(sess, "unsubscribe", ok, nil)

	default:
		s.controlErrors.Inc()
		s.sendError(sess, "unknown action")
	}
}

func subscribeError(err error) string {
	switch err {
	case hub.ErrUnknownChannel:
		return "unknown channel"
	case hub.ErrTooManySubscriptions:
		return "too many subscriptions"
	case hub.ErrSessionClosed:
		return "session closed"
	}
	return "error"
}

func (s *Server) sendAck(sess *hub.Session, action string, ok []string, errs map[string]string) {
	if len(errs) == 0 {
		errs = nil
	}
	msg, err := json.Marshal(controlAck{Type: "ack", Action: action, OK: ok, Errors: errs})
	if err == nil {
		sess.SendControl(msg)
	}
}

func (s *Server) sendError(sess *hub.Session, text string) {
	msg, err := json.Marshal(controlAck{Type: "error", Errors: map[string]string{"_": text}})
	if err == nil {
		sess.SendControl(msg)
	}
}

// writePump é a única goroutine que escreve no socket: mensagens dos
// mailboxes, acks de controle, pings e o close frame final. Toda escrita tem
// deadline — um socket morto nunca trava o pump.
func (s *Server) writePump(sess *hub.Session, conn *websocket.Conn) {
	ticker := time.NewTicker(s.cfg.PingInterval)
	defer ticker.Stop()
	defer conn.Close()

	for {
		select {
		case <-sess.Done():
			s.sendClose(conn, sess.Reason())
			return

		case <-ticker.C:
			_ = conn.SetWriteDeadline(time.Now().Add(s.cfg.WriteTimeout))
			if err := conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				s.writeErrors.Inc()
				sess.Close(hub.ReasonError)
				return
			}
			// Varredura de segurança: cobre o caminho defensivo (raro) de
			// sinalização perdida em deliver() — garante entrega em no
			// máximo 1 intervalo de ping mesmo nesse caso.
			for _, sub := range sess.Subscriptions() {
				if !s.drainSub(sess, conn, sub) {
					return
				}
			}

		case ctrl := <-sess.Control():
			_ = conn.SetWriteDeadline(time.Now().Add(s.cfg.WriteTimeout))
			if err := conn.WriteMessage(websocket.TextMessage, ctrl); err != nil {
				s.writeErrors.Inc()
				sess.Close(hub.ReasonError)
				return
			}

		case sub := <-sess.Dirty():
			if !s.drainSub(sess, conn, sub) {
				return
			}
		}
	}
}

// drainSub escreve todas as mensagens pendentes da assinatura no socket.
// Retorna false se a sessão deve ser encerrada (erro de escrita).
func (s *Server) drainSub(sess *hub.Session, conn *websocket.Conn, sub *hub.Subscription) bool {
	sub.BeginDrain()
	for m := sub.Pop(); m != nil; m = sub.Pop() {
		_ = conn.SetWriteDeadline(time.Now().Add(s.cfg.WriteTimeout))
		var err error
		if pm, ok := m.Prepared.(*websocket.PreparedMessage); ok {
			err = conn.WritePreparedMessage(pm)
		} else {
			err = conn.WriteMessage(websocket.BinaryMessage, m.Data)
		}
		if err != nil {
			s.writeErrors.Inc()
			sess.Close(hub.ReasonError)
			return false
		}
		if m.PublishedMicros != 0 {
			if h, ok := s.msgAge[sub.Channel()]; ok {
				age := float64(time.Now().UnixMicro()-m.PublishedMicros) / 1e6
				if age >= 0 {
					h.Observe(age)
				}
			}
		}
	}
	return true
}

// sendClose envia o close frame coerente com o motivo — o cliente sabe se
// deve reconectar (drain/deploy) ou recuar (lento).
func (s *Server) sendClose(conn *websocket.Conn, reason hub.CloseReason) {
	code := websocket.CloseNormalClosure
	text := ""
	switch reason {
	case hub.ReasonDrain:
		code = websocket.CloseGoingAway
		text = "server draining"
	case hub.ReasonSlow:
		code = websocket.CloseTryAgainLater
		text = "slow consumer"
	}
	_ = conn.WriteControl(
		websocket.CloseMessage,
		websocket.FormatCloseMessage(code, text),
		time.Now().Add(time.Second),
	)
}
