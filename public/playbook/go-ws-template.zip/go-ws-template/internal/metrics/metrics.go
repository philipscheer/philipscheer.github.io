// Package metrics implementa contadores, gauges e histogramas lock-free
// (atomics) com exposição no formato de texto do Prometheus — sem dependência
// externa. No hot path (fan-out) o custo por observação é 1–2 operações
// atômicas.
package metrics

import (
	"fmt"
	"math"
	"net/http"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
)

type Labels map[string]string

// ---------------------------------------------------------------------------
// Instrumentos

type Counter struct{ v atomic.Uint64 }

func (c *Counter) Inc()            { c.v.Add(1) }
func (c *Counter) Add(n uint64)    { c.v.Add(n) }
func (c *Counter) Value() uint64   { return c.v.Load() }

type Gauge struct{ v atomic.Int64 }

func (g *Gauge) Inc()          { g.v.Add(1) }
func (g *Gauge) Dec()          { g.v.Add(-1) }
func (g *Gauge) Add(n int64)   { g.v.Add(n) }
func (g *Gauge) Set(n int64)   { g.v.Store(n) }
func (g *Gauge) Value() int64  { return g.v.Load() }

// Histogram com buckets cumulativos estilo Prometheus (le = upper bound).
type Histogram struct {
	bounds  []float64 // ordenado crescente; bucket extra implícito +Inf
	counts  []atomic.Uint64
	sumBits atomic.Uint64
	count   atomic.Uint64
}

func newHistogram(bounds []float64) *Histogram {
	b := make([]float64, len(bounds))
	copy(b, bounds)
	sort.Float64s(b)
	return &Histogram{bounds: b, counts: make([]atomic.Uint64, len(b)+1)}
}

func (h *Histogram) Observe(v float64) {
	idx := sort.SearchFloat64s(h.bounds, v) // primeiro bound >= v
	h.counts[idx].Add(1)
	h.count.Add(1)
	for {
		old := h.sumBits.Load()
		nw := math.Float64bits(math.Float64frombits(old) + v)
		if h.sumBits.CompareAndSwap(old, nw) {
			return
		}
	}
}

func (h *Histogram) Count() uint64 { return h.count.Load() }
func (h *Histogram) Sum() float64  { return math.Float64frombits(h.sumBits.Load()) }

// Quantile estima o quantil q (0..1) pelo upper bound do bucket — suficiente
// para alarmes e relatórios de carga.
func (h *Histogram) Quantile(q float64) float64 {
	total := h.count.Load()
	if total == 0 {
		return 0
	}
	target := uint64(math.Ceil(q * float64(total)))
	var cum uint64
	for i := range h.counts {
		cum += h.counts[i].Load()
		if cum >= target {
			if i < len(h.bounds) {
				return h.bounds[i]
			}
			return math.Inf(1)
		}
	}
	return math.Inf(1)
}

// DefaultLatencyBuckets cobre de 1ms a 60s (idade de mensagem / fan-out).
func DefaultLatencyBuckets() []float64 {
	return []float64{
		0.001, 0.0025, 0.005, 0.01, 0.025, 0.05, 0.1,
		0.25, 0.5, 1, 2.5, 5, 10, 30, 60,
	}
}

// ---------------------------------------------------------------------------
// Registry

type kind uint8

const (
	kindCounter kind = iota
	kindGauge
	kindHistogram
)

type series struct {
	labels string // já renderizado: {a="b",c="d"} ou ""
	c      *Counter
	g      *Gauge
	gf     func() int64 // gauge funcional (avaliado no scrape)
	h      *Histogram
}

type family struct {
	name   string
	help   string
	kind   kind
	series []*series
}

type Registry struct {
	mu       sync.Mutex
	families map[string]*family
	order    []string
}

func NewRegistry() *Registry {
	return &Registry{families: make(map[string]*family)}
}

func (r *Registry) family(name, help string, k kind) *family {
	r.mu.Lock()
	defer r.mu.Unlock()
	f, ok := r.families[name]
	if !ok {
		f = &family{name: name, help: help, kind: k}
		r.families[name] = f
		r.order = append(r.order, name)
	}
	return f
}

func renderLabels(l Labels) string {
	if len(l) == 0 {
		return ""
	}
	keys := make([]string, 0, len(l))
	for k := range l {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var b strings.Builder
	b.WriteByte('{')
	for i, k := range keys {
		if i > 0 {
			b.WriteByte(',')
		}
		fmt.Fprintf(&b, "%s=%q", k, l[k])
	}
	b.WriteByte('}')
	return b.String()
}

func (r *Registry) Counter(name, help string, l Labels) *Counter {
	f := r.family(name, help, kindCounter)
	s := &series{labels: renderLabels(l), c: &Counter{}}
	r.mu.Lock()
	f.series = append(f.series, s)
	r.mu.Unlock()
	return s.c
}

func (r *Registry) Gauge(name, help string, l Labels) *Gauge {
	f := r.family(name, help, kindGauge)
	s := &series{labels: renderLabels(l), g: &Gauge{}}
	r.mu.Lock()
	f.series = append(f.series, s)
	r.mu.Unlock()
	return s.g
}

// GaugeFunc registra um gauge cujo valor é calculado a cada scrape — útil
// para métricas de runtime (goroutines, heap, GC).
func (r *Registry) GaugeFunc(name, help string, l Labels, fn func() int64) {
	f := r.family(name, help, kindGauge)
	s := &series{labels: renderLabels(l), gf: fn}
	r.mu.Lock()
	f.series = append(f.series, s)
	r.mu.Unlock()
}

func (r *Registry) Histogram(name, help string, l Labels, buckets []float64) *Histogram {
	f := r.family(name, help, kindHistogram)
	s := &series{labels: renderLabels(l), h: newHistogram(buckets)}
	r.mu.Lock()
	f.series = append(f.series, s)
	r.mu.Unlock()
	return s.h
}

// Handler expõe /metrics no formato de texto do Prometheus.
func (r *Registry) Handler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
		var b strings.Builder
		r.mu.Lock()
		defer r.mu.Unlock()
		for _, name := range r.order {
			f := r.families[name]
			fmt.Fprintf(&b, "# HELP %s %s\n", f.name, f.help)
			fmt.Fprintf(&b, "# TYPE %s %s\n", f.name, typeName(f.kind))
			for _, s := range f.series {
				switch f.kind {
				case kindCounter:
					fmt.Fprintf(&b, "%s%s %d\n", f.name, s.labels, s.c.Value())
				case kindGauge:
					v := int64(0)
					if s.gf != nil {
						v = s.gf()
					} else {
						v = s.g.Value()
					}
					fmt.Fprintf(&b, "%s%s %d\n", f.name, s.labels, v)
				case kindHistogram:
					writeHistogram(&b, f.name, s)
				}
			}
		}
		_, _ = w.Write([]byte(b.String()))
	})
}

func writeHistogram(b *strings.Builder, name string, s *series) {
	h := s.h
	var cum uint64
	for i, bound := range h.bounds {
		cum += h.counts[i].Load()
		fmt.Fprintf(b, "%s_bucket%s %d\n", name, mergeLabel(s.labels, fmt.Sprintf("le=%q", formatFloat(bound))), cum)
	}
	cum += h.counts[len(h.bounds)].Load()
	fmt.Fprintf(b, "%s_bucket%s %d\n", name, mergeLabel(s.labels, `le="+Inf"`), cum)
	fmt.Fprintf(b, "%s_sum%s %g\n", name, s.labels, h.Sum())
	fmt.Fprintf(b, "%s_count%s %d\n", name, s.labels, h.Count())
}

func mergeLabel(existing, extra string) string {
	if existing == "" {
		return "{" + extra + "}"
	}
	return existing[:len(existing)-1] + "," + extra + "}"
}

func formatFloat(f float64) string {
	return strings.TrimRight(strings.TrimRight(fmt.Sprintf("%f", f), "0"), ".")
}

func typeName(k kind) string {
	switch k {
	case kindCounter:
		return "counter"
	case kindGauge:
		return "gauge"
	default:
		return "histogram"
	}
}
