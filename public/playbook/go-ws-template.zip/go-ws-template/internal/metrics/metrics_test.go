package metrics

import (
	"io"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
)

func TestCounterGauge(t *testing.T) {
	r := NewRegistry()
	c := r.Counter("test_total", "help", Labels{"channel": "a"})
	g := r.Gauge("test_active", "help", nil)

	c.Inc()
	c.Add(4)
	g.Set(10)
	g.Dec()

	if c.Value() != 5 {
		t.Fatalf("counter esperado 5, obtido %d", c.Value())
	}
	if g.Value() != 9 {
		t.Fatalf("gauge esperado 9, obtido %d", g.Value())
	}
}

func TestHistogramQuantile(t *testing.T) {
	r := NewRegistry()
	h := r.Histogram("lat_seconds", "help", nil, []float64{0.01, 0.1, 1})

	for i := 0; i < 90; i++ {
		h.Observe(0.005) // bucket 0.01
	}
	for i := 0; i < 10; i++ {
		h.Observe(0.5) // bucket 1
	}

	if h.Count() != 100 {
		t.Fatalf("count esperado 100, obtido %d", h.Count())
	}
	if q := h.Quantile(0.5); q != 0.01 {
		t.Fatalf("p50 esperado 0.01, obtido %v", q)
	}
	if q := h.Quantile(0.99); q != 1 {
		t.Fatalf("p99 esperado 1, obtido %v", q)
	}
}

func TestExposition(t *testing.T) {
	r := NewRegistry()
	r.Counter("msgs_total", "mensagens", Labels{"channel": "stats"}).Add(7)
	r.Gauge("conns", "conexões", nil).Set(3)
	h := r.Histogram("age_seconds", "idade", Labels{"channel": "stats"}, []float64{0.1, 1})
	h.Observe(0.05)
	h.Observe(2)

	req := httptest.NewRequest("GET", "/metrics", nil)
	rec := httptest.NewRecorder()
	r.Handler().ServeHTTP(rec, req)
	body, _ := io.ReadAll(rec.Result().Body)
	out := string(body)

	for _, want := range []string{
		`msgs_total{channel="stats"} 7`,
		`conns 3`,
		`age_seconds_bucket{channel="stats",le="0.1"} 1`,
		`age_seconds_bucket{channel="stats",le="+Inf"} 2`,
		`age_seconds_count{channel="stats"} 2`,
		"# TYPE age_seconds histogram",
	} {
		if !strings.Contains(out, want) {
			t.Fatalf("exposição não contém %q:\n%s", want, out)
		}
	}
}

func TestConcurrentObserve(t *testing.T) {
	r := NewRegistry()
	h := r.Histogram("x", "h", nil, DefaultLatencyBuckets())
	c := r.Counter("y", "c", nil)
	var wg sync.WaitGroup
	for w := 0; w < 8; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := 0; i < 1000; i++ {
				h.Observe(0.002)
				c.Inc()
			}
		}()
	}
	wg.Wait()
	if h.Count() != 8000 || c.Value() != 8000 {
		t.Fatalf("contagens divergentes: %d / %d", h.Count(), c.Value())
	}
}

func BenchmarkHistogramObserve(b *testing.B) {
	h := newHistogram(DefaultLatencyBuckets())
	b.ReportAllocs()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			h.Observe(0.0042)
		}
	})
}
