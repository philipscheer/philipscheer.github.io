package broker

import (
	"context"
	"errors"
	"sync"
)

// Memory é um broker in-process para desenvolvimento e testes.
type Memory struct {
	mu     sync.RWMutex
	subs   map[string][]chan Event
	closed bool
}

var ErrClosed = errors.New("broker: fechado")

func NewMemory() *Memory {
	return &Memory{subs: make(map[string][]chan Event)}
}

func (m *Memory) Subscribe(ctx context.Context, topics ...string) (<-chan Event, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.closed {
		return nil, ErrClosed
	}
	ch := make(chan Event, 1024)
	for _, t := range topics {
		m.subs[t] = append(m.subs[t], ch)
	}
	go func() {
		<-ctx.Done()
		m.mu.Lock()
		for _, t := range topics {
			list := m.subs[t]
			for i, c := range list {
				if c == ch {
					m.subs[t] = append(list[:i], list[i+1:]...)
					break
				}
			}
		}
		m.mu.Unlock()
		close(ch)
	}()
	return ch, nil
}

func (m *Memory) Publish(_ context.Context, topic string, payload []byte) error {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if m.closed {
		return ErrClosed
	}
	for _, ch := range m.subs[topic] {
		select {
		case ch <- Event{Topic: topic, Payload: payload}:
		default: // assinante saturado: descarta (paridade com Redis Pub/Sub)
		}
	}
	return nil
}

func (m *Memory) Close() error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.closed = true
	return nil
}
