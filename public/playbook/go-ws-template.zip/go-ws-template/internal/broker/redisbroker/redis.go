// Package redisbroker implementa broker.Broker sobre Redis Pub/Sub
// (go-redis/v9, com reconexão automática embutida).
//
// Cada tópico tem sua própria assinatura (conexão Pub/Sub): a leitura é
// paralela e o atraso de um tópico não contamina os demais
// (IMPROVEMENTS §8).
package redisbroker

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/redis/go-redis/v9"

	"github.com/grupootg/go-ws-template/internal/broker"
)

type Broker struct {
	client *redis.Client
	prefix string
}

// New conecta ao Redis e valida com PING.
func New(addr, prefix string) (*Broker, error) {
	client := redis.NewClient(&redis.Options{
		Addr:         addr,
		MinIdleConns: 1,
	})
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := client.Ping(ctx).Err(); err != nil {
		_ = client.Close()
		return nil, fmt.Errorf("redisbroker: ping %s: %w", addr, err)
	}
	return &Broker{client: client, prefix: prefix}, nil
}

func (b *Broker) Subscribe(ctx context.Context, topics ...string) (<-chan broker.Event, error) {
	out := make(chan broker.Event, 4096)
	pubsubs := make([]*redis.PubSub, 0, len(topics))

	for _, topic := range topics {
		pubsub := b.client.Subscribe(ctx, b.prefix+topic)
		// Garante que a assinatura foi aceita antes de retornar.
		if _, err := pubsub.Receive(ctx); err != nil {
			_ = pubsub.Close()
			for _, p := range pubsubs {
				_ = p.Close()
			}
			return nil, fmt.Errorf("redisbroker: subscribe %s: %w", topic, err)
		}
		pubsubs = append(pubsubs, pubsub)
	}

	// done coordena o fechamento de out após todos os leitores encerrarem.
	done := make(chan struct{}, len(pubsubs))

	for _, pubsub := range pubsubs {
		go func(ps *redis.PubSub) {
			defer func() { done <- struct{}{} }()
			defer ps.Close()
			in := ps.Channel(redis.WithChannelSize(4096))
			for {
				select {
				case <-ctx.Done():
					return
				case msg, ok := <-in:
					if !ok {
						return
					}
					ev := broker.Event{
						Topic:   strings.TrimPrefix(msg.Channel, b.prefix),
						Payload: []byte(msg.Payload),
					}
					select {
					case out <- ev:
					case <-ctx.Done(): // consumidor parou: não bloquear o leitor
						return
					}
				}
			}
		}(pubsub)
	}

	go func() {
		for range pubsubs {
			<-done
		}
		close(out)
	}()

	return out, nil
}

func (b *Broker) Publish(ctx context.Context, topic string, payload []byte) error {
	return b.client.Publish(ctx, b.prefix+topic, payload).Err()
}

func (b *Broker) Close() error { return b.client.Close() }
