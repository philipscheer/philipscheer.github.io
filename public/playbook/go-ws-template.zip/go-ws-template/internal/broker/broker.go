// Package broker define a interface de ingestão de eventos. A implementação
// padrão é Redis Pub/Sub (subpacote redisbroker); Memory serve para testes e
// desenvolvimento single-process. Trocar por NATS/Kafka = nova implementação
// desta interface, sem tocar no resto do servidor.
package broker

import "context"

// Event é um evento bruto recebido do broker. Payload normalmente carrega um
// envelope (internal/envelope) — mas o servidor tolera payloads sem envelope.
type Event struct {
	Topic   string
	Payload []byte
}

type Broker interface {
	// Subscribe entrega eventos dos tópicos até o cancelamento do ctx.
	// O canal retornado é fechado quando a assinatura termina.
	Subscribe(ctx context.Context, topics ...string) (<-chan Event, error)

	// Publish publica um evento no tópico (usado por produtores e testes).
	Publish(ctx context.Context, topic string, payload []byte) error

	Close() error
}
