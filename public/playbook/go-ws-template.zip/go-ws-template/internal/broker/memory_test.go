package broker

import (
	"context"
	"testing"
	"time"
)

func TestMemoryPubSub(t *testing.T) {
	m := NewMemory()
	defer m.Close()

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	events, err := m.Subscribe(ctx, "a", "b")
	if err != nil {
		t.Fatal(err)
	}

	if err := m.Publish(ctx, "a", []byte("1")); err != nil {
		t.Fatal(err)
	}
	if err := m.Publish(ctx, "other", []byte("x")); err != nil {
		t.Fatal(err)
	}
	if err := m.Publish(ctx, "b", []byte("2")); err != nil {
		t.Fatal(err)
	}

	got := map[string]string{}
	for i := 0; i < 2; i++ {
		select {
		case ev := <-events:
			got[ev.Topic] = string(ev.Payload)
		case <-time.After(time.Second):
			t.Fatal("timeout")
		}
	}
	if got["a"] != "1" || got["b"] != "2" {
		t.Fatalf("eventos divergentes: %v", got)
	}

	cancel()
	select {
	case _, ok := <-events:
		if ok {
			// drena eventuais pendentes
			for range events {
			}
		}
	case <-time.After(time.Second):
		t.Fatal("canal não fechou após cancel")
	}

	if err := m.Publish(context.Background(), "a", []byte("3")); err != nil {
		t.Fatal("publish após unsubscribe deve ser no-op, não erro")
	}
}

func TestMemoryClosed(t *testing.T) {
	m := NewMemory()
	m.Close()
	if _, err := m.Subscribe(context.Background(), "a"); err != ErrClosed {
		t.Fatalf("esperava ErrClosed, obtido %v", err)
	}
	if err := m.Publish(context.Background(), "a", nil); err != ErrClosed {
		t.Fatalf("esperava ErrClosed, obtido %v", err)
	}
}
