package hub

import (
	"sync"
	"sync/atomic"
	"time"
)

// DeliveryMode define a política de entrega por assinatura.
type DeliveryMode int

const (
	// Coalesce (latest-wins): guarda apenas a mensagem mais recente do canal
	// em um slot atômico. Assinante atrasado pula direto para o estado atual.
	// Exige que o produtor publique o estado COMPLETO do canal por mensagem
	// (ADR-0003). Ideal para estado: odds, placares, estatísticas.
	Coalesce DeliveryMode = iota

	// KeyedCoalesce: latest-wins POR CHAVE DE ENTIDADE (envelope.Key,
	// ADR-0008). Assinante atrasado recebe o estado mais recente de CADA
	// entidade — permite updates incrementais sem perder entidades.
	KeyedCoalesce

	// Buffer: fila bounded com drop-oldest quando cheia. Para streams em
	// que toda mensagem importa (eventos discretos).
	Buffer
)

func ParseMode(s string) (DeliveryMode, bool) {
	switch s {
	case "coalesce":
		return Coalesce, true
	case "coalesce-keyed":
		return KeyedCoalesce, true
	case "buffer":
		return Buffer, true
	}
	return Coalesce, false
}

// CloseReason indica por que a sessão foi encerrada — o write pump escolhe o
// close code do WebSocket a partir dela.
type CloseReason int32

const (
	ReasonNone  CloseReason = iota
	ReasonDrain             // shutdown/deploy → 1001 going away
	ReasonSlow              // cliente persistentemente lento → 1013 try again later
	ReasonError             // erro de I/O ou protocolo
)

// Outgoing é uma mensagem pronta para fan-out. Data carrega o frame wire
// completo (envelope com canal + payload); Prepared carrega o
// *websocket.PreparedMessage montado 1× pelo transporte.
type Outgoing struct {
	Seq             uint64
	PublishedMicros int64  // 0 = desconhecido
	Key             string // chave de entidade (KeyedCoalesce)
	Data            []byte
	Prepared        any
}

// ---------------------------------------------------------------------------
// Session — uma conexão WebSocket com N assinaturas (ADR-0007)

type Session struct {
	ID  uint64
	hub *Hub

	mu      sync.Mutex
	subs    map[string]*Subscription
	removed bool // já passou por CloseSession (contagem decrementada)

	dirty   chan *Subscription // sinalização dedup: cap = maxSubs, nunca bloqueia
	control chan []byte        // mensagens de controle (acks JSON) p/ write pump

	done      chan struct{}
	closeOnce sync.Once
	reason    atomic.Int32

	// janela da política de cliente lento
	winStart atomic.Int64
	winDrops atomic.Int64
}

// Done fecha quando a sessão deve ser encerrada (drain, slow, erro).
func (s *Session) Done() <-chan struct{} { return s.done }

// Dirty sinaliza assinaturas com mensagens pendentes (dedup por assinatura).
func (s *Session) Dirty() <-chan *Subscription { return s.dirty }

// Control entrega mensagens de controle (acks) para o write pump.
func (s *Session) Control() <-chan []byte { return s.control }

// Reason retorna o motivo do encerramento (válido após Done fechar).
func (s *Session) Reason() CloseReason { return CloseReason(s.reason.Load()) }

// Close encerra a sessão (idempotente); o primeiro motivo vence.
func (s *Session) Close(reason CloseReason) {
	s.reason.CompareAndSwap(int32(ReasonNone), int32(reason))
	s.closeOnce.Do(func() { close(s.done) })
}

// SendControl enfileira uma mensagem de controle sem bloquear (descarta se o
// write pump estiver saturado — acks são best-effort).
func (s *Session) SendControl(msg []byte) bool {
	select {
	case <-s.done:
		return false
	case s.control <- msg:
		return true
	default:
		return false
	}
}

// Channels lista os canais atualmente assinados.
func (s *Session) Channels() []string {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]string, 0, len(s.subs))
	for ch := range s.subs {
		out = append(out, ch)
	}
	return out
}

// Subscriptions retorna as assinaturas ativas (cópia). Usado pelo write pump
// para a varredura periódica que cobre o (raro) caminho defensivo de
// sinalização perdida em deliver().
func (s *Session) Subscriptions() []*Subscription {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]*Subscription, 0, len(s.subs))
	for _, sub := range s.subs {
		out = append(out, sub)
	}
	return out
}

// noteDrop alimenta a política de cliente lento: drops sustentados dentro da
// janela ⇒ desconexão com ReasonSlow (IMPROVEMENTS §2).
func (s *Session) noteDrop() {
	max := s.hub.slowMaxDrops
	if max <= 0 {
		return
	}
	now := time.Now().UnixNano()
	start := s.winStart.Load()
	if now-start > s.hub.slowWindowNanos {
		// janela expirou: reinicia (aproximação tolerante a corrida)
		if s.winStart.CompareAndSwap(start, now) {
			s.winDrops.Store(0)
		}
	}
	n := s.winDrops.Add(1)
	if n < max {
		return
	}
	if n == max {
		s.hub.slowDisconnects.Inc() // conta 1× por sessão/janela
	}
	s.Close(ReasonSlow) // idempotente; >= tolera resets concorrentes da janela
}

// ---------------------------------------------------------------------------
// Subscription — mailbox de um canal dentro de uma sessão

type Subscription struct {
	sess    *Session
	shard   *shard
	channel string

	inQueue atomic.Bool // dedup do sinal em Session.dirty

	// exatamente um destes é usado, conforme o modo:
	slot  atomic.Pointer[Outgoing] // Coalesce
	keyed *keyedSlots              // KeyedCoalesce
	queue chan *Outgoing           // Buffer
}

func (sub *Subscription) Channel() string { return sub.channel }

// deliver entrega a mensagem ao mailbox sem JAMAIS bloquear o broadcaster —
// a garantia anti head-of-line blocking (ADR-0003).
func (sub *Subscription) deliver(m *Outgoing) {
	select {
	case <-sub.sess.done:
		return
	default:
	}

	switch {
	case sub.queue != nil: // Buffer
		for {
			select {
			case sub.queue <- m:
				goto signal
			default:
			}
			select {
			case <-sub.queue:
				sub.shard.dropped.Inc()
				sub.sess.noteDrop()
			default:
			}
		}
	case sub.keyed != nil: // KeyedCoalesce
		if sub.keyed.put(m) {
			sub.shard.dropped.Inc()
			sub.sess.noteDrop()
		}
	default: // Coalesce
		if old := sub.slot.Swap(m); old != nil {
			sub.shard.dropped.Inc()
			sub.sess.noteDrop()
		}
	}

signal:
	if sub.inQueue.CompareAndSwap(false, true) {
		select {
		case sub.sess.dirty <- sub:
		default:
			// dirty é dimensionado para maxSubs (1 slot por assinatura, com
			// dedup) — este caminho é defensivo: libera o flag para que a
			// próxima entrega tente de novo.
			sub.inQueue.Store(false)
		}
	}
}

// BeginDrain marca o início do consumo pós-sinal. DEVE ser chamado antes da
// sequência de Pop — a ordem (flag primeiro, pop depois) garante que uma
// entrega concorrente re-sinalize em vez de se perder.
func (sub *Subscription) BeginDrain() { sub.inQueue.Store(false) }

// Pop retira a próxima mensagem pendente (nil quando não há mais).
func (sub *Subscription) Pop() *Outgoing {
	switch {
	case sub.queue != nil:
		select {
		case m := <-sub.queue:
			return m
		default:
			return nil
		}
	case sub.keyed != nil:
		return sub.keyed.pop()
	default:
		return sub.slot.Swap(nil)
	}
}

// ---------------------------------------------------------------------------
// keyedSlots — latest-wins por chave de entidade, com ordem FIFO de chaves

type keyedSlots struct {
	mu    sync.Mutex
	m     map[string]*Outgoing
	order []string
	head  int
}

func newKeyedSlots() *keyedSlots {
	return &keyedSlots{m: make(map[string]*Outgoing, 8)}
}

// put guarda a mensagem como estado mais recente da chave; retorna true se
// substituiu um estado ainda não consumido (drop por coalescing).
func (k *keyedSlots) put(m *Outgoing) (dropped bool) {
	k.mu.Lock()
	defer k.mu.Unlock()
	if _, exists := k.m[m.Key]; exists {
		k.m[m.Key] = m
		return true
	}
	k.m[m.Key] = m
	k.order = append(k.order, m.Key)
	return false
}

func (k *keyedSlots) pop() *Outgoing {
	k.mu.Lock()
	defer k.mu.Unlock()
	for k.head < len(k.order) {
		key := k.order[k.head]
		k.head++
		if k.head == len(k.order) {
			k.order = k.order[:0]
			k.head = 0
		}
		if m, ok := k.m[key]; ok {
			delete(k.m, key)
			return m
		}
	}
	return nil
}
