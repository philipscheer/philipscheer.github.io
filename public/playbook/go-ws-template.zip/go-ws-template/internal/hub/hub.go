// Package hub mantém sessões (conexões) com N assinaturas de canais (shards)
// e executa o fan-out de mensagens.
//
// Decisões de performance (ADR-0003/0004/0007):
//
//  1. Um shard por canal, snapshot imutável (atomic.Pointer) da lista de
//     assinantes: ZERO locks e zero alocações no caminho do broadcast.
//  2. A entrega (Subscription.deliver) nunca bloqueia: assinante lento sofre
//     coalescing/drop individual — sem head-of-line blocking.
//  3. Fan-out intra-canal paralelo: acima de FanoutChunk assinantes, o
//     snapshot é fatiado e entregue por um worker pool fixo (multi-core
//     também dentro de um único canal quente).
//  4. Sessões multiplexadas: 1 conexão atende N canais via assinaturas
//     independentes com sinalização dedup (Session.dirty).
package hub

import (
	"errors"
	"math/rand"
	"runtime"
	"sync"
	"sync/atomic"
	"time"

	"github.com/grupootg/go-ws-template/internal/metrics"
)

var (
	ErrUnknownChannel       = errors.New("hub: canal inexistente")
	ErrSessionClosed        = errors.New("hub: sessão encerrada")
	ErrTooManySubscriptions = errors.New("hub: limite de assinaturas da sessão atingido")
)

// Options parametriza o hub. Zero values recebem defaults sensatos.
type Options struct {
	Mode              DeliveryMode
	BufferSize        int   // fila por assinatura no modo Buffer (default 64)
	MaxSubscriptions  int   // assinaturas por sessão (default 16)
	SnapshotOnConnect bool  // entrega o último estado ao assinar
	FanoutChunk       int   // fatia do fan-out paralelo (default 4096; 0 = default)
	FanoutWorkers     int   // workers do pool (default GOMAXPROCS)
	SlowMaxDrops      int64 // drops na janela p/ desconectar cliente lento (0 = off)
	SlowWindow        time.Duration
}

func (o *Options) defaults() {
	if o.BufferSize <= 0 {
		o.BufferSize = 64
	}
	if o.MaxSubscriptions <= 0 {
		o.MaxSubscriptions = 16
	}
	if o.FanoutChunk <= 0 {
		o.FanoutChunk = 4096
	}
	if o.FanoutWorkers <= 0 {
		o.FanoutWorkers = runtime.GOMAXPROCS(0)
	}
	if o.SlowWindow <= 0 {
		o.SlowWindow = 10 * time.Second
	}
}

// ---------------------------------------------------------------------------

type shard struct {
	channel string

	mu   sync.Mutex
	subs map[uint64]*Subscription // por Session.ID
	snap atomic.Pointer[[]*Subscription]

	// snapshot-on-connect
	last       atomic.Pointer[Outgoing]
	keyedMu    sync.Mutex
	keyedLast  map[string]*Outgoing // só em KeyedCoalesce+SnapshotOnConnect
	keyedOrder []string

	subsGauge *metrics.Gauge
	sent      *metrics.Counter
	dropped   *metrics.Counter
	fanout    *metrics.Histogram
}

func (s *shard) rebuildLocked() {
	list := make([]*Subscription, 0, len(s.subs))
	for _, sub := range s.subs {
		list = append(list, sub)
	}
	s.snap.Store(&list)
}

func (s *shard) add(sub *Subscription) {
	s.mu.Lock()
	s.subs[sub.sess.ID] = sub
	s.rebuildLocked()
	s.mu.Unlock()
	s.subsGauge.Inc()
}

func (s *shard) remove(sub *Subscription) {
	s.mu.Lock()
	_, ok := s.subs[sub.sess.ID]
	if ok {
		delete(s.subs, sub.sess.ID)
		s.rebuildLocked()
	}
	s.mu.Unlock()
	if ok {
		s.subsGauge.Dec()
	}
}

// rememberLast guarda o estado mais recente para snapshot-on-connect.
func (s *shard) rememberLast(m *Outgoing, keyed bool) {
	s.last.Store(m)
	if !keyed || m.Key == "" {
		return
	}
	s.keyedMu.Lock()
	if _, exists := s.keyedLast[m.Key]; !exists {
		s.keyedOrder = append(s.keyedOrder, m.Key)
	}
	s.keyedLast[m.Key] = m
	s.keyedMu.Unlock()
}

// replayLast entrega o último estado conhecido a um novo assinante.
func (s *shard) replayLast(sub *Subscription, keyed bool) {
	if keyed {
		s.keyedMu.Lock()
		msgs := make([]*Outgoing, 0, len(s.keyedOrder))
		for _, k := range s.keyedOrder {
			if m, ok := s.keyedLast[k]; ok {
				msgs = append(msgs, m)
			}
		}
		s.keyedMu.Unlock()
		for _, m := range msgs {
			sub.deliver(m)
		}
		return
	}
	if m := s.last.Load(); m != nil {
		sub.deliver(m)
	}
}

// ---------------------------------------------------------------------------

// Hub é o conjunto de shards (um por canal) + registro de sessões.
type Hub struct {
	shards map[string]*shard
	opts   Options

	slowMaxDrops    int64
	slowWindowNanos int64

	nextSessID atomic.Uint64
	sessMu     sync.Mutex
	sessions   map[uint64]*Session

	pool *fanoutPool

	connGauge       *metrics.Gauge
	slowDisconnects *metrics.Counter
}

// New cria o hub com o conjunto fixo de canais (imutável após o boot —
// ADR-0004; por isso o acesso a h.shards dispensa lock).
func New(channels []string, opts Options, reg *metrics.Registry) *Hub {
	opts.defaults()
	h := &Hub{
		shards:          make(map[string]*shard, len(channels)),
		opts:            opts,
		slowMaxDrops:    opts.SlowMaxDrops,
		slowWindowNanos: opts.SlowWindow.Nanoseconds(),
		sessions:        make(map[uint64]*Session),
		pool:            newFanoutPool(opts.FanoutWorkers),
		connGauge: reg.Gauge("ws_active_connections",
			"Sessões (conexões) ativas", nil),
		slowDisconnects: reg.Counter("ws_slow_clients_disconnected_total",
			"Sessões desconectadas pela política de cliente lento", nil),
	}
	for _, ch := range channels {
		sh := &shard{
			channel: ch,
			subs:    make(map[uint64]*Subscription),
			subsGauge: reg.Gauge("ws_active_subscriptions",
				"Assinaturas ativas por canal", metrics.Labels{"channel": ch}),
			sent: reg.Counter("ws_messages_sent_total",
				"Mensagens enfileiradas para envio por canal", metrics.Labels{"channel": ch}),
			dropped: reg.Counter("ws_messages_dropped_total",
				"Mensagens descartadas (coalescing/fila cheia) por canal", metrics.Labels{"channel": ch}),
			fanout: reg.Histogram("ws_broadcast_fanout_seconds",
				"Duração do fan-out por broadcast", metrics.Labels{"channel": ch},
				metrics.DefaultLatencyBuckets()),
		}
		if opts.Mode == KeyedCoalesce && opts.SnapshotOnConnect {
			sh.keyedLast = make(map[string]*Outgoing)
		}
		h.shards[ch] = sh
	}
	return h
}

// NewSession cria uma sessão (conexão) sem assinaturas.
func (h *Hub) NewSession() *Session {
	s := &Session{
		ID:   h.nextSessID.Add(1),
		hub:  h,
		subs: make(map[string]*Subscription, 4),
		// +8 de folga: assinaturas recém-canceladas podem ocupar slots até o
		// write pump drenar; a varredura no tick de ping cobre o resto.
		dirty:   make(chan *Subscription, h.opts.MaxSubscriptions+8),
		control: make(chan []byte, 8),
		done:    make(chan struct{}),
	}
	s.winStart.Store(time.Now().UnixNano())
	h.sessMu.Lock()
	h.sessions[s.ID] = s
	h.sessMu.Unlock()
	h.connGauge.Inc()
	return s
}

// Subscribe adiciona a sessão ao canal (idempotente por canal).
func (h *Hub) Subscribe(s *Session, channel string) (*Subscription, error) {
	sh, ok := h.shards[channel]
	if !ok {
		return nil, ErrUnknownChannel
	}
	select {
	case <-s.done:
		return nil, ErrSessionClosed
	default:
	}

	s.mu.Lock()
	if s.removed {
		s.mu.Unlock()
		return nil, ErrSessionClosed
	}
	if sub, exists := s.subs[channel]; exists {
		s.mu.Unlock()
		return sub, nil
	}
	if len(s.subs) >= h.opts.MaxSubscriptions {
		s.mu.Unlock()
		return nil, ErrTooManySubscriptions
	}
	sub := &Subscription{sess: s, shard: sh, channel: channel}
	switch h.opts.Mode {
	case Buffer:
		sub.queue = make(chan *Outgoing, h.opts.BufferSize)
	case KeyedCoalesce:
		sub.keyed = newKeyedSlots()
	}
	s.subs[channel] = sub
	// sh.add ainda sob s.mu: garante que CloseSession concorrente não deixe
	// uma assinatura órfã no shard (ordem de locks: Session.mu → shard.mu;
	// nenhum caminho adquire na ordem inversa).
	sh.add(sub)
	s.mu.Unlock()

	if h.opts.SnapshotOnConnect {
		sh.replayLast(sub, h.opts.Mode == KeyedCoalesce)
	}
	return sub, nil
}

// Unsubscribe remove a assinatura do canal (no-op se não assinado).
func (h *Hub) Unsubscribe(s *Session, channel string) {
	s.mu.Lock()
	sub, ok := s.subs[channel]
	if ok {
		delete(s.subs, channel)
	}
	s.mu.Unlock()
	if ok {
		sub.shard.remove(sub)
	}
}

// CloseSession encerra a sessão e remove todas as assinaturas (idempotente).
func (h *Hub) CloseSession(s *Session, reason CloseReason) {
	s.Close(reason)

	s.mu.Lock()
	if s.removed {
		s.mu.Unlock()
		return
	}
	s.removed = true
	subs := make([]*Subscription, 0, len(s.subs))
	for _, sub := range s.subs {
		subs = append(subs, sub)
	}
	s.subs = make(map[string]*Subscription)
	s.mu.Unlock()

	for _, sub := range subs {
		sub.shard.remove(sub)
	}

	h.sessMu.Lock()
	delete(h.sessions, s.ID)
	h.sessMu.Unlock()
	h.connGauge.Dec()
}

// Broadcast envia a mensagem a todos os assinantes do canal. Nunca bloqueia
// em assinante lento.
func (h *Hub) Broadcast(channel string, m *Outgoing) error {
	sh, ok := h.shards[channel]
	if !ok {
		return ErrUnknownChannel
	}

	if h.opts.SnapshotOnConnect {
		sh.rememberLast(m, h.opts.Mode == KeyedCoalesce)
	}

	listPtr := sh.snap.Load()
	if listPtr == nil || len(*listPtr) == 0 {
		return nil
	}
	list := *listPtr
	start := time.Now()

	if n := len(list); n <= h.opts.FanoutChunk {
		for _, sub := range list {
			sub.deliver(m)
		}
	} else {
		var wg sync.WaitGroup
		for i := 0; i < n; i += h.opts.FanoutChunk {
			end := min(i+h.opts.FanoutChunk, n)
			wg.Add(1)
			h.pool.submit(fanoutTask{subs: list[i:end], m: m, wg: &wg})
		}
		wg.Wait()
	}

	sh.sent.Add(uint64(len(list)))
	sh.fanout.Observe(time.Since(start).Seconds())
	return nil
}

// Connections retorna o total de sessões ativas.
func (h *Hub) Connections() int64 { return h.connGauge.Value() }

// HasChannel informa se o canal é servido por este hub.
func (h *Hub) HasChannel(channel string) bool {
	_, ok := h.shards[channel]
	return ok
}

// Channels lista os canais servidos.
func (h *Hub) Channels() []string {
	out := make([]string, 0, len(h.shards))
	for ch := range h.shards {
		out = append(out, ch)
	}
	return out
}

// CloseAll agenda o encerramento de todas as sessões espalhado por maxJitter
// (anti thundering herd no deploy). Os write pumps observam Done() e enviam o
// close frame adequado ao motivo.
func (h *Hub) CloseAll(maxJitter time.Duration) {
	h.sessMu.Lock()
	sessions := make([]*Session, 0, len(h.sessions))
	for _, s := range h.sessions {
		sessions = append(sessions, s)
	}
	h.sessMu.Unlock()

	for _, s := range sessions {
		if maxJitter <= 0 {
			s.Close(ReasonDrain)
			continue
		}
		delay := time.Duration(rand.Int63n(int64(maxJitter)))
		sess := s
		time.AfterFunc(delay, func() { sess.Close(ReasonDrain) })
	}
}

// ---------------------------------------------------------------------------
// fanoutPool — workers fixos para fan-out paralelo intra-canal

type fanoutTask struct {
	subs []*Subscription
	m    *Outgoing
	wg   *sync.WaitGroup
}

type fanoutPool struct {
	tasks chan fanoutTask
}

func newFanoutPool(workers int) *fanoutPool {
	p := &fanoutPool{tasks: make(chan fanoutTask, workers*2)}
	for i := 0; i < workers; i++ {
		go func() {
			for t := range p.tasks {
				for _, sub := range t.subs {
					sub.deliver(t.m)
				}
				t.wg.Done()
			}
		}()
	}
	return p
}

func (p *fanoutPool) submit(t fanoutTask) { p.tasks <- t }
