package hub

import (
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/grupootg/go-ws-template/internal/metrics"
)

func newTestHub(t testing.TB, opts Options, channels ...string) *Hub {
	t.Helper()
	if len(channels) == 0 {
		channels = []string{"events"}
	}
	return New(channels, opts, metrics.NewRegistry())
}

// collect consome mensagens da sessão até atingir want (ou estourar timeout).
func collect(t *testing.T, s *Session, want int, timeout time.Duration) []*Outgoing {
	t.Helper()
	var out []*Outgoing
	deadline := time.After(timeout)
	for len(out) < want {
		select {
		case sub := <-s.Dirty():
			sub.BeginDrain()
			for m := sub.Pop(); m != nil; m = sub.Pop() {
				out = append(out, m)
			}
		case <-deadline:
			t.Fatalf("timeout: esperava %d mensagens, obtidas %d", want, len(out))
		}
	}
	return out
}

func TestSubscribeUnknownChannel(t *testing.T) {
	h := newTestHub(t, Options{}, "a")
	s := h.NewSession()
	defer h.CloseSession(s, ReasonNone)

	if _, err := h.Subscribe(s, "nope"); err != ErrUnknownChannel {
		t.Fatalf("esperava ErrUnknownChannel, obtido %v", err)
	}
	if err := h.Broadcast("nope", &Outgoing{}); err != ErrUnknownChannel {
		t.Fatalf("esperava ErrUnknownChannel, obtido %v", err)
	}
}

func TestSessionLifecycle(t *testing.T) {
	h := newTestHub(t, Options{}, "a", "b")
	s := h.NewSession()

	if _, err := h.Subscribe(s, "a"); err != nil {
		t.Fatal(err)
	}
	if _, err := h.Subscribe(s, "b"); err != nil {
		t.Fatal(err)
	}
	if h.Connections() != 1 {
		t.Fatalf("esperava 1 sessão, obtido %d", h.Connections())
	}
	if got := len(s.Channels()); got != 2 {
		t.Fatalf("esperava 2 assinaturas, obtido %d", got)
	}

	h.CloseSession(s, ReasonError)
	h.CloseSession(s, ReasonDrain) // idempotente; primeiro motivo vence
	if h.Connections() != 0 {
		t.Fatalf("esperava 0 sessões, obtido %d", h.Connections())
	}
	if s.Reason() != ReasonError {
		t.Fatalf("esperava ReasonError, obtido %v", s.Reason())
	}
	select {
	case <-s.Done():
	default:
		t.Fatal("CloseSession deveria fechar a sessão")
	}
	if _, err := h.Subscribe(s, "a"); err != ErrSessionClosed {
		t.Fatalf("esperava ErrSessionClosed, obtido %v", err)
	}
}

func TestSubscribeIdempotenteELimite(t *testing.T) {
	h := newTestHub(t, Options{MaxSubscriptions: 2}, "a", "b", "c")
	s := h.NewSession()
	defer h.CloseSession(s, ReasonNone)

	sub1, _ := h.Subscribe(s, "a")
	sub1b, _ := h.Subscribe(s, "a")
	if sub1 != sub1b {
		t.Fatal("Subscribe no mesmo canal deveria ser idempotente")
	}
	if _, err := h.Subscribe(s, "b"); err != nil {
		t.Fatal(err)
	}
	if _, err := h.Subscribe(s, "c"); err != ErrTooManySubscriptions {
		t.Fatalf("esperava ErrTooManySubscriptions, obtido %v", err)
	}
}

func TestBroadcastDeliversAllModes(t *testing.T) {
	for _, mode := range []DeliveryMode{Coalesce, KeyedCoalesce, Buffer} {
		h := newTestHub(t, Options{Mode: mode})
		s := h.NewSession()
		if _, err := h.Subscribe(s, "events"); err != nil {
			t.Fatal(err)
		}
		if err := h.Broadcast("events", &Outgoing{Seq: 1, Key: "k", Data: []byte("hello")}); err != nil {
			t.Fatal(err)
		}
		got := collect(t, s, 1, time.Second)
		if string(got[0].Data) != "hello" {
			t.Fatalf("mode %v: payload divergente", mode)
		}
		h.CloseSession(s, ReasonNone)
	}
}

// Contrato central anti super spike: assinante que não consome recebe apenas
// a última mensagem (latest-wins) e o broadcast jamais bloqueia.
func TestCoalesceLatestWins(t *testing.T) {
	h := newTestHub(t, Options{Mode: Coalesce})
	s := h.NewSession()
	defer h.CloseSession(s, ReasonNone)
	_, _ = h.Subscribe(s, "events")

	done := make(chan struct{})
	go func() {
		defer close(done)
		for i := 1; i <= 1000; i++ {
			_ = h.Broadcast("events", &Outgoing{Seq: uint64(i)})
		}
	}()

	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("broadcast bloqueou com assinante lento — head-of-line blocking!")
	}

	got := collect(t, s, 1, time.Second)
	if got[0].Seq != 1000 {
		t.Fatalf("esperava a última mensagem (seq=1000), obtido seq=%d", got[0].Seq)
	}
	if len(got) != 1 {
		t.Fatalf("coalesce deveria entregar exatamente 1 mensagem, obtidas %d", len(got))
	}
}

// Keyed: assinante lento mantém o estado mais recente de CADA entidade.
func TestKeyedCoalesceLatestWinsPorChave(t *testing.T) {
	h := newTestHub(t, Options{Mode: KeyedCoalesce})
	s := h.NewSession()
	defer h.CloseSession(s, ReasonNone)
	_, _ = h.Subscribe(s, "events")

	_ = h.Broadcast("events", &Outgoing{Seq: 1, Key: "match:A"})
	_ = h.Broadcast("events", &Outgoing{Seq: 2, Key: "match:B"})
	_ = h.Broadcast("events", &Outgoing{Seq: 3, Key: "match:A"}) // substitui seq=1

	got := collect(t, s, 2, time.Second)
	if len(got) != 2 {
		t.Fatalf("esperava 2 mensagens (1 por chave), obtidas %d", len(got))
	}
	byKey := map[string]uint64{}
	for _, m := range got {
		byKey[m.Key] = m.Seq
	}
	if byKey["match:A"] != 3 {
		t.Fatalf("match:A deveria ter o estado mais recente (seq=3), obtido %d", byKey["match:A"])
	}
	if byKey["match:B"] != 2 {
		t.Fatalf("match:B esperava seq=2, obtido %d", byKey["match:B"])
	}
}

func TestBufferDropOldest(t *testing.T) {
	h := newTestHub(t, Options{Mode: Buffer, BufferSize: 4})
	s := h.NewSession()
	defer h.CloseSession(s, ReasonNone)
	_, _ = h.Subscribe(s, "events")

	for i := 1; i <= 10; i++ {
		_ = h.Broadcast("events", &Outgoing{Seq: uint64(i)})
	}

	got := collect(t, s, 4, time.Second)
	want := []uint64{7, 8, 9, 10}
	for i, w := range want {
		if got[i].Seq != w {
			t.Fatalf("posição %d: esperava seq=%d, obtido seq=%d", i, w, got[i].Seq)
		}
	}
}

func TestSnapshotOnConnect(t *testing.T) {
	h := newTestHub(t, Options{Mode: Coalesce, SnapshotOnConnect: true})
	_ = h.Broadcast("events", &Outgoing{Seq: 41})
	_ = h.Broadcast("events", &Outgoing{Seq: 42})

	s := h.NewSession()
	defer h.CloseSession(s, ReasonNone)
	_, _ = h.Subscribe(s, "events")

	got := collect(t, s, 1, time.Second)
	if got[0].Seq != 42 {
		t.Fatalf("novo assinante deveria receber o último estado (seq=42), obtido %d", got[0].Seq)
	}
}

func TestSnapshotOnConnectKeyed(t *testing.T) {
	h := newTestHub(t, Options{Mode: KeyedCoalesce, SnapshotOnConnect: true})
	_ = h.Broadcast("events", &Outgoing{Seq: 1, Key: "A"})
	_ = h.Broadcast("events", &Outgoing{Seq: 2, Key: "B"})
	_ = h.Broadcast("events", &Outgoing{Seq: 3, Key: "A"})

	s := h.NewSession()
	defer h.CloseSession(s, ReasonNone)
	_, _ = h.Subscribe(s, "events")

	got := collect(t, s, 2, time.Second)
	byKey := map[string]uint64{}
	for _, m := range got {
		byKey[m.Key] = m.Seq
	}
	if byKey["A"] != 3 || byKey["B"] != 2 {
		t.Fatalf("snapshot keyed divergente: %v", byKey)
	}
}

func TestSlowClientDisconnect(t *testing.T) {
	h := newTestHub(t, Options{Mode: Coalesce, SlowMaxDrops: 5, SlowWindow: time.Minute})
	s := h.NewSession()
	defer h.CloseSession(s, ReasonNone)
	_, _ = h.Subscribe(s, "events")

	// 1ª mensagem ocupa o slot; as próximas 5 geram drops 1..5 → fecha no 5º
	for i := 1; i <= 6; i++ {
		_ = h.Broadcast("events", &Outgoing{Seq: uint64(i)})
	}

	select {
	case <-s.Done():
	case <-time.After(time.Second):
		t.Fatal("política de cliente lento não desconectou a sessão")
	}
	if s.Reason() != ReasonSlow {
		t.Fatalf("esperava ReasonSlow, obtido %v", s.Reason())
	}
}

func TestUnsubscribeStopsDelivery(t *testing.T) {
	h := newTestHub(t, Options{Mode: Buffer, BufferSize: 8}, "a", "b")
	s := h.NewSession()
	defer h.CloseSession(s, ReasonNone)
	_, _ = h.Subscribe(s, "a")
	_, _ = h.Subscribe(s, "b")

	h.Unsubscribe(s, "a")
	_ = h.Broadcast("a", &Outgoing{Seq: 1})
	_ = h.Broadcast("b", &Outgoing{Seq: 2})

	got := collect(t, s, 1, time.Second)
	if got[0].Seq != 2 {
		t.Fatalf("esperava apenas a mensagem do canal b (seq=2), obtido seq=%d", got[0].Seq)
	}
	select {
	case sub := <-s.Dirty():
		sub.BeginDrain()
		if m := sub.Pop(); m != nil {
			t.Fatalf("canal dessinado não deveria entregar (seq=%d)", m.Seq)
		}
	case <-time.After(50 * time.Millisecond):
	}
}

func TestChannelsAreIsolated(t *testing.T) {
	h := newTestHub(t, Options{Mode: Buffer, BufferSize: 8}, "a", "b")
	sa := h.NewSession()
	sb := h.NewSession()
	defer h.CloseSession(sa, ReasonNone)
	defer h.CloseSession(sb, ReasonNone)
	_, _ = h.Subscribe(sa, "a")
	_, _ = h.Subscribe(sb, "b")

	_ = h.Broadcast("a", &Outgoing{Seq: 1})

	if got := collect(t, sa, 1, time.Second); got[0].Seq != 1 {
		t.Fatal("assinante do canal 'a' não recebeu")
	}
	select {
	case <-sb.Dirty():
		t.Fatal("assinante do canal 'b' recebeu mensagem do canal 'a'")
	case <-time.After(50 * time.Millisecond):
	}
}

// Força o caminho do worker pool (fan-out paralelo intra-canal).
func TestParallelFanoutDeliversToAll(t *testing.T) {
	h := newTestHub(t, Options{Mode: Coalesce, FanoutChunk: 8, FanoutWorkers: 4})
	const n = 100
	sessions := make([]*Session, n)
	for i := range sessions {
		sessions[i] = h.NewSession()
		if _, err := h.Subscribe(sessions[i], "events"); err != nil {
			t.Fatal(err)
		}
	}
	_ = h.Broadcast("events", &Outgoing{Seq: 7})

	for i, s := range sessions {
		got := collect(t, s, 1, time.Second)
		if got[0].Seq != 7 {
			t.Fatalf("sessão %d: seq divergente %d", i, got[0].Seq)
		}
		h.CloseSession(s, ReasonNone)
	}
}

func TestCloseAllUnblocksSessions(t *testing.T) {
	h := newTestHub(t, Options{})
	var sessions []*Session
	for i := 0; i < 50; i++ {
		s := h.NewSession()
		_, _ = h.Subscribe(s, "events")
		sessions = append(sessions, s)
	}
	h.CloseAll(10 * time.Millisecond)
	for _, s := range sessions {
		select {
		case <-s.Done():
			if s.Reason() != ReasonDrain {
				t.Fatalf("esperava ReasonDrain, obtido %v", s.Reason())
			}
		case <-time.After(2 * time.Second):
			t.Fatal("CloseAll não fechou todas as sessões")
		}
	}
}

// Corrida real: broadcasts paralelos (inclusive via pool) + churn de sessões
// e assinaturas. Roda sob -race.
func TestConcurrentBroadcastAndChurn(t *testing.T) {
	h := newTestHub(t, Options{Mode: KeyedCoalesce, FanoutChunk: 4, FanoutWorkers: 4, SnapshotOnConnect: true}, "a", "b")
	var wg sync.WaitGroup
	stop := make(chan struct{})

	for w := 0; w < 4; w++ {
		wg.Add(1)
		go func(w int) {
			defer wg.Done()
			key := fmt.Sprintf("k%d", w)
			for i := 0; ; i++ {
				select {
				case <-stop:
					return
				default:
				}
				_ = h.Broadcast("a", &Outgoing{Seq: uint64(i), Key: key})
				_ = h.Broadcast("b", &Outgoing{Seq: uint64(i), Key: key})
			}
		}(w)
	}

	for w := 0; w < 4; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := 0; i < 300; i++ {
				s := h.NewSession()
				_, _ = h.Subscribe(s, "a")
				_, _ = h.Subscribe(s, "b")
				select {
				case sub := <-s.Dirty():
					sub.BeginDrain()
					for m := sub.Pop(); m != nil; m = sub.Pop() {
					}
				default:
				}
				h.Unsubscribe(s, "a")
				h.CloseSession(s, ReasonNone)
			}
		}()
	}

	time.Sleep(200 * time.Millisecond)
	close(stop)
	wg.Wait()
	if h.Connections() != 0 {
		t.Fatalf("esperava 0 sessões após churn, obtido %d", h.Connections())
	}
}

// ---------------------------------------------------------------------------
// Benchmarks — o custo do fan-out é a métrica de capacidade da máquina.

func benchmarkBroadcast(b *testing.B, nSubs int, opts Options) {
	h := newTestHub(b, opts)
	for i := 0; i < nSubs; i++ {
		s := h.NewSession()
		if _, err := h.Subscribe(s, "events"); err != nil {
			b.Fatal(err)
		}
	}
	msg := &Outgoing{Seq: 1, Data: make([]byte, 256)}
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_ = h.Broadcast("events", msg)
	}
	b.ReportMetric(float64(nSubs)*float64(b.N)/b.Elapsed().Seconds(), "deliveries/s")
}

func BenchmarkBroadcast1k(b *testing.B)  { benchmarkBroadcast(b, 1_000, Options{}) }
func BenchmarkBroadcast10k(b *testing.B) { benchmarkBroadcast(b, 10_000, Options{}) }

// 100k assinantes: serial × fan-out paralelo (worker pool)
func BenchmarkBroadcast100kSerial(b *testing.B) {
	benchmarkBroadcast(b, 100_000, Options{FanoutChunk: 1 << 30})
}
func BenchmarkBroadcast100kParallel(b *testing.B) {
	benchmarkBroadcast(b, 100_000, Options{FanoutChunk: 4096})
}

// Fan-out em canais independentes — mede o ganho de sharding.
func BenchmarkBroadcastParallelChannels(b *testing.B) {
	channels := []string{"c0", "c1", "c2", "c3"}
	h := newTestHub(b, Options{}, channels...)
	for _, ch := range channels {
		for i := 0; i < 25_000; i++ {
			s := h.NewSession()
			if _, err := h.Subscribe(s, ch); err != nil {
				b.Fatal(err)
			}
		}
	}
	msg := &Outgoing{Seq: 1, Data: make([]byte, 256)}
	b.ResetTimer()
	b.ReportAllocs()
	b.RunParallel(func(pb *testing.PB) {
		i := 0
		for pb.Next() {
			_ = h.Broadcast(channels[i%len(channels)], msg)
			i++
		}
	})
	b.ReportMetric(25_000*float64(b.N)/b.Elapsed().Seconds(), "deliveries/s")
}

func ExampleHub() {
	h := New([]string{"odds"}, Options{}, metrics.NewRegistry())
	s := h.NewSession()
	sub, _ := h.Subscribe(s, "odds")
	_ = h.Broadcast("odds", &Outgoing{Seq: 1, Data: []byte("1.95")})
	<-s.Dirty()
	sub.BeginDrain()
	fmt.Println(string(sub.Pop().Data))
	// Output: 1.95
}
