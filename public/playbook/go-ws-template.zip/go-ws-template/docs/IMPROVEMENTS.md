# Oportunidades de melhoria — arquitetura e performance

**Data:** 2026-06-11 · **Base:** branch `feat/ws-template` (PR #1)
**Atualização (mesmo dia):** itens 1–13 **implementados** no protocolo v1.1 (ADR-0007/0008). Restam os itens por gatilho (14–16).

Análise do template. Cada item traz impacto, esforço e o racional técnico. Os itens P0 tocam **corretude sob carga**; P1 são ganhos de capacidade; P2 operação; P3 evolução.

---

## P0 — Corretude sob carga

### 1. Coalescing por chave (keyed latest-wins) ou contrato de snapshot
**Impacto: alto · Esforço: M**

O latest-wins atual opera **por canal**. Se um canal carrega estado de N entidades (ex.: odds de vários jogos no mesmo canal `bets-portuguese`), um cliente lento que sofre coalescing perde o update do jogo A quando o update do jogo B chega depois — e fica com A defasado até o próximo update de A. Duas soluções, em ordem de preferência:

1. **Contrato de snapshot (sem código):** o produtor publica sempre o **estado completo** do canal por mensagem (como o r10 já faz por tópico×idioma). Basta documentar como contrato obrigatório do modo `coalesce` — é a opção de menor custo e já cobre o caso de uso atual.
2. **Mailbox keyed:** `map[key]*Outgoing` + fila de chaves por cliente; o produtor declara a chave da entidade no envelope (campo `flags`/extensão do header). Necessário apenas quando payloads completos ficarem grandes demais.

*Critério: cliente lento nunca observa entidade mais defasada que o último publish daquela entidade.*

### 2. Desconexão de cliente persistentemente lento
**Impacto: médio · Esforço: S**

Hoje o cliente lento sofre drops (contados em `ws_messages_dropped_total`), mas permanece conectado indefinidamente consumindo mailbox, goroutines e fd. Cliente com rede inviável é custo sem valor. Adicionar política: taxa de drops sustentada acima de X por Y segundos → close com código próprio (ex.: 1013 Try Again Later) + métrica `ws_slow_clients_disconnected_total`. Threshold por env (`WS_SLOW_CLIENT_DROP_RATE`).

### 3. GOMEMLIMIT no container
**Impacto: médio (evita OOM kill) · Esforço: S**

O GC do Go não conhece o limite de memória da task Fargate — sob pico de conexões, o heap pode crescer até o OOM killer derrubar a task (e derrubar dezenas de milhares de conexões de uma vez = thundering herd). Definir `GOMEMLIMIT` ≈ 85–90% da RAM da task no Dockerfile/task definition e documentar no guia de sizing. Go ≥1.25 já ajusta `GOMAXPROCS` ao cgroup; falta o equivalente de memória.

---

## P1 — Capacidade e performance

### 4. Fan-out paralelo intra-canal
**Impacto: alto no cenário "1 canal quente" · Esforço: M**

`shard.broadcast` percorre o snapshot inteiro em **uma** goroutine. Com 100k clientes em um único canal, o throughput de broadcast é limitado a 1 core (paralelismo hoje é só entre canais). Particionar o snapshot em K fatias (K ≈ `GOMAXPROCS`) entregues por um worker pool fixo por shard. `client.push()` já é lock-free, então a paralelização é trivialmente segura. Validar com `BenchmarkBroadcast100k` antes/depois — esperado ganho ~K× no fan-out de canal único.

### 5. Multiplexação: N canais por conexão
**Impacto: alto · Esforço: L (muda contrato do cliente)**

Modelo atual (herdado do r10): 1 canal por conexão. Um cliente que quer `stats` + `incidents` + `bets` abre 3 sockets — 3× fd, memória e handshakes. Protocolo de controle simples (frame texto `{"subscribe": ["stats-pt", "bets-pt"]}`) com um mailbox por assinatura compartilhando o mesmo write pump. Reduz conexões e custo por usuário em até N×. Exige versão de protocolo e atualização do SDK do cliente — fazer junto do item 16.

### 6. Snapshot-on-connect
**Impacto: alto em UX · Esforço: S**

Cliente novo só recebe dados no **próximo** publish — em canais de baixa frequência (standings), pode ficar minutos "vazio". O shard guarda o último `Outgoing` (atomic.Pointer, custo zero no hot path); `Register` entrega imediatamente. Coerente com o contrato de snapshot do item 1.

### 7. permessage-deflate opcional
**Impacto: médio (banda/custo de egress) · Esforço: S**

`EnableCompression` no Upgrader + `WS_COMPRESSION=true`. `PreparedMessage` já cacheia a variante comprimida 1× por broadcast — o custo de CPU é por mensagem, não por cliente. Para payloads JSON >1KB, economia típica de 70–85% de banda. Medir CPU antes de ligar por padrão.

### 8. Ingestão Redis paralela
**Impacto: médio · Esforço: S/M**

Uma única conexão Pub/Sub serializa todos os tópicos (head-of-line na ingestão; o dispatch por worker mitiga, mas o socket é um só). Opções incrementais: (a) um `Subscribe` por tópico — paraleliza leitura e isola falha; (b) Redis Cluster + **sharded Pub/Sub** (`SSUBSCRIBE`, Redis ≥7) quando o publisher saturar um nó; (c) pipeline de PUBLISH no produtor.

---

## P2 — Operação e observabilidade

### 9. pprof + métricas de runtime
**Esforço: S.** `net/http/pprof` em listener separado (`WS_DEBUG_PORT`, sem exposição pública) + gauges de runtime no /metrics: goroutines, heap, GC pause p99, fds abertos. Sem isso, investigar um super spike real em produção é adivinhação.

### 10. Rate limit de upgrades (anti accept-storm)
**Esforço: S.** Pós-deploy/failover, dezenas de milhares de clientes reconectam em segundos; o custo de handshake+TLS concentra CPU e atrasa o fan-out de quem já está conectado. Token bucket nos upgrades (ex.: 2k/s, burst 5k, por env) + 503/Retry-After. O jitter do drain reduz o problema causado por *nós*; o rate limit protege contra o que vem de fora.

### 11. Autenticação no upgrade
**Esforço: M.** Middleware opcional de JWT (`?token=` ou header) antes do `Upgrade`, com validação de claims → canal autorizado. Ponto de extensão já isolado em `handleWS`.

### 12. Referência de deploy (ECS/Fargate)
**Esforço: S (infra-as-code/docs).** Task definition exemplo com `ulimits nofile=1048576`, `GOMEMLIMIT`, sizing por tier (1 vCPU≈25–50k conns), scheduled scaling para janelas de jogo, alarmes CloudWatch: p99 `ws_message_age_seconds` (o alarme do super spike), taxa de `ws_messages_dropped_total`, `ws_rejected_full_total`.

### 13. CI: lint + teste de integração
**Esforço: S.** `golangci-lint` + verificação `gofmt`; teste e2e com build tag `integration` (servidor real + gorilla client + broker memory, validando upgrade→broadcast→idade). Hoje o e2e só existe via `cmd/loadtest` manual.

---

## P3 — Evolução (gatilhos claros, não fazer antes)

### 14. Transporte epoll (gobwas/ws)
**Gatilho:** teto vertical real atingido (~150–200k conns/task) ou custo de RAM dominante. Elimina as 2 goroutines/conn (~16KB) por event loop com epoll (~4KB/conn). Complexidade alta; a interface de transporte já isola a troca. Antes disso, vale mais o item 5 (multiplexação reduz o número de conexões na raiz).

### 15. Broker com entrega garantida (NATS JetStream / Kafka)
**Gatilho:** requisito de replay/at-least-once (ex.: trilha de auditoria de odds). Redis Pub/Sub perde mensagens em failover — aceitável para estado (próximo update corrige), inaceitável para eventos contábeis. Nova implementação de `broker.Broker`.

### 16. SDK de cliente oficial (TS + Go)
**Gatilho:** segundo projeto consumidor. Reconexão backoff+jitter, decode do envelope, detecção de staleness, (futuro) multiplexação — implementados 1× em vez de por produto. Reduz a principal fonte de incidentes de integração.

---

## Resumo priorizado (com status)

| # | Item | Impacto | Status |
|---|---|---|---|
| 1 | Contrato de snapshot + keyed coalescing | Alto (corretude) | ✅ Implementado — modo `coalesce-keyed` (ADR-0008) + contrato no ADR-0003 |
| 2 | Desconexão de cliente lento | Médio | ✅ Implementado — `WS_SLOW_MAX_DROPS`/`WS_SLOW_WINDOW`, close 1013 |
| 3 | GOMEMLIMIT | Médio | ✅ Implementado — autodetecção cgroup (90%) em `cmd/server/memlimit.go` |
| 4 | Fan-out paralelo intra-canal | Alto | ✅ Implementado — worker pool, `WS_FANOUT_CHUNK` (bench serial×paralelo no CI) |
| 5 | Multiplexação de canais | Alto | ✅ Implementado — protocolo v1.1 (ADR-0007) |
| 6 | Snapshot-on-connect | Alto (UX) | ✅ Implementado — `WS_SNAPSHOT_ON_CONNECT` (inclusive keyed) |
| 7 | Compressão | Médio | ✅ Implementado — `WS_COMPRESSION` (medir CPU antes de ligar) |
| 8 | Ingestão Redis paralela | Médio | ✅ Implementado — 1 assinatura por tópico; sharded Pub/Sub fica p/ cluster |
| 9 | pprof/runtime metrics | Médio | ✅ Implementado — `WS_DEBUG_PORT` + gauges de runtime |
| 10 | Rate limit de upgrades | Médio | ✅ Implementado — `WS_UPGRADE_RATE/BURST`, HTTP 429 |
| 11 | Auth JWT no upgrade | Médio | ✅ Implementado — HS256 stdlib, claim `channels` (403/ack forbidden) |
| 12 | Referência de deploy | Médio | ✅ Parcial — checklist ARCHITECTURE + compose; IaC de ECS fica com o produto |
| 13 | CI lint + e2e | Médio | ✅ Parcial — e2e `-tags integration` no CI; lint (golangci) ainda pendente |
| 14 | Transporte epoll (gobwas/ws) | — | ⏳ Por gatilho: teto vertical (~150–200k conns/task) |
| 15 | Broker entrega garantida (NATS/Kafka) | — | ⏳ Por gatilho: requisito de replay/at-least-once |
| 16 | SDK de cliente oficial (TS/Go) | — | ⏳ Por gatilho: segundo projeto consumidor |

> Aceitação do v1.1: rodar `make test`, `make test-integration`, `make bench` (comparar `BenchmarkBroadcast100kSerial` × `BenchmarkBroadcast100kParallel`) e `make spike` + `make loadtest conns=50000` com p99 de `ws_message_age_seconds` dentro do alvo.
