# Guia passo a passo — criar e evoluir um serviço de WebSockets com este template

**Audiência:** dev que vai criar a camada de tempo real de um novo produto, ou alterar um serviço existente baseado neste template.
**Pré-requisitos:** Go ≥ 1.25, Docker (opcional), Redis para o modo padrão.

Sumário: [1. Novo serviço](#1-criar-um-novo-serviço-a-partir-do-template) · [2. Canais e modo de entrega](#2-definir-canais-e-modo-de-entrega) · [3. Produtor](#3-integrar-o-produtor) · [4. Cliente](#4-implementar-o-cliente) · [5. Validação local](#5-rodar-e-validar-localmente) · [6. Deploy](#6-deploy-em-produção) · [7. Receitas de alteração](#7-receitas-de-alteração-passo-a-passo) · [8. Convenções](#8-convenções-do-projeto)

---

## 1. Criar um novo serviço a partir do template

```bash
# 1. Novo repositório a partir do template (sem histórico)
git clone https://github.com/philipscheer/go-ws-template.git meu-produto-websockets
cd meu-produto-websockets && rm -rf .git && git init -b main

# 2. Renomear o módulo Go para o novo projeto
go mod edit -module github.com/grupootg/meu-produto-websockets
grep -rl "github.com/grupootg/go-ws-template" --include="*.go" . | \
  xargs sed -i 's|github.com/grupootg/go-ws-template|github.com/grupootg/meu-produto-websockets|g'

# 3. Setup e smoke test
./scripts/setup.sh        # (Windows: scripts\setup.bat)
make test                 # vet + testes -race: precisa estar verde antes do 1º commit
./scripts/start.sh        # sobe com broker memory
```

Smoke test em outro terminal:

```bash
curl http://localhost:8080/healthz          # → OK
curl http://localhost:8080/metrics | head   # → métricas expostas
```

> Apague `docs/referencia/` (específico do R10) e atualize o `README.md` com o nome do produto. **Mantenha `docs/adr/`** — registre novas decisões como novos ADRs (regras em [docs/adr/README.md](adr/README.md)).

## 2. Definir canais e modo de entrega

Edite o `.env` (gerado a partir de `.env.sample`):

```bash
WS_TOPICS=odds-pt,odds-en,placar-pt,placar-en   # 1 canal por assinatura do cliente
WS_DELIVERY_MODE=coalesce                        # ver tabela abaixo
WS_MAX_CONNECTIONS=50000
WS_ALLOWED_ORIGINS=https://meuproduto.com.br,https://app.meuproduto.com.br
```

**Como escolher o modo de entrega** (decisão por serviço, não por canal — ver ADR-0003/0008):

| Seu dado é... | Modo | Contrato do produtor |
|---|---|---|
| **Estado** que o próximo update substitui, publicável completo (placar, stats) | `coalesce` | ⚠️ Cada mensagem DEVE conter o estado completo do canal (snapshot) — mensagens intermediárias podem ser descartadas para clientes lentos |
| **Estado por entidade** com updates incrementais (odds de N jogos) | `coalesce-keyed` | Cada mensagem carrega a chave da entidade (`envelope.EncodeKeyed`, ex.: `match:123`); assinante lento mantém o último estado de CADA entidade |
| **Eventos discretos** em que cada item importa (gols, notificações) | `buffer` | Fila de `WS_CLIENT_BUFFER` por assinatura; sob saturação descarta os mais antigos |

Cada conexão assina até `WS_MAX_SUBSCRIPTIONS` canais (multiplexação — ADR-0007). Canal não existe dinamicamente: alterar `WS_TOPICS` exige redeploy (ADR-0004).

## 3. Integrar o produtor

O produtor publica no Redis em `<REDIS_CHANNEL_PREFIX><tópico>`, com o payload **envelopado** (ADR-0005). Em Go:

```go
import (
    "github.com/grupootg/meu-produto-websockets/internal/envelope"
    "github.com/redis/go-redis/v9"
)

rdb := redis.NewClient(&redis.Options{Addr: "redis:6379"})
seq++ // contador monotônico do produtor

// modo coalesce/buffer:
msg := envelope.Encode(nil, seq, time.Now(), payloadProtobufOuJSON)
// modo coalesce-keyed (latest-wins por entidade):
msg, _ = envelope.EncodeKeyed(nil, seq, time.Now(), "match:123", payloadProtobufOuJSON)

rdb.Publish(ctx, "odds-pt", msg)
```

Em outra linguagem, monte os 20 bytes do header (big-endian): `0x5753 | 0x01 | flags | seq u64 | unix_micros u64` (+extensões conforme flags — formato completo no README). Referência executável: [`cmd/publisher/main.go`](../cmd/publisher/main.go) (use `-keys N` para simular entidades).

Regras do produtor:

1. `seq` monotônico por tópico (detecção de perda no consumidor).
2. Timestamp do momento do **publish**, não da geração do dado.
3. Modo `coalesce`: snapshot completo por mensagem; modo `coalesce-keyed`: chave de entidade obrigatória (ver §2).
4. Payload sem envelope é tolerado pelo servidor (conta em `ingest_invalid_envelope_total`), mas você perde a medição de idade — use só durante migração.

## 4. Implementar o cliente

Conexão multiplexada: `wss://host/ws?channels=odds-pt,placar-pt` (+ subscribe dinâmico por frames de controle). Requisitos do cliente de produção:

```js
function connect(channels, onState) {
  let retry = 1000;
  function dial() {
    const ws = new WebSocket(`wss://ws.meuproduto.com.br/ws`); // + ?token=JWT se auth ativa
    ws.binaryType = "arraybuffer";

    ws.onopen = () => {
      retry = 1000;
      ws.send(JSON.stringify({ action: "subscribe", channels }));
    };

    ws.onmessage = (e) => {
      if (typeof e.data === "string") return;           // ack/erro de controle (JSON)
      const v = new DataView(e.data);
      if (v.getUint16(0) !== 0x5753) return;            // sem envelope: ignora
      const flags = v.getUint8(3);
      const publishedUs = v.getBigUint64(12);
      let off = 20, channel = "", key = "";
      if (flags & 0x02) { const n = v.getUint8(off); channel = dec(e.data, off + 1, n); off += 1 + n; }
      if (flags & 0x01) { const n = v.getUint8(off); key = dec(e.data, off + 1, n); off += 1 + n; }
      const ageMs = publishedUs ? Date.now() - Number(publishedUs / 1000n) : 0;
      onState(channel, key, new Uint8Array(e.data, off), ageMs);
      // ageMs alto → UI "dado defasado": nunca deixe o usuário agir sobre preço velho
    };

    ws.onclose = (ev) => {
      // 1001 = servidor drenando (deploy); 1013 = você foi considerado lento
      const jitter = Math.random() * retry;
      setTimeout(dial, retry + jitter);
      retry = Math.min(retry * 2, 30000);               // backoff exponencial, teto 30s
    };
  }
  const dec = (b, o, n) => new TextDecoder().decode(new Uint8Array(b, o, n));
  dial();
}
```

Obrigatório: reconexão com **backoff exponencial + jitter** (sem isso, um deploy vira thundering herd), tratamento dos closes `1001 going away` e `1013 try again later`, parsing dos flags do envelope, e exibição de staleness quando `ageMs` passar do tolerado pelo negócio. Com `WS_SNAPSHOT_ON_CONNECT` (default), a reconexão recebe o estado atual imediatamente.

## 5. Rodar e validar localmente

```bash
make run-memory                    # terminal 1: servidor sem Redis
make publisher rate=50             # terminal 2: produtor de teste (envelope correto)
make loadtest conns=1000           # terminal 3: 1000 conexões medindo idade p50/p95/p99
```

Validação de **super spike** (o critério de aceitação — PLAN §7):

```bash
make spike                         # regime estável + rajadas de 1000 msgs a cada 10s
make loadtest conns=10000          # com churn: go run ./cmd/loadtest -conns 10000 -churn 0.01
```

Aprovado quando: p99 de idade no cliente fica abaixo do limite do negócio **durante as rajadas**, e `ws_messages_dropped_total` cresce de forma controlada (coalescing agindo) sem atraso propagado.

O que olhar em `http://localhost:8080/metrics`: `ws_message_age_seconds` (p99 — alarme principal), `ws_active_connections`, `ws_messages_dropped_total`, `ws_broadcast_fanout_seconds`, `ws_rejected_full_total`.

Antes de todo commit: `make test` (vet + `-race`). Mudou hot path? `make bench` e compare `deliveries/s` com a baseline anterior no PR.

## 6. Deploy em produção

Checklist completo em [ARCHITECTURE.md](ARCHITECTURE.md#checklist-de-produção). Resumo do caminho ECS/Fargate:

1. **Imagem:** `make docker-build` (multi-stage → distroless, binário estático).
2. **Task definition:** `ulimits nofile = 1048576` (1 conexão = 1 fd — sem isso o teto real é ~1k!), env `GOMEMLIMIT` ≈ 85% da RAM da task.
3. **Sizing inicial:** 1 vCPU/1GB ≈ 25–50k conns; 2 vCPU/2GB ≈ 50–100k. Valide com `make loadtest` no ambiente real — o teto depende de msgs/s × payload.
4. **Topologia:** escala **vertical primeiro** (1 task forte), horizontal só para HA (2–4 tasks multi-AZ). Cada task assina o Redis e atende seus próprios clientes.
5. **ALB:** target `/healthz`, idle timeout > `WS_PING_INTERVAL` (ex.: 60s > 25s).
6. **Alarmes:** p99 `ws_message_age_seconds` acima da tolerância do negócio (o alarme do super spike); taxa de `ws_messages_dropped_total`; `ws_rejected_full_total` > 0.
7. **Picos previsíveis** (agenda de jogos): scheduled scaling antes do evento — autoscaling reativo não acompanha spike de 10 segundos.
8. **Deploy sem dor:** SIGTERM já dispara o drain com jitter (`WS_DRAIN_TIMEOUT`/`WS_DRAIN_JITTER`); confirme que o `stopTimeout` do ECS ≥ `WS_DRAIN_TIMEOUT`.

## 7. Receitas de alteração passo a passo

### 7.1 Adicionar um canal novo

1. Acrescente o nome em `WS_TOPICS` (env/task definition). 2. Redeploy. 3. Produtor publica no novo tópico. Pronto — métricas por canal aparecem automaticamente. *Sem código.*

### 7.2 Trocar/adicionar broker (ex.: NATS)

1. Crie `internal/broker/natsbroker/nats.go` implementando `broker.Broker` (3 métodos — use `redisbroker/redis.go` como referência).
2. Registre no switch de `cmd/server/main.go` (`case "nats":`) e adicione a opção em `config.validate()`.
3. Teste de contrato: replique `memory_test.go` contra a nova implementação.
4. **Escreva um ADR** (decisão de infra — template em `docs/adr/template.md`).

### 7.3 Adicionar um modo de entrega

1. Nova constante + caso em `ParseMode` (`internal/hub/client.go`).
2. Estruturas no `Client` + lógica em `push()` — **invariante inegociável: `push()` nunca pode bloquear** (ADR-0003/0004).
3. Caso de consumo no `writePump` (`internal/transport/ws.go`).
4. Testes no padrão de `TestCoalesceLatestWins` (inclusive o teste de não-bloqueio) + benchmark. ADR se mudar contrato com produtor/cliente.

### 7.4 Ativar autenticação (JWT HS256) — já implementada

1. Defina `WS_AUTH_SECRET`. Sem ele, o servidor aceita qualquer conexão.
2. Emita tokens HS256 com claims: `exp` (obrigatória), `sub` e opcionalmente `channels` (lista de canais autorizados — subscribe fora dela retorna `forbidden`).
3. Cliente envia via `?token=` ou `Authorization: Bearer`. Falhas: 401 no handshake, 403 para canal proibido na query, ack com erro no subscribe dinâmico.
4. Para RS256/JWKS (chave assimétrica), substitua `internal/auth` e registre um ADR.

### 7.5 Mudar o formato do payload (ex.: JSON → protobuf)

Nada muda no servidor: o payload é **opaco** após o envelope (ADR-0005). Alinhe produtor e cliente; o envelope e as métricas de idade continuam funcionando.

## 8. Convenções do projeto

| O quê | Onde |
|---|---|
| Configuração | Sempre env var com default em `internal/config` + linha no `.env.sample` + tabela do README |
| Decisão arquitetural | Novo ADR em `docs/adr/` no mesmo PR que a implementa |
| Hot path (broadcast/push/write) | Proibido: locks, alocações por mensagem, sends bloqueantes. Benchmark antes/depois no PR |
| Métricas | Registradas 1× no boot; nomes `ws_*`/`ingest_*`; toda nova falha silenciosa ganha counter |
| Testes | `make test` verde (vet + `-race`) é gate de commit; contratos de concorrência têm teste dedicado |
| Invariantes | Os 5 de [ARCHITECTURE.md](ARCHITECTURE.md#invariantes-de-performance) não se quebram em PR — se precisar quebrar, é ADR |
