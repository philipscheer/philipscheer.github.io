# Arquitetura de WebSockets — R10 Score

**Documento de Arquitetura e Recomendação Técnica**
Autor: Time de Engenharia · Data: 2026-06-11 · Status: Proposta

---

## 1. Resumo executivo

A camada de tempo real do R10 Score hoje sofre com um limite prático de **~5.000 conexões simultâneas por instância em Node.js**. Para crescer, a única alavanca disponível em Node é **escalar horizontalmente** — subir mais ECS services/tasks atrás de um load balancer com *sticky sessions*. Isso multiplica custo, complexidade operacional e número de conexões ao Redis sem resolver o gargalo de raiz: o *event loop* single-thread do Node e o custo de memória por conexão.

Este documento recomenda **consolidar a camada de WebSocket em Go** (este repositório, `r10-websockets`), usando o modelo de concorrência baseado em **goroutines** + *netpoller* (epoll). Uma única instância Go absorve a carga de **10 a 20 instâncias Node**, com custo de Fargate proporcionalmente menor e arquitetura mais simples.

O documento também:

1. Descreve a arquitetura atual (Go) e o fluxo de dados;
2. Explica **por que goroutines escalam melhor que escalar ECS services em Node** (modelo de concorrência + custo);
3. Lista **boas práticas de WebSocket** e aponta **3 gargalos concretos no código atual** que precisam ser corrigidos antes de escalar;
3b. Alerta para o **risco do super spike** (§6): uma degradação **invisível** em que a mensagem chega atrasada no pico, o usuário aposta sobre dado velho e a **rejeição sobe** — sem que nenhum painel do WS acuse o problema;
4. Apresenta um **modelo de custo comparativo** Node-horizontal × Go-vertical;
5. Define um **plano de migração** e métricas de aceitação.

---

## 2. Contexto e problema

### 2.1 Situação atual

Duas frentes foram levantadas pelo time:

> *"A aplicação roda em Node e temos uma limitação mesmo do sistema operacional, de uns 5k de connections no socket."*
> *"A gente quer trocar essa app de ingest pra Go."*
> *"Reorganizar o site para melhorar a UI/UX."* (fora do escopo deste documento)

O sistema entrega dados em tempo real via Pub/Sub em 5 tópicos × 3 idiomas:

- **Tópicos:** `stats`, `matches`, `incidents`, `bets`, `standings`
- **Idiomas:** `portuguese`, `english`, `spanish`
- **Canais:** `{tópico}-{idioma}` (ex.: `stats-portuguese`) + canais agregados por tópico → ~20 canais lógicos

O cliente assina **um canal por conexão**:

```
wss://websockets.<env>.r10score.com/ws?event={eventType}&language={language}
```

### 2.2 De onde vem o limite de ~5k em Node

O "limite de 5k" **não é** um limite rígido do sistema operacional — é a soma de três fatores:

1. **Event loop single-thread.** Node processa I/O em uma única thread. O *fan-out* (serializar uma mensagem e escrevê-la em milhares de sockets) compete com aceitar novas conexões, *parsing* e *heartbeats* na mesma thread. Acima de alguns milhares de sockets ativos, a latência de broadcast dispara.
2. **Memória por conexão.** Cada conexão carrega objetos JS no heap V8 (socket, buffers, closures, estado da `ws`). São dezenas a centenas de KB por conexão — o GC do V8 passa a dominar o CPU.
3. **`ulimit`/descritores de arquivo.** Cada conexão é um *file descriptor*. O default (1024) precisa ser elevado; mesmo elevado, os dois fatores acima batem antes.

Em Node, a saída de engenharia é **rodar N processos/containers**, cada um abaixo do teto, atrás de um LB com afinidade de sessão. É escalabilidade horizontal de um serviço **stateful** — cara e operacionalmente frágil.

---

## 3. Arquitetura atual (Go) — como já está implementada

Este repositório (`r10-websockets`) **já é** o servidor Go alvo. Stack:

- **`gorilla/websocket`** — upgrade HTTP→WS e I/O de frames
- **Redis Pub/Sub** (`go-redis/v8`) — ingestão dos eventos publicados pela dataloader
- **Protobuf** — serialização das mensagens enviadas ao cliente
- **AWS Fargate (ECS)** via `serverless-fargate` — runtime (atualmente `0.5GB` / `256` CPU)
- **ALB** com health check em `/healthz`

### 3.1 Fluxo de dados

```mermaid
flowchart LR
    DL[Dataloader / Ingest] -->|PUBLISH base64| R[(Redis Pub/Sub)]
    R -->|Subscribe 5 canais| SUB[RunRedisSubscriber<br/>1 goroutine]
    SUB -->|decode + protobuf por idioma| AC[AllWSChannel<br/>chan por canal]
    AC -->|1 goroutine por canal| BC[PublishWSMessageAllChannel<br/>fan-out]
    BC -->|clientWS.Channel| W1[Writer goroutine cliente 1]
    BC --> W2[Writer goroutine cliente 2]
    BC --> WN[Writer goroutine cliente N]
    W1 -->|WriteMessage| C1((Cliente 1))
    W2 --> C2((Cliente 2))
    WN --> CN((Cliente N))
```

### 3.2 Modelo de concorrência (o que faz escalar)

Por conexão aceita ([websockets.go](../src/server/api/websockets.go)), o servidor cria:

- **1 goroutine de leitura** — o loop `conn.ReadMessage()` que detecta o fechamento da conexão;
- **1 goroutine de escrita** — `PublishWSMessageSingle`, que drena o canal do cliente e escreve no socket;
- **1 goroutine transitória** de boas-vindas (`ConnectClient`).

O `ClientManager` ([manager.go](../src/server/schemas/manager.go)) mantém `map[canal]map[uuid]*ClientWS` protegido por um `sync.RWMutex`. A ingestão tem **1 goroutine** assinando o Redis e **1 goroutine por canal** fazendo o fan-out ([publisher.go](../src/server/api/publisher.go), [redis.go](../src/server/api/redis.go)).

É o padrão clássico **goroutine-per-connection**: o *runtime* do Go multiplexa centenas de milhares de goroutines sobre poucas threads do SO via o **netpoller (epoll)**, sem que o programador gerencie threads.

---

## 4. Por que Go escala melhor que escalar ECS services em Node

### 4.1 Modelo de concorrência

| Dimensão | Node.js | Go |
|---|---|---|
| Modelo | Event loop single-thread + libuv | Scheduler M:N (goroutines sobre threads do SO) |
| Uso de CPU | 1 core por processo (precisa `cluster`/N processos) | Todos os cores automaticamente (`GOMAXPROCS`) |
| Custo por conexão | Objetos JS no heap V8 (dezenas–centenas de KB) | Goroutine ~2–8 KB de stack inicial, cresce sob demanda |
| Fan-out (broadcast) | Serializa na única thread; compete com I/O | Paralelizável por canal/goroutine entre cores |
| Teto prático/instância | ~5k conexões ativas | 50k–100k+ conexões (limitado por taxa de fan-out e RAM) |
| Pressão de GC | V8 GC sobre milhares de objetos por conexão | GC do Go sobre estruturas pequenas; muito menor |

**Consequência direta:** o que em Node exige **muitos processos/containers** (escala horizontal stateful), em Go cabe em **um processo usando todos os cores** (escala vertical), e a escala horizontal vira apenas **redundância/HA** — não obrigação para atingir capacidade.

### 4.2 Por que escalar ECS Node é caro e frágil

Escalar a camada WS em Node significa subir mais ECS tasks. Como WebSocket é **stateful** (a conexão vive na task), isso obriga:

1. **Sticky sessions no ALB** — afinidade por conexão; rebalanceamento ruim quando uma task cai (milhares de clientes reconectam de uma vez → *thundering herd*).
2. **Mais conexões ao Redis** — cada task é um subscriber; o fan-out do Redis e o número de conexões crescem linearmente com o número de tasks.
3. **Mais overhead fixo por task** — runtime, sidecars, health checks, logging, footprint base de memória repetido N vezes.
4. **Operação mais complexa** — deploys, rolling updates e *draining* de conexões em 20–30 tasks são muito mais arriscados que em 2–4.
5. **Desperdício de CPU** — cada task Node usa efetivamente ~1 core; pagar por vCPU fracionado em dezenas de tasks é menos eficiente que poucas tasks Go saturando seus cores.

### 4.3 Modelo de custo (ilustrativo)

Premissas (Fargate `us-east-1`, sob demanda): **vCPU $0,04048/h**, **GB $0,004445/h**. Cenário: **100.000 conexões simultâneas** em pico.

**Opção A — Node horizontal**
~5k conexões/task → 20 tasks só para capacidade; com folga/HA assuma **26 tasks** de `0,5 vCPU + 1 GB`.

```
CPU:  26 × 0,5 × 0,04048 = $0,526/h
RAM:  26 × 1,0 × 0,004445 = $0,116/h
Total ≈ $0,642/h ≈ $462/mês  (+ overhead operacional de 26 tasks stateful)
```

**Opção B — Go vertical**
~50k conexões/task → 2 tasks para capacidade; com HA assuma **4 tasks** de `1 vCPU + 1 GB`.

```
CPU:  4 × 1,0 × 0,04048 = $0,162/h
RAM:  4 × 1,0 × 0,004445 = $0,018/h
Total ≈ $0,180/h ≈ $130/mês  (4 tasks, deploy simples)
```

> **~70% de redução de custo de compute** e ~6× menos tasks para operar. Os números absolutos dependem da taxa real de mensagens/segundo e do tamanho do payload protobuf — mas a **razão estrutural** (Node usa 1 core/processo; Go usa todos) se mantém em qualquer escala. *Recomenda-se validar com teste de carga real antes de fechar o dimensionamento (ver §6).*

---

## 5. Boas práticas de WebSocket + correções necessárias no código atual

A migração para Go **não basta por si só**: o código atual tem padrões que limitam o ganho de escala. Abaixo, boas práticas e os pontos concretos a corrigir.

### 5.1 🔴 Crítico — Broadcast bloqueante com lock global (head-of-line blocking)

Em [publisher.go:50-65](../src/server/api/publisher.go#L50-L65), `PublishWSMessageAllChannel`:

- segura `MuClients.Lock()` (lock de **escrita**) durante **todo** o broadcast;
- envia em `clientWS.Channel <- message`, e esse canal é **não-bufferizado** (`make(chan []byte)` em [client.go:18](../src/server/schemas/client.go#L18)).

**Efeito:** um único cliente lento (ou cuja goroutine de escrita esteja momentaneamente ocupada em `WriteMessage`) **bloqueia o broadcast inteiro** e, como o lock global está retido, **trava também novas conexões e desconexões** naquele instante. Esse é exatamente o tipo de acoplamento que impede passar de alguns milhares de conexões.

**Recomendações:**

1. **Canais bufferizados por cliente** (ex.: `make(chan []byte, 16)`).
2. **Envio não-bloqueante** com descarte do cliente lento:
   ```go
   select {
   case clientWS.Channel <- message:
   default:
       // cliente lento: descartar mensagem (ou marcar p/ desconexão)
   }
   ```
3. **`RLock()` em vez de `Lock()`** no broadcast — ele só lê o mapa de clientes; o lock de escrita deve ficar apenas em add/remove.
4. Idealmente, **copiar a lista de ponteiros sob RLock** e fazer o envio fora do lock.

### 5.2 🟠 Importante — Keepalive: ping/pong e deadlines

A goroutine de leitura ([websockets.go:77-84](../src/server/api/websockets.go#L77-L84)) só detecta queda quando o TCP falha — conexões "meio-abertas" (cliente sumiu sem FIN) podem ficar penduradas indefinidamente, consumindo memória.

**Recomendações (padrão `gorilla/websocket`):**

- `conn.SetReadDeadline(...)` + `conn.SetPongHandler(...)` para renovar o deadline a cada pong;
- enviar **ping periódico** (ex.: a cada 30s) na goroutine de escrita;
- `conn.SetWriteDeadline(...)` antes de cada `WriteMessage` para não travar em socket morto;
- definir `conn.SetReadLimit(...)` (os clientes só assinam; não devem enviar payloads grandes).

### 5.3 🟠 Importante — Contenção do mutex global / sharding

Add/remove ([client.go:18-44](../src/server/api/client.go#L18-L44)) e broadcast disputam o **mesmo** `MuClients`. Em alta escala isso vira ponto de contenção.

**Recomendações:**

- Após corrigir §5.1 (RLock no broadcast), a contenção já cai muito;
- Se necessário, **shardar** o mapa de clientes por canal (cada canal com seu próprio lock) — os 20 canais são independentes;
- `RemoveClientWS` hoje itera **todos** os canais para apagar por id; como o cliente pertence a **um** canal, guardar o canal no `ClientWS` e apagar em O(1).

### 5.4 🟡 Recomendações gerais

- **Limite de conexões por instância** + rejeição graciosa (HTTP 503) acima do teto, para o autoscaling agir antes da degradação.
- **Graceful shutdown / connection draining**: ao receber `SIGTERM` (deploy/scale-in), parar de aceitar conexões, sinalizar reconexão aos clientes e drenar — evita *thundering herd*.
- **Backoff de reconexão no cliente** (jitter) para suavizar reconexões em massa.
- **Origin check real** em produção — hoje `CheckOrigin` retorna `true` sempre ([websockets.go:46](../src/server/api/websockets.go#L46)); restringir aos domínios R10.
- **Compressão** (`permessage-deflate`) avaliada caso a caso (troca CPU por banda).
- **Observabilidade**: expor métricas (conexões ativas por canal, mensagens/s, tamanho de buffer dos canais, mensagens descartadas, latência de broadcast) via Prometheus/CloudWatch.

---

## 6. O risco do Super Spike: a degradação invisível

> **Este é o risco mais importante do sistema — e o mais difícil de detectar.**

O problema não está no regime estável. Está no **super spike**: o instante em que um evento (gol, pênalti, cartão, fim de jogo) dispara, ao mesmo tempo, um **pico de mensagens** (odds e stats recalculadas em rajada) e um **pico de reconexões/atividade** dos usuários. É exatamente quando o sistema mais precisa estar rápido — e é quando ele degrada.

### 6.1 Por que a falha é *invisível*

Numa degradação de WS, **nada quebra de forma óbvia**:

- o health check `/healthz` continua **verde** (o processo está vivo);
- não há erro 5xx, não há exceção, não há alarme de CPU necessariamente;
- a conexão WebSocket permanece **aberta**.

O único sintoma é: **a mensagem chega atrasada**. Alguns segundos de atraso de broadcast no pico — invisíveis para qualquer monitoramento que olhe só "está no ar?" / CPU / contagem de conexões.

### 6.2 O impacto no negócio: aumento de rejeição

A cadeia de dano é direta:

```
Super spike → broadcast atrasa → cliente vê odd/stat DESATUALIZADA
            → usuário aposta sobre o preço velho
            → motor de risco rejeita (a odd já mudou)
            → TAXA DE REJEIÇÃO sobe
```

E o pior: o problema é **atribuído à causa errada**. Como o WS aparenta saúde, a alta de rejeição é debitada ao backend de apostas / motor de risco, e o tempo de investigação é gasto no lugar errado. É um custo de receita (GGR) e de UX que **não aparece no painel do WS**.

> Em apostas ao vivo, atraso de poucos segundos no momento de pico **é** o problema — não um detalhe de performance.

### 6.3 Como o código atual *amplifica* o spike

O gargalo da [§5.1](#51--crítico--broadcast-bloqueante-com-lock-global-head-of-line-blocking) é o que transforma um pico em atraso invisível para **todos**:

- o broadcast segura o **lock global** e envia em **canais não-bufferizados**;
- no spike, o cliente mais lento (rede móvel ruim, aba em background) **vira o relógio de todo o broadcast** — head-of-line blocking;
- o atraso não fica isolado no cliente lento: ele **se propaga para toda a base** do canal.

Ou seja: sem a correção da §5.1, o super spike não degrada *um* cliente — degrada *todos*, silenciosamente.

### 6.4 Solução: tornar o invisível visível e degradar de forma controlada

**1. Latest-wins (coalescing), nunca backlog de frames velhos.**
Para odds/stats, entregar um *backlog* de 50 preços velhos é pior que entregar só o último. Use buffer limitado por cliente com política **drop-oldest**: se o cliente está atrasado, descarte os frames intermediários e entregue **o estado mais recente**. Isso converte "atraso crescente para todos" em "sempre o dado mais novo, descarte controlado do obsoleto".

**2. Carimbo de tempo / sequência na mensagem.**
Incluir `timestamp`/`seq` no payload protobuf permite que:
- o servidor **descarte mensagens já obsoletas** antes de escrevê-las;
- o cliente **detecte staleness** e a UI mostre "reconectando / dado defasado" em vez de deixar o usuário apostar sobre preço velho. Degradação **visível e segura** > rejeição silenciosa.

**3. Medir idade de ponta a ponta — o alarme que falta.**
Instrumentar e alarmar sobre **latência**, não só "está no ar":
- **idade da mensagem** (publish na dataloader → escrita no socket) — p99;
- **lag de broadcast** por canal;
- **ocupação dos buffers** dos clientes e **mensagens descartadas/s**.

Alarmar quando o p99 de idade passar de um limite (ex.: o motor de risco tolera). É isso que torna o super spike **visível** antes de virar rejeição.

**4. Pré-escalar janelas de pico conhecidas.**
Autoscaling reativo (CPU) é **lento demais** para um spike de 10 segundos num gol — e WS é stateful, escala devagar. Para jogos grandes, **pré-provisionar capacidade por agenda** (scheduled scaling) com folga, em vez de esperar a métrica reagir.

### 6.5 Critério de aceitação do spike

A migração só está pronta quando, **sob carga de super spike simulada** (rajada de mensagens + reconexões), o p99 de idade da mensagem no cliente permanecer abaixo do limite tolerado pelo motor de risco — e não apenas quando o servidor "não cai". Ver fase 2 do plano (§8).

---

## 7. Estratégia de escalabilidade recomendada

```mermaid
flowchart TB
    subgraph AWS
      ALB[ALB / NLB<br/>WSS termina TLS]
      subgraph ECS[ECS Fargate]
        T1[Task Go 1<br/>todos os cores]
        T2[Task Go 2]
        T3[Task Go N - HA]
      end
      RDS[(Redis Pub/Sub<br/>ElastiCache)]
    end
    Clientes((Clientes WSS)) --> ALB --> T1 & T2 & T3
    DL[Dataloader] --> RDS --> T1 & T2 & T3
```

**Princípios:**

1. **Escalar verticalmente primeiro.** Dar **vCPUs e RAM** à task Go (ex.: `1–2 vCPU / 1–2 GB`) e deixar o scheduler usar todos os cores. Uma task forte > muitas tasks fracas.
2. **Horizontal só para HA e além do teto vertical.** 2–4 tasks bastam para redundância em multi-AZ; cada uma é subscriber do Redis e recebe todas as mensagens, fazendo fan-out só para os clientes que ela detém.
3. **Autoscaling por conexões ativas / CPU** (métrica custom no CloudWatch), não só CPU.
4. **Redis (ElastiCache) como ponto único de fan-out** entre dataloader e as tasks — já é o desenho atual.
5. **TLS/WSS no ALB**, health check em `/healthz` (já implementado em [websockets.go:28-34](../src/server/api/websockets.go#L28-L34)).

---

## 8. Plano de migração

| Fase | Entregável | Critério de aceitação |
|---|---|---|
| 0. Baseline | Teste de carga no Node atual | Documentar conexões máx., latência de broadcast, CPU/RAM |
| 1. Correções de escala (Go) | Aplicar §5.1, §5.2, §5.3 | Broadcast não-bloqueante; ping/pong; sem lock de escrita no fan-out |
| 2. Teste de carga (Go) | Stress test (ver `make client-stress`) | 1 task Go sustenta ≥ 50k conexões com latência de broadcast < alvo |
| 2b. Teste de **super spike** (§6) | Rajada de mensagens + reconexões em massa | **p99 de idade da mensagem no cliente < limite do motor de risco**; latest-wins funcionando; zero atraso propagado |
| 3. Deploy paralelo | Go atrás de hostname canário | Subconjunto de tráfego real; comparar métricas (inclusive idade da mensagem) com Node |
| 4. Cutover | Migrar tráfego para Go; ajustar `desiredCount`/recursos | Erros e latência dentro do SLA; rollback pronto |
| 5. Decomissionar Node | Remover ECS services Node | Custo de compute reduzido conforme §4.3 |

> A ferramenta de stress test já existe no repo: `make client-stress clients={n}` ([stress_testing](../src/client/stress_testing/main.go)). Use-a (em ambiente dedicado, vários geradores de carga) para validar o teto real por task antes do dimensionamento final.

---

## 9. Recomendação final

1. **Adotar Go como camada definitiva de WebSocket** (este repositório). O modelo goroutine + netpoller resolve o gargalo de raiz do Node (event loop single-thread + custo de memória por conexão), e não apenas o adia com mais containers.
2. **Antes de declarar pronto para produção em escala, corrigir os 3 gargalos da §5** — em especial o **broadcast bloqueante com lock global (§5.1)**, que hoje limitaria o ganho mesmo em Go.
3. **Tratar o super spike (§6) como requisito de primeira classe**: instrumentar e alarmar **idade de ponta a ponta da mensagem** (não só "está no ar"), adotar **latest-wins** (drop-oldest) no fan-out, carimbar `timestamp`/`seq` no payload e **pré-escalar janelas de pico conhecidas**. É o que evita a degradação invisível que aumenta a rejeição.
4. **Dimensionar por escala vertical** (mais vCPU/RAM por task) e usar horizontal apenas para HA — reduzindo custo de Fargate em ~70% e o número de tasks operadas em ~6× no cenário de 100k conexões.
5. **Validar com teste de carga** (`make client-stress`), incluindo um **cenário de super spike**, os números reais antes do cutover; o critério não é "o servidor não cai", e sim **p99 de idade da mensagem abaixo do limite do motor de risco**. Ajustar `cpu`/`memory` no [serverless.yml](../serverless.yml) conforme o resultado.
6. Tratar a **reorganização de UI/UX do site** como frente separada, sem dependência técnica desta migração.

---

### Anexo — referências de código

- Aceite de conexão e goroutines por cliente: [src/server/api/websockets.go](../src/server/api/websockets.go)
- Broadcast / fan-out (gargalo §5.1): [src/server/api/publisher.go](../src/server/api/publisher.go)
- Ingestão Redis → canais: [src/server/api/redis.go](../src/server/api/redis.go)
- Estado dos clientes e mutex: [src/server/schemas/manager.go](../src/server/schemas/manager.go), [src/server/schemas/client.go](../src/server/schemas/client.go)
- Reconexão ao Redis: [src/server/utils/redis/redis_utils.go](../src/server/utils/redis/redis_utils.go)
- Deploy Fargate: [serverless.yml](../serverless.yml), [deploy/ECS_methods.py](../deploy/ECS_methods.py)
