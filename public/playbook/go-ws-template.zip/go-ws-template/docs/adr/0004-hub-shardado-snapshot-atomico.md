# ADR-0004: Hub shardado com snapshot atômico (broadcast sem lock)

**Status:** Aceito
**Data:** 2026-06-11
**Autores:** Philip Scheer <philipscheer@grupootg.com>

## Contexto

No servidor anterior, broadcast e add/remove de clientes disputavam o **mesmo mutex global**, e o broadcast retinha lock de **escrita** durante todo o fan-out — novas conexões e desconexões travavam a cada mensagem. O fan-out é o hot path: roda milhões de vezes por minuto, enquanto o churn de membros é ordens de magnitude menor.

## Decisão

O hub é particionado em **um shard por canal**, e cada shard mantém a lista de clientes em um **snapshot imutável** (`atomic.Pointer[[]*Client]`):

- **Broadcast** lê o snapshot com um load atômico — zero locks, zero alocações.
- **Add/remove** pega o mutex do shard, altera o mapa e **reconstrói** o snapshot (O(n) no churn, irrelevante perto da frequência de broadcast).
- O conjunto de canais é **imutável após o boot** (vem de `WS_TOPICS`), então o mapa de shards dispensa lock.

Alternativas consideradas:

- **RWMutex no broadcast (RLock)** — melhor que o lock de escrita, mas ainda invalida cache line entre cores a cada broadcast e serializa com escritores; o snapshot elimina o custo por completo.
- **sync.Map** — semântica genérica, sem snapshot consistente para iteração de fan-out; mais lenta nesse padrão de acesso.
- **Canais dinâmicos (criados on-demand)** — exigiria lock no mapa de shards no hot path; a lista fixa por env cobre o caso de uso e mantém o invariante.

## Consequências

- (+) Custo de fan-out = iterar um slice + 1 push lock-free por cliente; escala linearmente e paraleliza entre canais.
- (+) Remoção O(1) (cliente conhece seu canal).
- (−) Adicionar canal exige restart (deploy) — aceitável: a lista de tópicos é configuração de produto, não dado dinâmico.
- (−) Broadcast de um canal roda em 1 goroutine; com 100k+ clientes em um único canal, paralelizar o fan-out intra-canal é a próxima fronteira (IMPROVEMENTS §4).
