# ADR-0007: Multiplexação de canais por conexão (protocolo v1.1)

**Status:** Aceito
**Data:** 2026-06-11
**Autores:** Philip Scheer <philipscheer@grupootg.com>

## Contexto

No modelo herdado do r10, cada conexão assinava exatamente 1 canal — um cliente que acompanha `stats` + `incidents` + `bets` abre 3 sockets (3× fds, memória, handshakes TLS e reconexões). Com a meta de centenas de milhares de usuários simultâneos, o número de conexões é o principal driver de custo por máquina (IMPROVEMENTS §5).

## Decisão

Uma conexão passa a ser uma **sessão** com até `WS_MAX_SUBSCRIPTIONS` assinaturas:

- **Assinatura inicial** por query string (`?channels=a,b`; `?channel=` e `?event=&language=` seguem aceitos como compat).
- **Protocolo de controle** em frames TEXT JSON: `{"action":"subscribe","channels":[...]}` / `unsubscribe`, respondidos com `{"type":"ack",...}` (acks são best-effort, via fila própria no write pump).
- **Frames de dados** (BINARY) carregam a **extensão de canal** no envelope (flag `0x02`) — o cliente sabe a qual canal cada mensagem pertence.
- Cada assinatura tem **mailbox próprio** (latest-wins/keyed/buffer); a sessão tem **um único write pump** acordado por sinalização dedup (`Session.dirty`), sem `reflect.Select` nem goroutines extras por canal.

Alternativas consideradas:

- **1 canal por conexão (status quo)** — simples, mas multiplica conexões por cliente; rejeitada pelo custo.
- **Um WebSocket por canal com HTTP/2 (RFC 8441)** — suporte de infraestrutura (ALB) e clientes irregular.
- **Subprotocolo binário de controle** — JSON em frames TEXT é desprezível em volume (controle é raro) e trivial de depurar.

## Consequências

- (+) Redução de até N× em conexões/fds/memória por usuário; reconexão única no failover.
- (+) Métrica nova `ws_active_subscriptions{channel}`; `ws_active_connections` passa a contar sessões (sem label de canal) — **dashboards precisam ser ajustados**.
- (−) **Breaking change de protocolo** para clientes que liam payload no offset 20: o frame agora carrega a extensão de canal; parsers devem honrar os flags do envelope (ADR-0005). Aceitável pré-produção; SDK de referência atualizado em `cmd/loadtest` e no README.
- (−) Complexidade do hub aumenta (sessão/assinatura/sinalização dedup) — coberta por testes de corrida e e2e dedicados.
