# Architecture Decision Records (ADRs)

Toda decisão arquitetural relevante deste projeto é registrada aqui como um ADR — um documento curto e imutável que captura **contexto, decisão e consequências** no momento em que foi tomada. É a prática que evita o "por que isso é assim?" seis meses depois.

## Regras

1. **Quando criar:** qualquer decisão difícil de reverter ou que restrinja decisões futuras — escolha de biblioteca, protocolo, modelo de concorrência, broker, formato de mensagem.
2. **Numeração sequencial** (`0007-...`), nunca reutilizada. Arquivo: `NNNN-titulo-curto-com-hifens.md`.
3. **ADRs são imutáveis.** Mudou a decisão? Crie um novo ADR e marque o antigo como `Substituído por ADR-NNNN`. Não edite o histórico.
4. **Curto.** Uma página. Se precisa de mais, o anexo vai em `docs/` e o ADR linka.
5. **No PR.** O ADR entra no mesmo PR que implementa a decisão — revisão de código e de decisão juntas.

Use o [template](template.md).

## Índice

| ADR | Título | Status |
|---|---|---|
| [0001](0001-goroutine-per-connection-gorilla.md) | Goroutine-per-connection com gorilla/websocket | Aceito |
| [0002](0002-redis-pubsub-atras-de-interface.md) | Redis Pub/Sub atrás de interface Broker | Aceito |
| [0003](0003-mailbox-latest-wins.md) | Mailbox latest-wins por cliente (coalescing) | Aceito |
| [0004](0004-hub-shardado-snapshot-atomico.md) | Hub shardado com snapshot atômico (broadcast sem lock) | Aceito |
| [0005](0005-envelope-binario-seq-timestamp.md) | Envelope binário com seq + timestamp de publicação | Aceito |
| [0006](0006-metricas-prometheus-stdlib.md) | Métricas Prometheus em stdlib (sem client_golang) | Aceito |
| [0007](0007-multiplexacao-de-canais.md) | Multiplexação de canais por conexão (protocolo v1.1) | Aceito |
| [0008](0008-keyed-coalescing.md) | Keyed coalescing (latest-wins por chave de entidade) | Aceito |
