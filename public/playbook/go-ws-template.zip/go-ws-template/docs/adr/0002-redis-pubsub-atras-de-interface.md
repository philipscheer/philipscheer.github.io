# ADR-0002: Redis Pub/Sub atrás de interface Broker

**Status:** Aceito
**Data:** 2026-06-11
**Autores:** Philip Scheer <philipscheer@grupootg.com>

## Contexto

A ingestão de eventos precisa desacoplar o produtor (dataloader) das N instâncias do servidor WS. A infra existente do grupo já opera Redis (ElastiCache) como Pub/Sub entre dataloader e o servidor atual.

## Decisão

A ingestão é definida pela interface **`broker.Broker`** (`Subscribe`/`Publish`/`Close`). A implementação padrão é **Redis Pub/Sub** (`go-redis/v9`); existe uma implementação **memory** para desenvolvimento e testes. Trocar de broker = nova implementação da interface, sem tocar em hub/transport.

Alternativas consideradas:

- **Acoplar direto ao go-redis** — menos uma abstração, mas qualquer mudança de broker viraria refactor invasivo.
- **NATS** — maior throughput e menor latência, porém nova peça de infra para operar sem necessidade atual.
- **Kafka** — entrega garantida e replay, custo operacional alto; desnecessário para dados de estado em que o próximo update corrige o anterior.

## Consequências

- (+) Compatível com a infra atual; migração do r10 sem mudança no produtor (exceto envelope — ADR-0005).
- (+) Testes e dev local sem Redis (`BROKER_KIND=memory`).
- (−) Redis Pub/Sub é **at-most-once**: mensagens são perdidas em failover do Redis ou subscriber saturado. Aceitável para estado; inaceitável para eventos contábeis — nesse caso, implementar broker JetStream/Kafka (IMPROVEMENTS §15).
- (−) Cada instância recebe todas as mensagens de todos os tópicos (fan-out completo no Redis); com muitas instâncias, avaliar sharded Pub/Sub (IMPROVEMENTS §8).
