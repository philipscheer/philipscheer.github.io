# ADR-0003: Mailbox latest-wins por cliente (coalescing)

**Status:** Aceito
**Data:** 2026-06-11
**Autores:** Philip Scheer <philipscheer@grupootg.com>

## Contexto

O gargalo crítico do servidor anterior (r10): broadcast segurava lock global e enviava em canais não-bufferizados — um único cliente lento atrasava **todos** (head-of-line blocking). No super spike (gol/pênalti), isso degrada a base inteira silenciosamente: a mensagem chega atrasada, o usuário aposta sobre odd velha e a rejeição sobe sem nenhum alarme do WS acusar (ver `docs/referencia/arquitetura-websockets-r10.md` §6).

Para dados de **estado** (odds, placares), entregar backlog de valores velhos é pior que entregar somente o mais recente.

## Decisão

Cada cliente tem um **mailbox** cuja entrega (`Client.push`) **nunca bloqueia** o broadcaster, com duas políticas:

- **`coalesce` (default, latest-wins):** slot `atomic.Pointer` — só a mensagem mais recente sobrevive; cliente atrasado pula direto para o estado atual.
- **`buffer`:** fila bounded com drop-oldest, para streams onde cada mensagem importa.

Descartes são contados em `ws_messages_dropped_total`.

Alternativas consideradas:

- **Fila ilimitada por cliente** — converte cliente lento em vazamento de memória; rejeitada.
- **Bloquear até o cliente drenar** — é exatamente o head-of-line blocking que estamos eliminando; rejeitada.
- **Desconectar imediatamente o cliente lento** — punitivo demais para hiccups de rede móvel; a política de desconexão por drop sustentado fica como evolução (IMPROVEMENTS §2).

## Consequências

- (+) Atraso não se propaga entre clientes; broadcast nunca trava; degradação é individual, mensurável e controlada.
- (−) **Contrato com o produtor:** no modo `coalesce`, cada mensagem deve carregar o **estado completo** do canal (snapshot), pois mensagens intermediárias podem ser descartadas para clientes lentos. Updates incrementais exigiriam keyed coalescing (IMPROVEMENTS §1).
- (−) Em `buffer`, sob saturação o cliente perde as mensagens mais antigas — by design.
