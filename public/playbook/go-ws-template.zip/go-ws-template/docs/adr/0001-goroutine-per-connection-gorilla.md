# ADR-0001: Goroutine-per-connection com gorilla/websocket

**Status:** Aceito
**Data:** 2026-06-11
**Autores:** Philip Scheer <philipscheer@grupootg.com>

## Contexto

O template substitui uma camada Node.js limitada a ~5k conexões por instância (event loop single-thread + custo de heap V8 por conexão). Precisamos de 50k–100k+ conexões por task Fargate com fan-out de milhões de msgs/s, mantendo o código operável por um time que já conhece o stack do `r10-websockets`.

## Decisão

Usaremos **gorilla/websocket** com o padrão **goroutine-per-connection** (1 read pump + 1 write pump por conexão), deixando o netpoller do runtime Go (epoll) multiplexar as goroutines sobre poucas threads.

Alternativas consideradas:

- **gobwas/ws + epoll manual** — menor RAM/conexão (~4KB vs ~16KB) e suporta 1M+ conns/máquina, mas exige gerenciar o event loop, parsing parcial de frames e timeouts manualmente; complexidade não justificada antes do teto de ~150–200k conns/task (ver IMPROVEMENTS §14).
- **coder/websocket** — API moderna, porém sem `PreparedMessage`; o frame seria serializado por cliente, custo proibitivo no fan-out massivo.
- **uWebSockets via CGO** — performance excelente, mas CGO complica build/imagem e debugging.

## Consequências

- (+) Código linear e simples de raciocinar; `PreparedMessage` serializa o frame 1× por broadcast.
- (+) Familiaridade do time (mesma lib do r10).
- (−) ~2 goroutines + ~16KB por conexão → ~2GB de overhead em 100k conns; teto vertical prático na casa de centenas de milhares de conexões por task.
- Gatilho de revisão: atingir esse teto ou o custo de RAM dominar o sizing → migrar transporte para epoll (a interface `transport` isola a troca).
