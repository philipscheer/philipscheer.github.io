# ADR-0005: Envelope binário com seq + timestamp de publicação

**Status:** Aceito
**Data:** 2026-06-11
**Autores:** Philip Scheer <philipscheer@grupootg.com>

## Contexto

A falha mais perigosa de uma camada de WS de apostas ao vivo é **invisível**: no pico, a mensagem chega atrasada, o usuário age sobre dado velho e a taxa de rejeição sobe — enquanto health check, CPU e contagem de conexões seguem normais. Sem um timestamp de origem na mensagem, é **impossível** medir a idade ponta a ponta (publish → socket → cliente).

## Decisão

Toda mensagem carrega um **envelope binário de 20 bytes** antes do payload opaco:

```
[0:2] magic 0x5753 | [2] versão | [3] flags | [4:12] seq u64 | [12:20] publish_ts (µs Unix) | [20:] payload
```

Com ele: o servidor mede `ws_message_age_seconds` na escrita (alarme de p99), o cliente detecta staleness e pode exibir "dado defasado", e `seq` permite detectar perda/raça no consumidor. Payloads sem envelope são **tolerados** (encaminhados + contados em `ingest_invalid_envelope_total`) para permitir adoção gradual pelos produtores.

Alternativas consideradas:

- **Timestamp dentro do payload (protobuf/JSON)** — obrigaria o servidor a conhecer e decodificar o schema de cada produto; o envelope mantém o payload 100% opaco.
- **Sem envelope, medir só latência interna** — não captura o atraso de fila no broker nem permite staleness no cliente; era exatamente o ponto cego do sistema anterior.
- **Header textual (JSON)** — parsing mais caro no hot path e payload maior; 20 bytes fixos custam 2 loads + bounds check.

## Consequências

- (+) O super spike vira métrica e alarme em vez de incidente invisível; critério de aceitação objetivo (p99 < tolerância do motor de risco).
- (−) Produtores precisam envelopar (16 linhas de código; `internal/envelope` + `cmd/publisher` de referência) e clientes pular 20 bytes.
- (−) Versão no byte [2] precisa ser respeitada em evoluções (campo `flags` reservado para extensões, ex.: chave de entidade do keyed coalescing).
