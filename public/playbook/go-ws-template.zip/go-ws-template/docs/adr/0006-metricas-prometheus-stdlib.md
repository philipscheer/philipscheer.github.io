# ADR-0006: Métricas Prometheus em stdlib (sem client_golang)

**Status:** Aceito
**Data:** 2026-06-11
**Autores:** Philip Scheer <philipscheer@grupootg.com>

## Contexto

Observabilidade é requisito de primeira classe (idade de mensagem, drops, fan-out), com observações no hot path — milhões por segundo. O template tem como princípio a superfície mínima de dependências (supply chain, build, imagem).

## Decisão

Implementamos contadores, gauges e histogramas com **atomics da stdlib** e exposição manual no **formato de texto do Prometheus** (`internal/metrics`, ~250 linhas). O conjunto de séries é fixo no boot (canais conhecidos), o que permite registrar instrumentos uma vez e observar sem locks.

Alternativas consideradas:

- **prometheus/client_golang** — padrão de mercado, mas traz árvore de dependências relevante e custo de labels dinâmicos que não usamos; o formato de exposição é idêntico, então a troca futura é transparente para o Prometheus.
- **OpenTelemetry metrics** — flexível, porém SDK pesado e em movimento; tracing OTel pode ser adicionado depois sem conflito.
- **expvar (JSON)** — sem histogramas nem integração nativa com Prometheus/CloudWatch.

## Consequências

- (+) Custo por observação: 1–2 operações atômicas; zero dependências; scrape padrão Prometheus funciona.
- (−) Sem features avançadas (summaries, exemplars, labels dinâmicos). Se surgirem requisitos assim, migrar para client_golang — a interface dos instrumentos é compatível conceitualmente e a troca fica contida em `internal/metrics` + injeção no boot.
- (−) Histogramas usam buckets fixos (`DefaultLatencyBuckets`); ajustar exige recompilar — aceitável, são SLOs de latência estáveis.
