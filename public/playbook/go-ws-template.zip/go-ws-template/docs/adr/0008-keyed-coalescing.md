# ADR-0008: Keyed coalescing (latest-wins por chave de entidade)

**Status:** Aceito
**Data:** 2026-06-11
**Autores:** Philip Scheer <philipscheer@grupootg.com>

## Contexto

O latest-wins por canal (ADR-0003) exige que cada mensagem carregue o **estado completo** do canal — caso contrário, um assinante lento que sofre coalescing perde o update da entidade A quando o update da entidade B chega depois, e fica com A defasado até o próximo publish de A (IMPROVEMENTS §1). Para canais com muitas entidades (odds de dezenas de jogos), o snapshot completo por mensagem cresce e o custo de banda/serialização passa a doer.

## Decisão

Novo modo de entrega **`coalesce-keyed`**: o produtor declara a **chave da entidade** no envelope (extensão flag `0x01`, ex.: `match:123`), e o mailbox do assinante guarda o **estado mais recente por chave** (mapa + FIFO de chaves). Assinante atrasado recebe exatamente 1 mensagem por entidade — sempre a mais nova. Snapshot-on-connect em modo keyed reproduz o último estado de **todas** as chaves conhecidas do canal.

Alternativas consideradas:

- **Contrato de snapshot completo (ADR-0003)** — continua sendo o default (`coalesce`) e a opção mais simples; keyed é para quando payloads completos ficam grandes.
- **Canal por entidade** (`odds-match-123`) — explode o número de canais (dinâmicos), quebrando o invariante de canais fixos do ADR-0004 e multiplicando assinaturas.
- **Diff/patch no cliente** — complexidade de sincronização (estado base + sequência contígua) incompatível com drop controlado.

## Consequências

- (+) Updates incrementais por entidade com correção sob coalescing; banda proporcional ao que mudou.
- (+) Mensagem sem chave funciona no modo keyed (chave vazia = slot único), permitindo migração gradual.
- (−) Mailbox keyed usa um mutex curto por assinatura (em vez de slot atômico puro); custo medido em benchmark — irrelevante perto do I/O.
- (−) Memória por assinante lento cresce com o nº de entidades ativas do canal (bounded pelo universo de chaves; monitorar `ws_messages_dropped_total` e RAM).
- Produtores precisam usar `envelope.EncodeKeyed` (referência em `cmd/publisher -keys N`).
