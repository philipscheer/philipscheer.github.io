# ADR-NNNN: Título curto da decisão

**Status:** Proposto | Aceito | Rejeitado | Substituído por ADR-NNNN
**Data:** AAAA-MM-DD
**Autores:** nome <email>

## Contexto

Qual problema ou força motivou esta decisão? Quais restrições existiam (prazo, infra, time, compatibilidade)? Fatos, não opiniões.

## Decisão

O que foi decidido, em voz ativa: "Usaremos X para Y". Inclua as alternativas consideradas e por que perderam — 1 a 2 linhas por alternativa.

## Consequências

O que fica mais fácil, o que fica mais difícil, que dívidas assumimos e qual o gatilho para revisitar. Consequências negativas são obrigatórias — toda decisão tem custo.
