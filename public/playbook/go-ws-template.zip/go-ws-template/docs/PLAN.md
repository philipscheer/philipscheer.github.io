# Planejamento — Template Go WebSockets de Alta Performance

**Status:** Aprovado para implementação · **Data:** 2026-06-11 · **Autor:** Philip Scheer (com Claude)
**Base:** `r10-websockets` + `docs/referencia/arquitetura-websockets-r10.md`

---

## 1. Objetivo

Template Go genérico e reutilizável para camadas de WebSocket de novos projetos, focado em:

1. **Densidade máxima por máquina** — 50k–100k+ conexões por task (1–2 vCPU), escala vertical primeiro; horizontal só para HA.
2. **Fan-out massivo** — milhões de msgs/s por task; a meta de "bilhões de transações/minuto" é atingida pela frota (N tasks × msgs/s), com escala linear por máquina.
3. **Baixo custo** — ~70% menos compute vs. equivalente Node horizontal (modelo §4.3 do doc de referência).
4. **Degradação controlada** — resolver o "super spike" (§6 do doc): latest-wins, idade de mensagem ponta-a-ponta instrumentada, sem head-of-line blocking.

## 2. Decisões validadas com o Product Owner

| Decisão | Escolha | Racional |
|---|---|---|
| Biblioteca WS | `gorilla/websocket` | Familiaridade do time + `PreparedMessage` (serializa 1× para N clientes) |
| Escopo | Genérico | Tópicos/canais configuráveis por env; sem domínio R10 |
| Broker | Redis Pub/Sub atrás de interface `Broker` | Compatível com infra atual; trocar por NATS/Kafka vira plugin |
| Versionamento | Repo git + GitHub | Commits como Philip Scheer `<philipscheer@grupootg.com>` |

## 3. Correções estruturais sobre o r10-websockets

| # | Problema no r10 | Solução no template |
|---|---|---|
| 1 | 🔴 Broadcast com `Lock()` de escrita global + canais não-bufferizados → head-of-line blocking | Shard por canal com `RWMutex` próprio; snapshot da lista sob `RLock`; envio **fora** do lock; mailbox por cliente **nunca bloqueia** o broadcast |
| 2 | 🔴 Cliente lento atrasa todos | Mailbox **latest-wins** (slot atômico com coalescing) ou fila bounded drop-oldest; cliente persistentemente lento é desconectado |
| 3 | 🟠 Sem ping/pong/deadlines → conexões meio-abertas vazam | Ping periódico, `SetReadDeadline` renovado no pong, `SetWriteDeadline` por escrita, `SetReadLimit` |
| 4 | 🟠 `RemoveClientWS` itera todos os canais | Cliente conhece seu canal → remoção O(1) |
| 5 | 🟠 `clientWS.Online` (bool) sem sincronização → data race | Estado por `atomic`/fechamento de canal; `go test -race` no CI |
| 6 | 🟠 Serialização repetida por cliente | `websocket.PreparedMessage`: frame montado 1× por broadcast |
| 7 | 🟡 `CheckOrigin` sempre `true` | Allowlist de origins por env |
| 8 | 🟡 Sem limite de conexões | `MAX_CONNECTIONS` + HTTP 503 → autoscaling age antes da degradação |
| 9 | 🟡 Sem graceful shutdown | SIGTERM → healthz 503 (drain no LB) → close `GoingAway` em ondas com jitter → timeout de drain |
| 10 | 🟡 Sem observabilidade | `/metrics` Prometheus: conexões ativas, msgs/s, drops, **idade p99 da mensagem** (publish→socket), lag de fan-out |
| 11 | 🟡 Sem timestamp/seq na mensagem | Envelope binário: `seq` + `publish_ts` → staleness mensurável no servidor e no cliente |
| 12 | 🟡 `select {}` triplo, sem coordenação de erro | `context` + `errgroup`-like com shutdown coordenado |

## 4. Arquitetura

```
Broker (Redis Pub/Sub | Memory) ──▶ Ingest (1 goroutine, decode envelope)
        │                                  │
        ▼                                  ▼
   topics → channels              Hub (1 shard por canal)
                                   ├─ shard "topic-a": RWMutex + map[id]*Client
                                   │     broadcast: RLock → snapshot → PreparedMessage → mailbox de cada cliente (não-bloqueante)
                                   └─ shard "topic-b": ...
                                            │
                                            ▼
                              Client mailbox (latest-wins slot OU fila bounded)
                                            │
                                  write pump (1 goroutine/cliente)
                                  ping ticker · write deadline · métricas de idade
                                            │
                                            ▼
                                       socket (epoll via netpoller)
```

- **2 goroutines por conexão** (read pump + write pump), ~8 KB cada → 100k conexões ≈ 1,6 GB de stacks no pior caso, na prática menos (stacks de 2–4 KB).
- **Latest-wins (coalescing):** para dados de estado (odds, placares), o slot atômico guarda só a mensagem mais recente; cliente atrasado pula direto para o estado atual. Modo fila (`buffer`) disponível para streams onde toda mensagem importa.
- **GOMAXPROCS:** Go ≥1.25 é container-aware (respeita cgroup CPU limit do Fargate) — sem dependência extra.

## 5. Estrutura do repositório

```
cmd/server/          binário principal
cmd/publisher/       publica eventos de teste no broker (envelope correto)
cmd/loadtest/        gerador de carga: N conexões, mede idade p50/p95/p99 no cliente
internal/config/     configuração por env (stdlib)
internal/hub/        shards, clientes, mailbox, broadcast    [stdlib — testável offline]
internal/envelope/   header binário seq+timestamp            [stdlib — testável offline]
internal/metrics/    atomics + exposição Prometheus text     [stdlib — testável offline]
internal/broker/     interface + redis (go-redis/v9) + memory
internal/transport/  upgrade, pumps, limites, graceful shutdown (gorilla)
docs/                PLAN.md, ARCHITECTURE.md, referencia/
.github/workflows/   ci.yml (vet, test -race, build)
Dockerfile           multi-stage → imagem estática mínima
docker-compose.yml   redis + server para dev local
Makefile             run, test, bench, loadtest, publisher
```

Dependências externas: **apenas** `gorilla/websocket` e `redis/go-redis/v9`. Métricas, config, UUID e afins resolvidos com stdlib (menos supply chain, build mais rápido).

## 6. Configuração (env)

`WS_PORT`, `WS_TOPICS` (lista de canais), `WS_MAX_CONNECTIONS`, `WS_ALLOWED_ORIGINS`, `WS_DELIVERY_MODE` (coalesce|buffer), `WS_CLIENT_BUFFER`, `WS_PING_INTERVAL`, `WS_PONG_TIMEOUT`, `WS_WRITE_TIMEOUT`, `WS_DRAIN_TIMEOUT`, `BROKER_KIND` (redis|memory), `REDIS_ADDR`, `REDIS_CHANNEL_PREFIX`.

## 7. Critérios de aceitação

1. `go vet` e `go test -race` verdes; benchmarks de fan-out incluídos.
2. Broadcast não segura lock de escrita; nenhum send bloqueante no caminho do fan-out.
3. Sob simulação de super spike (rajada + reconexões via `cmd/loadtest`): p99 de idade da mensagem dentro do alvo configurado, drops contabilizados em métrica, zero atraso propagado entre clientes.
4. 1 task (2 vCPU/2 GB) sustenta ≥ 50k conexões com fan-out ativo — validar com `make loadtest` em ambiente dedicado.
5. SIGTERM drena conexões sem thundering herd (ondas com jitter).

## 8. Fora de escopo (e caminho futuro)

- **gobwas/ws + epoll custom** (1M+ conns/máquina, menos RAM): documentado como evolução; a interface `transport` isola a troca.
- Autenticação/autorização de clientes (JWT no upgrade) — ponto de extensão documentado.
- Mensagens cliente→servidor (template é broadcast-only por design, como o r10).

## 9. Nota de verificação desta entrega

⚠️ O ambiente da sessão de geração não tinha acesso a `proxy.golang.org` e o sandbox de execução falhou (disco) antes da rodada de compilação — **o código foi entregue com revisão manual cruzada (imports, contratos entre pacotes, APIs externas), mas sem execução de `go build`/`go test`**. Antes do primeiro commit em CI, rode na sua máquina:

```bash
make setup   # go mod tidy (gera go.sum)
make test    # go vet + go test -race
make bench   # benchmarks de fan-out
```

A suíte de testes incluída cobre os contratos críticos (latest-wins sem bloqueio, drop-oldest, isolamento entre canais, churn concorrente sob -race) — qualquer divergência de compilação será pontual e trivial de corrigir.
