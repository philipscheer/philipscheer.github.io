# Arquitetura

```
Produtor (dataloader) ──PUBLISH──▶ Redis Pub/Sub ──▶ 1 assinatura POR TÓPICO (leitura paralela)
                                                          │ dispatch por tópico
                                              ┌───────────┴───────────┐
                                              ▼                       ▼
                                     worker canal A             worker canal B       (paralelo, multi-core)
                                              │ envelope.Decode → EncodeWire(+canal) → PreparedMessage (1×)
                                              ▼
                                     hub.Broadcast(canal)
                                       snapshot atômico (sem lock, sem alocação)
                                       ≤ chunk: entrega direta · > chunk: WORKER POOL (fatias multi-core)
                                              │ Subscription.deliver() — NUNCA bloqueia
                              ┌───────────────┼────────────────────┐
                              ▼               ▼                    ▼
                     sessão 1 {sub A}   sessão 2 {sub A, sub B}   sessão N {…}   (multiplexação: N canais/conexão)
                       mailbox/sub: latest-wins · keyed (por entidade) · fila bounded
                              │               │                    │
                        write pump       write pump           write pump   (1/conexão: dados+acks+pings, deadlines)
                              ▼               ▼                    ▼
                           socket          socket               socket      (epoll via netpoller do Go)
```

## Invariantes de performance

1. **Nenhum lock no caminho do broadcast.** O shard mantém `atomic.Pointer[[]*Subscription]`; add/remove reconstrói o snapshot (O(n) no churn, zero custo no fan-out). Broadcasts ≫ churn de membros.
2. **Nenhum send bloqueante no caminho do broadcast.** `Subscription.deliver()` faz swap atômico (coalesce), upsert em mapa com mutex curto (keyed) ou send com drop-oldest (buffer). Assinante lento sofre descarte individual, contado em métrica — e é desconectado se persistir (close 1013).
3. **Serialização 1× por broadcast.** `websocket.PreparedMessage` monta o frame (e a variante comprimida, se habilitada) uma única vez para N assinantes.
4. **Toda escrita tem deadline.** Socket morto nunca prende uma goroutine além de `WS_WRITE_TIMEOUT`.
5. **Canais são independentes.** Uma assinatura Redis + um worker de ingestão por tópico; o atraso em um canal não contamina os demais.
6. **Fan-out intra-canal escala com os cores.** Canal com mais de `WS_FANOUT_CHUNK` assinantes é fatiado pelo worker pool — um canal quente não fica limitado a 1 core.

## Goroutines e memória (regra de bolso)

| Componente | Goroutines | Memória |
|---|---|---|
| Por conexão (sessão) | 2 (read+write pump), independente do nº de canais | ~8–16 KB stacks + buffers (pool) + mailboxes |
| Ingestão | 1 por tópico (Redis) + 1 worker por tópico | canais bounded (1024/4096) |
| Fan-out pool | GOMAXPROCS workers fixos | — |
| 100k sessões | ~200k goroutines | ~1,5–2,5 GB típico (GOMEMLIMIT auto = 90% do cgroup) |

Referência de sizing Fargate: 1 vCPU/1 GB ≈ 25–50k conns; 2 vCPU/2 GB ≈ 50–100k — **valide com `make loadtest`**; o teto real depende de msgs/s × payload. Com multiplexação, 1 usuário com 3 canais = 1 conexão (antes: 3).

## Super spike: como o template responde

| Mecanismo | Efeito |
|---|---|
| Latest-wins (coalesce / coalesce-keyed) | Backlog de preços velhos nunca se forma; assinante atrasado pula para o estado atual (por canal ou por entidade) |
| `seq`+`publish_ts` no envelope | Servidor mede idade na escrita; cliente detecta staleness e pode exibir "dado defasado" |
| `ws_message_age_seconds` p99 | O alarme que faltava: dispara quando a idade passa o tolerado pelo motor de risco |
| Workers por tópico + fan-out pool | Spike em um canal não atrasa os outros; canal quente usa todos os cores |
| Política de cliente lento | Quem não consegue consumir sai (1013) em vez de acumular custo |
| Rate limit de upgrades | Accept-storm de reconexões não rouba CPU do fan-out de quem está conectado |
| 503 no teto + drain com jitter | Degradação explícita e controlada, sem colapso nem thundering herd |
| Snapshot-on-connect | Reconectado vê estado imediatamente — reconexão em massa não gera "tela vazia" |

## Decisões e trade-offs

Cada decisão estrutural está registrada como ADR em [`docs/adr/`](adr/README.md) — contexto, alternativas consideradas e consequências:

- [ADR-0001](adr/0001-goroutine-per-connection-gorilla.md) — gorilla/websocket, goroutine-per-connection (vs gobwas/ws+epoll; gatilho de revisão documentado)
- [ADR-0002](adr/0002-redis-pubsub-atras-de-interface.md) — Redis Pub/Sub at-most-once atrás da interface `Broker`
- [ADR-0003](adr/0003-mailbox-latest-wins.md) — mailbox latest-wins (inclui o **contrato de snapshot** do produtor no modo `coalesce`)
- [ADR-0004](adr/0004-hub-shardado-snapshot-atomico.md) — hub shardado com snapshot atômico (broadcast sem lock)
- [ADR-0005](adr/0005-envelope-binario-seq-timestamp.md) — envelope binário seq+timestamp (payload opaco: protobuf/JSON é decisão do produto)
- [ADR-0006](adr/0006-metricas-prometheus-stdlib.md) — métricas Prometheus em stdlib
- [ADR-0007](adr/0007-multiplexacao-de-canais.md) — multiplexação de canais por conexão (protocolo v1.1)
- [ADR-0008](adr/0008-keyed-coalescing.md) — keyed coalescing (latest-wins por chave de entidade)

Novas decisões: criar o ADR no mesmo PR que as implementa ([template](adr/template.md)).

## Checklist de produção

- [ ] `WS_ALLOWED_ORIGINS` restrito aos domínios do produto
- [ ] `WS_AUTH_SECRET` definido (e rotação de segredo planejada), se o produto exige auth
- [ ] ulimit `nofile` ≥ 1M na task definition / systemd
- [ ] GOMEMLIMIT: autodetecção ativa (default) ou valor explícito na task definition
- [ ] ALB idle timeout > `WS_PING_INTERVAL` (ex.: 60s > 25s)
- [ ] `WS_UPGRADE_RATE` dimensionado (ex.: 2000/s) para failover sem accept-storm
- [ ] Alarme no p99 de `ws_message_age_seconds` (limite = tolerância do negócio)
- [ ] Alarme em `ws_messages_dropped_total` (taxa), `ws_slow_clients_disconnected_total`, `ws_rejected_full_total` e `ws_rate_limited_total`
- [ ] `WS_DEBUG_PORT` acessível só pela rede interna (pprof)
- [ ] Scheduled scaling para janelas de pico conhecidas
- [ ] Cliente com reconexão backoff+jitter e tratamento dos closes `1001 going away` e `1013 try again later`
- [ ] Teste de aceitação: `make spike` com p99 dentro do alvo sob rajada + churn
