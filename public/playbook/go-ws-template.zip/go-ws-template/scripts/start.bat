@echo off
REM Inicia o servidor WebSocket local.
REM Uso (na raiz do template):
REM   scripts\start.bat            (broker em memoria, sem Redis - default)
REM   scripts\start.bat memory     (idem)
REM   scripts\start.bat redis      (broker Redis - exige Redis em localhost:6379)
setlocal enabledelayedexpansion
cd /d "%~dp0.."

set "BROKER=%~1"
if "%BROKER%"=="" set "BROKER=memory"

where go >nul 2>&1
if errorlevel 1 (
  echo ERRO: Go nao encontrado no PATH. Rode scripts\setup.bat primeiro.
  exit /b 1
)

if not exist .env (
  echo ==^> .env ausente -- criando a partir de .env.sample...
  copy /Y .env.sample .env >nul
)

REM Carrega variaveis do .env (ignora comentarios e linhas vazias).
for /f "usebackq tokens=1,* delims==" %%A in (".env") do (
  set "line=%%A"
  if not "!line!"=="" if not "!line:~0,1!"=="#" set "%%A=%%B"
)

set "BROKER_KIND=%BROKER%"
if "%WS_PORT%"=="" set "WS_PORT=8080"

echo ==^> Iniciando servidor ^(BROKER_KIND=%BROKER%^) em ws://localhost:%WS_PORT%/ws?channel=events
echo     /healthz  /metrics    ^(Ctrl+C para parar^)
go run ./cmd/server
endlocal
