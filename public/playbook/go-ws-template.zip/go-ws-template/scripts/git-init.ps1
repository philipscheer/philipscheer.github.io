# Inicializa o repositório, valida o build e cria commit + PR
# com o usuário git do Philip. Requer: git, go >= 1.25 e (para o PR) GitHub CLI autenticado (gh auth login).
#
# Uso (na raiz do template):
#   powershell -ExecutionPolicy Bypass -File scripts\git-init.ps1
#   powershell -ExecutionPolicy Bypass -File scripts\git-init.ps1 -CreateRepo -Org grupootg -RepoName go-ws-template

param(
    [switch]$CreateRepo,
    [string]$Org = "grupootg",
    [string]$RepoName = "go-ws-template"
)

$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

Write-Host "==> Validando build e testes (gate antes do commit)..." -ForegroundColor Cyan
go mod tidy
go vet ./...
go test -race ./...
if ($LASTEXITCODE -ne 0) { throw "Testes falharam - commit abortado." }

if (-not (Test-Path ".git")) {
    git init -b main
}
git config user.name  "Philip Scheer"
git config user.email "philipscheer@grupootg.com"

git add -A
git commit -m "docs: planejamento e arquitetura do template de websockets" -- docs/ README.md 2>$null
git checkout -b feat/ws-template 2>$null
git add -A
git commit -m @"
feat: template Go de websockets de alta performance

- Hub shardado por canal: broadcast via snapshot atomico (zero locks no hot path)
- Mailbox latest-wins por cliente: elimina head-of-line blocking (super spike)
- PreparedMessage: serializacao 1x por broadcast
- Keepalive completo (ping/pong, deadlines, read limit) e graceful drain com jitter
- Envelope binario seq+timestamp: idade p99 da mensagem exposta em /metrics
- Broker plugavel: Redis Pub/Sub (go-redis/v9) e memory para dev/teste
- cmd/loadtest e cmd/publisher para validacao de carga e cenario de super spike
- Testes com -race e benchmarks de fan-out; CI no GitHub Actions

Refs: docs/PLAN.md, docs/ARCHITECTURE.md
"@

if ($CreateRepo) {
    Write-Host "==> Criando repositorio $Org/$RepoName no GitHub..." -ForegroundColor Cyan
    gh repo create "$Org/$RepoName" --private --source . --remote origin
    git push -u origin main feat/ws-template
    gh pr create `
        --base main --head feat/ws-template `
        --title "feat: template Go de websockets de alta performance" `
        --body-file docs/PLAN.md
    Write-Host "==> PR criado." -ForegroundColor Green
} else {
    Write-Host ""
    Write-Host "Commit local criado na branch feat/ws-template." -ForegroundColor Green
    Write-Host "Para criar o repo + PR no GitHub:" -ForegroundColor Yellow
    Write-Host "  powershell -ExecutionPolicy Bypass -File scripts\git-init.ps1 -CreateRepo -Org $Org -RepoName $RepoName"
}
