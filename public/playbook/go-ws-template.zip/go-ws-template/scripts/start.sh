#!/usr/bin/env bash
# Inicia o servidor WebSocket local.
# Uso (na raiz do template):
#   ./scripts/start.sh            # broker em memoria (sem Redis) — default
#   ./scripts/start.sh memory     # idem
#   ./scripts/start.sh redis      # broker Redis (exige Redis em localhost:6379)
set -euo pipefail
cd "$(dirname "$0")/.."

BROKER="${1:-memory}"

if ! command -v go >/dev/null 2>&1; then
  echo "ERRO: Go nao encontrado no PATH. Rode ./scripts/setup.sh primeiro." >&2
  exit 1
fi

if [ ! -f .env ]; then
  echo "==> .env ausente — criando a partir de .env.sample..."
  cp .env.sample .env
fi

# Carrega variaveis do .env (ignora comentarios e linhas vazias).
set -a
# shellcheck disable=SC1091
. ./.env
set +a

export BROKER_KIND="$BROKER"
PORT="${WS_PORT:-8080}"

echo "==> Iniciando servidor (BROKER_KIND=$BROKER) em ws://localhost:$PORT/ws?channel=events"
echo "    /healthz  /metrics    (Ctrl+C para parar)"
exec go run ./cmd/server
