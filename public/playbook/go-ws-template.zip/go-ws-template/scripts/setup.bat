@echo off
REM Setup local: baixa dependencias e cria o .env a partir do .env.sample.
REM Uso (na raiz do template): scripts\setup.bat
setlocal
cd /d "%~dp0.."

echo ==^> Verificando Go...
where go >nul 2>&1
if errorlevel 1 (
  echo ERRO: Go nao encontrado no PATH. Instale Go ^>= 1.25 ^(https://go.dev/dl/^).
  exit /b 1
)
go version

echo ==^> Baixando dependencias ^(go mod tidy^)...
go mod tidy
if errorlevel 1 exit /b 1

if not exist .env (
  echo ==^> Criando .env a partir de .env.sample...
  copy /Y .env.sample .env >nul
) else (
  echo ==^> .env ja existe -- mantido.
)

echo.
echo Setup concluido. Para rodar local sem Redis:
echo   scripts\start.bat            ^(broker em memoria - default^)
echo   scripts\start.bat redis      ^(broker Redis - exige Redis em localhost:6379^)
endlocal
