#!/usr/bin/env bash
# Setup local: baixa dependencias e cria o .env a partir do .env.sample.
# Uso (na raiz do template): ./scripts/setup.sh
set -euo pipefail
cd "$(dirname "$0")/.."

echo "==> Verificando Go..."
if ! command -v go >/dev/null 2>&1; then
  echo "ERRO: Go nao encontrado no PATH. Instale Go >= 1.25 (https://go.dev/dl/)." >&2
  exit 1
fi
go version

echo "==> Baixando dependencias (go mod tidy)..."
go mod tidy

if [ ! -f .env ]; then
  echo "==> Criando .env a partir de .env.sample..."
  cp .env.sample .env
else
  echo "==> .env ja existe — mantido."
fi

echo ""
echo "Setup concluido. Para rodar local sem Redis:"
echo "  ./scripts/start.sh            # broker em memoria (default)"
echo "  ./scripts/start.sh redis      # broker Redis (exige Redis em localhost:6379)"
